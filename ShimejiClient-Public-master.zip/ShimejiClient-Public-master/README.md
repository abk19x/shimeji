# ShimejiClient-Public
Project started in April 2022 destroyed by "@koppepandayo"
thanks to kazubon12, Mine_chan__
