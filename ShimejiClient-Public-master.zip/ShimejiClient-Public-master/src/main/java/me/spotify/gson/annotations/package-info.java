/**
 * This package provides annotations that can be used with {@link me.spotify.gson.Gson}.
 *
 * @author Inderjeet Singh, Joel Leitch
 */
package me.spotify.gson.annotations;