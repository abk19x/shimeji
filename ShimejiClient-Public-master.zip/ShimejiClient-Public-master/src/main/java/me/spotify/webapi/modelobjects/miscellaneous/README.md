# Miscellaneous Objects

Objects, that are defined on an API endpoint reference page, but not within
the [main object model](https://developer.spotify.com/documentation/web-api/reference/object-model/).