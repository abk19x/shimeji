# Special Objects

Objects, that are nowhere defined, but returned by requests.