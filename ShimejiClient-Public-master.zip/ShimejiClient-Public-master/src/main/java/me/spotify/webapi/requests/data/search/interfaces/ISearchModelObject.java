package me.spotify.webapi.requests.data.search.interfaces;

import me.spotify.webapi.modelobjects.IModelObject;

public interface ISearchModelObject extends IModelObject {

}
