package me.spotify.webapi.requests.data;

import me.spotify.webapi.modelobjects.specification.PagingCursorbased;
import me.spotify.webapi.requests.IRequest;

public interface IPagingCursorbasedRequestBuilder<T, A, BT extends IRequest.Builder<PagingCursorbased<T>, ?>>
        extends IRequest.Builder<PagingCursorbased<T>, BT> {
    BT limit(final Integer limit);

    BT after(final A after);
}
