package me.spotify.webapi.requests.data;

import me.spotify.webapi.modelobjects.specification.Paging;
import me.spotify.webapi.requests.IRequest;

public interface IPagingRequestBuilder<T, BT extends IRequest.Builder<Paging<T>, ?>>
        extends IRequest.Builder<Paging<T>, BT> {
    BT limit(final Integer limit);

    BT offset(final Integer offset);
}
