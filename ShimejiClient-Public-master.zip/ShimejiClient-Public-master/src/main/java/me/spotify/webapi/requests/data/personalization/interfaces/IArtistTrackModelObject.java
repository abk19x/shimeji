package me.spotify.webapi.requests.data.personalization.interfaces;

import me.spotify.webapi.modelobjects.IModelObject;

public interface IArtistTrackModelObject extends IModelObject {
}
