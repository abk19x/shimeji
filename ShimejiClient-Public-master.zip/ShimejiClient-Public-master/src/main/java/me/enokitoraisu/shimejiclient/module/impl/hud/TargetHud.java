package me.enokitoraisu.shimejiclient.module.impl.hud;

import me.enokitoraisu.shimejiclient.gui.shimeji.ShimejiGui;
import me.enokitoraisu.shimejiclient.module.Category;
import me.enokitoraisu.shimejiclient.module.Module;
import me.enokitoraisu.shimejiclient.utils.animation.Animate;
import me.enokitoraisu.shimejiclient.utils.animation.Delta;
import me.enokitoraisu.shimejiclient.utils.animation.Easing;
import me.enokitoraisu.shimejiclient.utils.entity.FriendUtil;
import me.enokitoraisu.shimejiclient.utils.game.DisplayUtil;
import me.enokitoraisu.shimejiclient.utils.game.MouseUtil;
import me.enokitoraisu.shimejiclient.utils.math.ColorUtil;
import me.enokitoraisu.shimejiclient.utils.renderer.RenderUtil;
import me.enokitoraisu.shimejiclient.utils.renderer.StencilUtil;
import me.enokitoraisu.shimejiclient.utils.renderer.font.FontUtil;
import me.enokitoraisu.shimejiclient.utils.renderer.font.MinecraftFontRenderer;
import me.enokitoraisu.shimejiclient.value.values.BooleanValue;
import me.enokitoraisu.shimejiclient.value.values.ColorValue;
import me.enokitoraisu.shimejiclient.value.values.IntegerValue;
import me.enokitoraisu.shimejiclient.value.values.ModeValue;
import net.minecraft.client.gui.GuiChat;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.gui.inventory.GuiInventory;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import org.lwjgl.input.Keyboard;
import org.lwjgl.input.Mouse;
import org.lwjgl.opengl.GL11;

import java.awt.*;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.util.List;
import java.util.*;

@SuppressWarnings("unused")
public class TargetHud extends Module {
    public float hpwidth, dorthpwidth, dortnewhpwidth = 0;

    public ModeValue themeSetting = register(new ModeValue("Theme", "Diablo", "Diablo", "Panda", "Dortold", "Dortnew", "Chill", "null"));
    public BooleanValue rounded = register(new BooleanValue("Rounded", false, v -> themeSetting.getValue().equals("Diablo")));
    public IntegerValue range = register(new IntegerValue("Range", 30, 0, 100));
    public IntegerValue X = register(new IntegerValue("X", 2, 0, 1000, v -> false));
    public IntegerValue Y = register(new IntegerValue("Y", 2, 0, 1000, v -> false));
    public ColorValue accent = register(new ColorValue("Color", new Color(0x76FF5D)));
    public CharRenderer charRenderer = new CharRenderer();
    public Animate hover = new Animate();

    public EntityLivingBase target;

    public MouseUtil mouse = new MouseUtil(0, 0, 0, 0);
    private boolean dragging;
    private int lastX;
    private int lastY;

    public TargetHud() {
        super("TargetHud", Category.HUD, Keyboard.KEY_NONE);
        this.target = mc.player;
    }

    private boolean isDortWareOld() {
        return this.themeSetting.getValue().equals("Dortold");
    }

    @Override
    public void onTick() {
        setTags(themeSetting.getValue());
        final List<EntityPlayer> entities = new ArrayList<>();
        mc.world.loadedEntityList.stream().filter(EntityPlayer.class::isInstance).filter(entity -> !entity.equals(mc.player)).filter(entity -> entity.getDistance(mc.player) < range.getValue()).map(EntityPlayer.class::cast).filter(player -> !FriendUtil.isFriend(player)).sorted(Comparator.comparingDouble(mc.player::getDistance)).forEach(entities::add);
        if (!entities.isEmpty()) {
            this.target = entities.get(0);
        } else {
            this.target = null;
        }
        if (mc.currentScreen instanceof GuiChat || mc.currentScreen instanceof ShimejiGui) {
            this.target = mc.player;
        }
    }

    @Override
    public void onDisable() {
        hpwidth = 0;
    }

    private void mouseDragging() {
        int mouseX = MouseUtil.getMouseX();
        int mouseY = MouseUtil.getMouseY();

        draggingFix(mouseX, mouseY);
        if (Mouse.isButtonDown(0) && mouse.bounding(MouseUtil.getMouseX(), MouseUtil.getMouseY())) {
            if (!this.dragging) {
                this.lastX = this.mouse.getX() - mouseX;
                this.lastY = this.mouse.getY() - mouseY;
                this.dragging = true;
            }
        }
    }

    public void draggingFix(int mouseX, int mouseY) {
        if (this.dragging) {
            this.mouse.setX(mouseX + this.lastX);
            this.mouse.setY(mouseY + this.lastY);
            this.X.setValue(this.mouse.getX());
            this.Y.setValue(this.mouse.getY());
            if (!Mouse.isButtonDown(0)) this.dragging = false;
        }
    }

    @Override
    public void onRender2D() {
        int x = X.getValue();
        int y = Y.getValue();
        if (!isDortWareOld() && mc.currentScreen instanceof GuiChat) mouseDragging();
        if (this.target != null) {
            float health = target.getHealth() + target.getAbsorptionAmount();
            float maxhealth = target.getAbsorptionAmount() > 0 ? 36.0f : target.getMaxHealth();
            int color = health / maxhealth > 0.66f ? 0xff00ff00 : health / maxhealth > 0.33f ? 0xffffff00 : 0xFFFF0000;
            switch (themeSetting.getValue()) {
                case "Diablo":
                    mouse.setAll(x, y, 160, 50);
                    String text = (int) Math.floor(health / maxhealth % 100 * 100) + "%";

                    if (rounded.getValue()) {
                        RenderUtil.drawSmotherRoundedRect(x, y, 160.0f, 50.0f, 10, 0x60000000, false);
                        RenderUtil.drawSmotherRoundedRect(x + 55, y + 15 + FontUtil.sfui30.getHeight() + FontUtil.sfui18.getHeight(), 95, FontUtil.sfui20.getHeight() + 3, 8, 0xff323232, false);
                        RenderUtil.drawSmotherRoundedRect(x + 55, y + 15 + FontUtil.sfui30.getHeight() + FontUtil.sfui18.getHeight(), 8 + health / maxhealth * 87, FontUtil.sfui20.getHeight() + 3, 8, ColorUtil.getRainbow(10.0f, 0.6f, 1.0f, 1), false);

                        StencilUtil.write(false);
                        RenderUtil.drawCircle(x + 25, y + 25, 19, 0xFFFFFFFF);
                        StencilUtil.erase(true);
                        RenderUtil.drawHead(target, x + 5, y + 5, 40, 40);
                        StencilUtil.dispose();
                    } else {
                        RenderUtil.drawRect(x, y, 160.0f, 50.0f, 0x60000000);
                        RenderUtil.drawRect(x + 55, y + 15 + FontUtil.sfui30.getHeight() + FontUtil.sfui18.getHeight(), 95, FontUtil.sfui20.getHeight() + 3, 0xff323232);
                        RenderUtil.drawRect(x + 55, y + 15 + FontUtil.sfui30.getHeight() + FontUtil.sfui18.getHeight(), health / maxhealth * 95, FontUtil.sfui20.getHeight() + 3, ColorUtil.getRainbow(10.0f, 0.6f, 1.0f, 1));

                        RenderUtil.drawHead(target, x + 5, y + 5, 40, 40);
                    }

                    FontUtil.sfui30.drawString(target.getName(), x + 55, y + 10, -1);
                    if (target != mc.player)
                        FontUtil.sfui18.drawString(String.format("\u00A77%.1f Blocks", mc.player.getDistance(target)), x + 55, y + 10 + FontUtil.sfui30.getHeight(), -1);
                    FontUtil.sfui18.drawCenteredStringWithShadow(text, x + (55 * 2 + 95) / 2f, y + 17 + FontUtil.sfui18.getHeight() + FontUtil.sfui30.getHeight(), -1);
                    break;
                case "Panda":
                    hpwidth = animate((health / maxhealth) * 132.0f, hpwidth, 0.3f);
                    mouse.setAll(x, y, 140, 50);
                    RenderUtil.drawSmotherRoundedRect(x, y, 140.0f, 50.0f, 5.0f, 0x60000000, false);
                    FontUtil.sfui20.drawStringWithShadow(target.getName(), x + 45.0, y + 4, -1);
                    FontUtil.sfui20.drawStringWithShadow(String.format("Health: \u00A77%.1f", health), x + 45.0, y + 4 + FontUtil.sfui20.getHeight(), -1);
                    if (target instanceof EntityPlayer) {
                        if (mc.getConnection().getPlayerInfo(target.getUniqueID()) != null)
                            FontUtil.sfui20.drawStringWithShadow("Ping: \u00A77" + mc.getConnection().getPlayerInfo(target.getUniqueID()).getResponseTime(), x + 45.0, y + 4 + FontUtil.sfui20.getHeight() * 2, -1);
                        StencilUtil.write(false);
                        RenderUtil.drawSmotherRoundedRect(x + 2, y + 2, 38, 38, 5.0f, 0xffffffff, false);
                        StencilUtil.erase(true);
                        RenderUtil.drawHead(target, x + 2, y + 2, 38, 38);
                        StencilUtil.dispose();
                    }
                    RenderUtil.drawSmotherRoundedRect(x + 2.0f, y + 42.0f, hpwidth + 4.0f, 6.0f, 5.0f, accent.getIntValue(), false);
                    break;
                case "Dortold":
                    dorthpwidth = animate((health / maxhealth) * 160, dorthpwidth, 0.05f);
                    int width2 = DisplayUtil.getWidth() / 2;
                    int height2 = DisplayUtil.getHeight() / 2;

                    int dort_x = width2 - 80;
                    int dort_y = height2 + 10;

                    RenderUtil.drawRect(dort_x, dort_y, 160, 10, Integer.MIN_VALUE);
                    RenderUtil.drawDoubleRect(dort_x, dort_y, dort_x + dorthpwidth, dort_y + 10, color);
                    FontUtil.sfui18.drawStringWithShadow(target.getName(), dort_x + 2, dort_y + (10 - FontUtil.sfui18.getHeight()) / 2f, -1);
                    FontUtil.sfui18.drawStringWithShadow(String.valueOf((int) health), width2 + 80 - (FontUtil.sfui18.getStringWidth(String.valueOf((int) (health))) + 1), dort_y + (10 - FontUtil.sfui18.getHeight()) / 2f, -1);
                    break;
                case "Dortnew":
                    dortnewhpwidth = animate((health / maxhealth) * 139, dortnewhpwidth, 0.5f);
                    mouse.setAll(x, y, 140, 50);
                    RenderUtil.drawRect(x, y, 140.0f, 50.0f, Integer.MIN_VALUE);
                    GL11.glColor3f(1.0f, 1.0f, 1.0f);
                    try {
                        GuiInventory.drawEntityOnScreen(x + 15, y + 45, 20, target.rotationYaw, target.rotationPitch, target);
                    } catch (Exception ignored) {
                    }
                    mc.fontRenderer.drawStringWithShadow("Name: " + target.getName(), x + 30, y + 10, -1);
                    mc.fontRenderer.drawStringWithShadow(String.format("Distance: %.0fm", mc.player.getDistance(target)), x + 30, y + 11 + mc.fontRenderer.FONT_HEIGHT, -1);
                    mc.fontRenderer.drawStringWithShadow("Armor: " + target.getTotalArmorValue(), x + 30, y + 12 + mc.fontRenderer.FONT_HEIGHT * 2, -1);
                    RenderUtil.drawDoubleRect(x + 0.5, y + 48, x + 139, y + 48 + 1.5, 0xff191919);
                    RenderUtil.drawDoubleRect(x + 0.5, y + 48, x + dortnewhpwidth, y + 48 + 1.5, color);
                    break;
                case "Chill":
                    hpwidth = animate((health / maxhealth) * 110, hpwidth, 0.3f);
                    mouse.setAll(x, y, 130, 50);
                    RenderUtil.drawSmotherRoundedRect(x, y, 130, 50, 10, 0x80000000, false);
                    StencilUtil.write(false);
                    RenderUtil.drawSmotherRoundedRect(x + 5, y + 5, 30, 30, 5F, 0xffffffff, false);
                    StencilUtil.erase(true);
                    RenderUtil.drawHead(target, x + 5, y + 5, 30, 30);
                    StencilUtil.dispose();
                    RenderUtil.drawSmotherRoundedRect(x + 5, y + 40, hpwidth + 10, 5, 5, accent.getIntValue(), false);
                    FontUtil.sfui18.drawString(target.getName(), x + 40, y + 7, -1);
                    GlStateManager.pushMatrix();
                    charRenderer.renderChar(target.getHealth() + target.getAbsorptionAmount(), x + 40, y + 8 + FontUtil.sfui18.getHeight(), false, 0.5F, -1);
                    GlStateManager.popMatrix();
                    break;
                case "null":
                    break;
            }
            hover.setEase(Easing.LINEAR).setMin(0).setMax(100).setSpeed(500).setReversed(!(mc.currentScreen instanceof GuiChat) || (!mouse.bounding(MouseUtil.getMouseX(), MouseUtil.getMouseY()) || isDortWareOld())).update();
            RenderUtil.drawRect(mouse.getX(), mouse.getY(), mouse.getWidth(), mouse.getHeight(), ColorUtil.toRGBA(0f, 0f, 0f, hover.getValue() / 200f));
            RenderUtil.drawOutLineRect(mouse.getX(), mouse.getY(), mouse.getWidth(), mouse.getHeight(), 1f, ColorUtil.toRGBA(1f, 1f, 1f, hover.getValue() / 100f));
            if (hover.getValue() != 0)
                FontUtil.bonicon40.drawCenteredString("y", mouse.getX() + mouse.getWidth() / 2f, mouse.getY() + (mouse.getHeight() / 2f - FontUtil.bonicon30.getHeight() / 2f), ColorUtil.toRGBA(1f, 1f, 1f, hover.getValue() / 100f));
        }
    }

    public float animate(float target, float current, float speed) {
        boolean larger = target > current;

        if (speed < 0.0) {
            speed = 0.0f;
        } else if (speed > 1.0) {
            speed = 1.0f;
        }

        float dif = Math.max(target, current) - Math.min(target, current);
        float factor = dif * speed;

        if (factor < 0.1) {
            factor = 0.1f;
        }

        if (Math.abs(current - target) < factor) {
            current = target;
        } else if (larger) {
            current += factor;
        } else {
            current -= factor;
        }

        return current;
    }

    public static class CharRenderer {
        private final float[] moveX = new float[20];
        private final float[] moveY = new float[20];

        private final List<String> numberList = Arrays.asList("0", "1", "2", "3", "4", "5", "6", "7", "8", "9", ".");

        private final DecimalFormat deFormat = new DecimalFormat("00.00", new DecimalFormatSymbols(Locale.ENGLISH));

        public CharRenderer() {
            for (int i = 0; i < 19; i++) {
                moveX[i] = 0F;
                moveY[i] = 0F;
            }
        }

        public float renderChar(float number, float x, float y, boolean shadow, float fontSpeed, int color) {
            String reFormat = deFormat.format(number);
            MinecraftFontRenderer fontRenderer = FontUtil.sfui40;
            float delta = Delta.DeltaTime;
            ScaledResolution resolution = new ScaledResolution(mc);

            int indexX = 0;
            int indexY = 0;
            float animX = 0F;

            GL11.glEnable(GL11.GL_SCISSOR_TEST);
            RenderUtil.glScissor(0F, y - 1F, resolution.getScaledWidth(), fontRenderer.getHeight() + 2F);
            for (char c : reFormat.toCharArray()) {
                moveX[indexX] = animate(animX, moveX[indexX], fontSpeed * 0.025F * delta);
                animX = moveX[indexX];

                int pos = numberList.indexOf(String.valueOf(c));
                float expectAnim = (fontRenderer.getHeight() + 2F) * pos;
                float expectAnimMin = (fontRenderer.getHeight() + 2F) * (pos - 2);
                float expectAnimMax = (fontRenderer.getHeight() + 2F) * (pos + 2);

                if (pos >= 0) {
                    moveY[indexY] = animate(expectAnim, moveY[indexY], fontSpeed * 0.02F * delta);

                    GlStateManager.translate(0F, y - moveY[indexY], 0F);

                    for (int index = 0; index < numberList.size(); index++) {
                        String num = numberList.get(index);
                        if ((float) (fontRenderer.getHeight() + 2) * index >= expectAnimMin && (float) (fontRenderer.getHeight() + 2) * index <= expectAnimMax) {
                            if (shadow)
                                fontRenderer.drawStringWithShadow(num, x + animX, (fontRenderer.getHeight() + 2F) * index, color);
                            else
                                fontRenderer.drawString(num, x + animX, (fontRenderer.getHeight() + 2F) * index, color);
                        }
                    }

                    GlStateManager.translate(0F, -(y - moveY[indexY]), 0F);
                } else {
                    moveY[indexY] = 0F;
                    if (shadow)
                        fontRenderer.drawStringWithShadow(String.valueOf(c), x + animX, y, color);
                    else
                        fontRenderer.drawString(String.valueOf(c), x + animX, y, color);
                }

                animX += fontRenderer.getStringWidth(String.valueOf(c));
                indexX++;
                indexY++;
            }

            GL11.glDisable(GL11.GL_SCISSOR_TEST);

            return animX;
        }

        public float animate(float target, float current, float speed) {
            boolean larger = target > current;

            if (speed < 0.0) {
                speed = 0.0f;
            } else if (speed > 1.0) {
                speed = 1.0f;
            }

            float dif = Math.max(target, current) - Math.min(target, current);
            float factor = dif * speed;

            if (factor < 0.1) {
                factor = 0.1f;
            }

            if (Math.abs(current - target) < factor) {
                current = target;
            } else if (larger) {
                current += factor;
            } else {
                current -= factor;
            }

            return current;
        }
    }
}
