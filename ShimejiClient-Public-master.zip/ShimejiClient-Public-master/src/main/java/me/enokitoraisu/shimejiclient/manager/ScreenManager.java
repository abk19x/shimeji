package me.enokitoraisu.shimejiclient.manager;

import me.enokitoraisu.shimejiclient.gui.shimeji.ShimejiGui;
import me.enokitoraisu.shimejiclient.utils.renderer.ClickCircle;

import java.util.ArrayList;
import java.util.List;

public class ScreenManager {
    public final ShimejiGui clickGui;
    public final List<ClickCircle> clickCircles;

    public ScreenManager() {
        this.clickGui = new ShimejiGui();
        this.clickCircles = new ArrayList<>();
    }

    public void drawCircle(int color) {
        clickCircles.removeIf(ClickCircle::isRemovable);
        clickCircles.forEach(clickCircle -> clickCircle.draw(color));
    }
}
