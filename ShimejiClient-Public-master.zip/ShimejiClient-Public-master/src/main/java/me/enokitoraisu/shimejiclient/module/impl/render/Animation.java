package me.enokitoraisu.shimejiclient.module.impl.render;

import me.enokitoraisu.shimejiclient.event.FlagGetEvent;
import me.enokitoraisu.shimejiclient.event.SwingAnimationEvent;
import me.enokitoraisu.shimejiclient.module.Category;
import me.enokitoraisu.shimejiclient.module.Module;
import me.enokitoraisu.shimejiclient.value.values.BooleanValue;
import me.enokitoraisu.shimejiclient.value.values.IntegerValue;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.EnumHand;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import org.lwjgl.input.Keyboard;

@SuppressWarnings("unused")
public class Animation extends Module {
    public static Animation INSTANCE = new Animation();

    public BooleanValue swing_speed = register(new BooleanValue("SwingSpeed", false));
    public IntegerValue speed = register(new IntegerValue("Speed", 12, 6, 32, v -> swing_speed.getValue()));
    public BooleanValue offhand = register(new BooleanValue("Offhand", false));
    public BooleanValue legs = register(new BooleanValue("Legs", false));
    public BooleanValue sneak = register(new BooleanValue("Sneak", false));

    public Animation() {
        super("Animation", "SwingSpeed", Category.RENDER, Keyboard.KEY_NONE);
        INSTANCE = this;
    }

    @SubscribeEvent
    public void onArmSwingAnim(SwingAnimationEvent event) {
        if (swing_speed.getValue() && event.getEntity() == mc.player)
            event.setSpeed(speed.getValue());
    }

    public void onTick() {
        if (offhand.getValue() && mc.player.isSwingInProgress) {
            mc.player.swingingHand = EnumHand.OFF_HAND;
        }
        if (swing_speed.getValue()) {
            setTags(speed.getValue().toString());
        } else {
            setTags("");
        }
    }

    @SubscribeEvent
    public void onFlagGet(FlagGetEvent event) {
        if (event.getEntity() instanceof EntityPlayer && event.getEntity() != mc.player && event.getFlag() == 1 && sneak.getValue()) {
            event.setReturnValue(true);
        }
    }
}