package me.enokitoraisu.shimejiclient.utils.interfaces;

public interface IMaxDuration {
    int getMaxDuration();
}
