package me.enokitoraisu.shimejiclient.gui.shimeji.componet.componets;

import me.enokitoraisu.shimejiclient.gui.shimeji.Panel;
import me.enokitoraisu.shimejiclient.gui.shimeji.componet.Component;
import me.enokitoraisu.shimejiclient.utils.animation.Animate;
import me.enokitoraisu.shimejiclient.utils.animation.Easing;
import me.enokitoraisu.shimejiclient.utils.renderer.RenderUtil;
import me.enokitoraisu.shimejiclient.utils.renderer.font.FontUtil;
import me.enokitoraisu.shimejiclient.value.values.EnumValue;
import me.enokitoraisu.shimejiclient.value.values.IEnumValue;
import me.enokitoraisu.shimejiclient.value.values.ModeValue;
import org.lwjgl.opengl.GL11;

public class DropDownButton<T extends Enum<T> & IEnumValue> extends Component {
    private ModeValue modeValue;
    private EnumValue<T> enumValue;
    private final Animate animate = new Animate();
    private boolean opening;
    private final boolean isEnum;

    public DropDownButton(ModeValue modeValue, int x, int width, int height) {
        this.modeValue = modeValue;
        this.x = x;
        this.width = width;
        this.height = height;
        this.opening = false;
        this.isEnum = false;
    }

    public DropDownButton(EnumValue<T> enumValue, int x, int width, int height) {
        this.enumValue = enumValue;
        this.x = x;
        this.width = width;
        this.height = height;
        this.opening = false;
        this.isEnum = true;
    }

    @Override
    public void drawScreen(int mouseX, int mouseY, int offsetY) {
        this.visible = isEnum ? enumValue.getVisibility() : modeValue.getVisibility();
        if (visible) {
            this.y = offsetY;

            String name = isEnum ? enumValue.getName() : modeValue.getName();
            String value = isEnum ? enumValue.getValue().display() : modeValue.getValue();

            RenderUtil.drawRect(x, y, width, height, 0xCB191919);
            if (bounding(mouseX, mouseY)) RenderUtil.drawRect(x, y, width, height, 0x40000000);

            FontUtil.sfui18.drawStringWithShadow(String.format("%s : %s", name, value),
                    x + 5,
                    y + height / 2f - FontUtil.sfui18.getHeight() / 2f,
                    -1);

            FontUtil.sfui18.drawStringWithShadow("...",
                    (x + width) - (5 + FontUtil.sfui18.getStringWidth("...")),
                    y + height / 2f - FontUtil.sfui18.getHeight() / 2f,
                    -1);

            animate.setEase(animate.isReversed() ? Easing.QUINTIC_IN : Easing.QUINTIC_OUT).setMin(0).setMax(100).setSpeed(500).setReversed(!opening).update();

            int size = isEnum ? enumValue.getEnumConstants().length : modeValue.list.size();
            Panel.offset += (height * size) * (animate.getValue() / 100);

            GL11.glEnable(GL11.GL_SCISSOR_TEST);
            RenderUtil.glScissor(x, y, width, height + (height * size + 0.6f) * (animate.getValue() / 100));

            int count = 1;
            for (String mode : modeValue.list) {
                RenderUtil.drawRect(x, y + height * count, width, height, 0xCB191919);

                if (bounding(mouseX, mouseY, x, y + height * count, width, height))
                    RenderUtil.drawRect(x, y + height * count, width, height, 0x40000000);

                FontUtil.sfui18.drawStringWithShadow(
                        mode,
                        x + (width / 2f - FontUtil.sfui18.getStringWidth(mode) / 2f),
                        (y + height * count) + height / 2f - FontUtil.sfui18.getHeight() / 2f,
                        modeValue.getValue().equals(mode) ? -1 : 0xFF505050
                );

                count++;
            }

            GL11.glDisable(GL11.GL_SCISSOR_TEST);
        }
    }

    @Override
    public void mouseClicked(int mouseX, int mouseY, int mouseButton) {
        if (bounding(mouseX, mouseY) && mouseButton == 1) this.opening = !this.opening;

        if (opening && visible && mouseButton == 0) {
            int count = 1;
            for (String mode : modeValue.list) {
                if (bounding(mouseX, mouseY, x, y + height * count, width, height))
                    modeValue.setValueOfIndex(modeValue.list.indexOf(mode));
                count++;
            }
        }
    }
}
