package me.enokitoraisu.shimejiclient.module.impl.client;

import me.enokitoraisu.shimejiclient.module.Category;
import me.enokitoraisu.shimejiclient.module.Module;
import me.enokitoraisu.shimejiclient.utils.math.Easings;
import me.enokitoraisu.shimejiclient.value.values.ColorValue;
import me.enokitoraisu.shimejiclient.value.values.IntegerValue;
import me.enokitoraisu.shimejiclient.value.values.ModeValue;
import org.lwjgl.input.Keyboard;

import java.awt.*;

public class GuiClickCircle extends Module {
    public static GuiClickCircle INSTANCE = new GuiClickCircle();
    public final IntegerValue seconds = register(new IntegerValue("Seconds", 2, 1, 5));
    public final IntegerValue radius = register(new IntegerValue("Radius", 5, 3, 15));
    public final ColorValue color = register(new ColorValue("Color", new Color(0x80FFFFFF), false));
    public final ModeValue easing = register(new ModeValue("Easing", Easings.easings[0], Easings.easings));

    public GuiClickCircle() {
        super("GuiClickCircle", Category.CLIENT, Keyboard.KEY_NONE);
        INSTANCE = this;
    }
}
