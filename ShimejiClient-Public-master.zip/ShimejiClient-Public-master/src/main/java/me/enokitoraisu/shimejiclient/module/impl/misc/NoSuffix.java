package me.enokitoraisu.shimejiclient.module.impl.misc;

import me.enokitoraisu.shimejiclient.event.PacketEvent;
import me.enokitoraisu.shimejiclient.mixin.AccessorSPacketChat;
import me.enokitoraisu.shimejiclient.module.Category;
import me.enokitoraisu.shimejiclient.module.Module;
import me.enokitoraisu.shimejiclient.utils.math.MathUtil;
import net.minecraft.network.play.server.SPacketChat;
import net.minecraft.util.text.Style;
import net.minecraft.util.text.TextComponentString;
import net.minecraft.util.text.event.HoverEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import org.lwjgl.input.Keyboard;

import java.util.Objects;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class NoSuffix extends Module {
    private final String regex = "([|/:《》⏐].*)";

    public NoSuffix() {
        super("NoSuffix", Category.MISC, Keyboard.KEY_NONE);
    }

    @SubscribeEvent
    public void onPacketReceived(PacketEvent.Receive event) {
        if (event.getPacket() instanceof SPacketChat) {
            AccessorSPacketChat packet = (AccessorSPacketChat) event.getPacket();
            String message = packet.getChatComponent().getUnformattedText();
            Matcher matcher;
            Matcher chat;
            if ((matcher = matcher(message)).find() && (chat = chat(MathUtil.cleanColor(message))).find() && !Objects.equals(chat.group(1), mc.player.getName())) {
                packet.setChatComponent(new TextComponentString(packet.getChatComponent().getUnformattedText().replaceAll(regex, ""))
                        .appendSibling(new TextComponentString("\u00A7e[NoSuffix]")
                                .setStyle(new Style().setHoverEvent(new HoverEvent(HoverEvent.Action.SHOW_TEXT, new TextComponentString(matcher.group(0)))))));
            }
        }
    }

    public Matcher matcher(String message) {
        return Pattern.compile(regex).matcher(message);
    }

    public Matcher chat(String message) {
        return Pattern.compile("<([a-zA-Z0-9_]{2,16})>").matcher(message);
    }
}
