package me.enokitoraisu.shimejiclient.module.impl.client;

import me.enokitoraisu.shimejiclient.ShimejiClient;
import me.enokitoraisu.shimejiclient.gui.shimeji.ShimejiGui;
import me.enokitoraisu.shimejiclient.module.Category;
import me.enokitoraisu.shimejiclient.module.Module;
import me.enokitoraisu.shimejiclient.value.values.BooleanValue;
import me.enokitoraisu.shimejiclient.value.values.ColorValue;
import org.lwjgl.input.Keyboard;

import java.awt.*;

@SuppressWarnings("unused")
public class Gui extends Module {
    public static Gui INSTANCE = new Gui();

    public ColorValue color = register(new ColorValue("Color", new Color(0x7D88FF)));
    public BooleanValue blur = register(new BooleanValue("Blur", false));

    public Gui() {
        super("Gui", Category.CLIENT, Keyboard.KEY_O);
        INSTANCE = this;
    }

    public void onEnable() {
        if (!(mc.currentScreen instanceof ShimejiGui))
            mc.displayGuiScreen(ShimejiClient.screenManager.clickGui);
    }

    public void onTick() {
        if (!(mc.currentScreen instanceof ShimejiGui))
            this.toggle();
    }
}