package me.enokitoraisu.shimejiclient.module.impl.hud;

import me.enokitoraisu.shimejiclient.module.Category;
import me.enokitoraisu.shimejiclient.module.Module;
import me.enokitoraisu.shimejiclient.utils.entity.BlockUtil;
import me.enokitoraisu.shimejiclient.utils.game.DisplayUtil;
import me.enokitoraisu.shimejiclient.value.values.BooleanValue;
import me.enokitoraisu.shimejiclient.value.values.ModeValue;
import net.minecraft.block.BlockAir;
import net.minecraft.block.BlockEnderChest;
import net.minecraft.block.BlockSkull;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.math.BlockPos;
import org.lwjgl.input.Keyboard;

@SuppressWarnings("unused")
public class PhaseTime extends Module {
    private final BooleanValue sendChat = register(new BooleanValue("StopSendTime", false));
    private final ModeValue formatTime = register(new ModeValue("Format", "milliSec", "milliSec", "Sec"));
    public boolean phase;
    public long startTime = -1;

    public PhaseTime() {
        super("PhaseTime", Category.HUD, Keyboard.KEY_NONE);
    }

    @Override
    public void onRender2D() {
        if (isPhasing(mc.player) && !phase) {
            startTime = System.currentTimeMillis();
            this.phase = true;
        } else if (!isPhasing(mc.player) && phase) {
            this.phase = false;
            if (sendChat.getValue())
                sendMessage("PhaseTime: " + format(System.currentTimeMillis() - startTime));
        }

        if (isPhasing(mc.player) && phase) {
            String format = String.format("PhaseTime: %s", format(System.currentTimeMillis() - startTime));
            mc.fontRenderer.drawStringWithShadow(
                    format,
                    DisplayUtil.getWidth() / 2f - mc.fontRenderer.getStringWidth(format) / 2f,
                    DisplayUtil.getHeight() / 2f - mc.fontRenderer.FONT_HEIGHT * 3,
                    -1
            );
        }
    }

    public String format(long time) {
        switch (formatTime.getValue()) {
            case "Sec":
                return (time / 1000L) + "s";
            case "milliSec":
            default:
                return time + "ms";
        }
    }

    public boolean isPhasing(EntityPlayer player) {
        BlockPos pos = BlockUtil.floorPos(player);
        IBlockState state = mc.world.getBlockState(pos);

        return (state.getBlock() instanceof BlockEnderChest ||
                state.getBlock() instanceof BlockSkull ||
                state.isFullBlock()) &&
                !(state.getBlock() instanceof BlockAir) &&
                state.getMaterial() != Material.LAVA &&
                state.getMaterial() != Material.WATER;
    }
}
