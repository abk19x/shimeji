package me.enokitoraisu.shimejiclient.module.impl.player;

import me.enokitoraisu.shimejiclient.event.BlockEvent;
import me.enokitoraisu.shimejiclient.event.ClickBlockEvent;
import me.enokitoraisu.shimejiclient.module.Category;
import me.enokitoraisu.shimejiclient.module.Module;
import me.enokitoraisu.shimejiclient.utils.entity.InventoryUtil;
import me.enokitoraisu.shimejiclient.value.values.BooleanValue;
import net.minecraft.block.state.IBlockState;
import net.minecraft.item.ItemStack;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.RayTraceResult;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import org.lwjgl.input.Keyboard;

@SuppressWarnings("unused")
public class AutoTool extends Module {
    private final BooleanValue silent = register(new BooleanValue("Silent", false));

    public AutoTool() {
        super("AutoTool", Category.PLAYER, Keyboard.KEY_NONE);
    }

    @SubscribeEvent
    public void onClickBlock(ClickBlockEvent event) {
        if (!silent.getValue()) {
            IBlockState block = mc.world.getBlockState(event.getPos());
            float strength = 1.0F;
            int bestItemIndex = -1;
            for (int i = 0; i < 9; i++) {
                ItemStack itemStack = mc.player.inventory.getStackInSlot(i);
                if (itemStack.getDestroySpeed(block) > strength) {
                    strength = itemStack.getDestroySpeed(block);
                    bestItemIndex = i;
                }
            }
            if (bestItemIndex != -1)
                InventoryUtil.switchToSlot(bestItemIndex, false);
        }
    }

    @SubscribeEvent
    public void onDamageBlockEvent(BlockEvent.Damage event) {
        if (mc.gameSettings.keyBindAttack.isKeyDown() && mc.objectMouseOver != null) {
            if (mc.objectMouseOver.typeOfHit == RayTraceResult.Type.BLOCK) {
                IBlockState block = mc.world.getBlockState(mc.objectMouseOver.getBlockPos());
                float strength = 1.0F;
                int bestItemIndex = -1;
                for (int i = 0; i < 9; i++) {
                    ItemStack itemStack = mc.player.inventory.getStackInSlot(i);
                    if (itemStack.getDestroySpeed(block) > strength) {
                        strength = itemStack.getDestroySpeed(block);
                        bestItemIndex = i;
                    }
                }

                if (bestItemIndex != -1 && mc.player.inventory.currentItem != bestItemIndex)
                    event.setCanceled(true);
            }
        }
    }

    @Override
    public void onUpdate() {
        if (silent.getValue()) {
            if (mc.gameSettings.keyBindAttack.isKeyDown() && mc.objectMouseOver != null) {
                if (mc.objectMouseOver.sideHit == null) return;
                if (mc.objectMouseOver.typeOfHit == RayTraceResult.Type.BLOCK) {
                    IBlockState block = mc.world.getBlockState(mc.objectMouseOver.getBlockPos());
                    float strength = 1.0F;
                    int bestItemIndex = -1;
                    for (int i = 0; i < 9; i++) {
                        ItemStack itemStack = mc.player.inventory.getStackInSlot(i);
                        if (itemStack.getDestroySpeed(block) > strength) {
                            strength = itemStack.getDestroySpeed(block);
                            bestItemIndex = i;
                        }
                    }

                    int old = mc.player.inventory.currentItem;
                    if (bestItemIndex != -1 && old != bestItemIndex) {
                        InventoryUtil.switchToSlot(bestItemIndex, false);
                        mc.player.swingArm(EnumHand.MAIN_HAND);
                        mc.playerController.onPlayerDamageBlock(mc.objectMouseOver.getBlockPos(), mc.objectMouseOver.sideHit);
                        InventoryUtil.switchToSlot(old, false);
                    }
                }
            }
        }
    }
}
