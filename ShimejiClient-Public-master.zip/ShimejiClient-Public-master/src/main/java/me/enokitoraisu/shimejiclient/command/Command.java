package me.enokitoraisu.shimejiclient.command;

import me.enokitoraisu.shimejiclient.ShimejiClient;
import net.minecraft.client.Minecraft;
import net.minecraft.util.text.TextComponentString;

public class Command {
    public static String commandInput;
    public static Minecraft mc = Minecraft.getMinecraft();
    public String name;
    public String description;

    public Command(String name, String description) {
        super();
        this.name = name;
        this.description = description;
    }

    public static void sendMessage(String message) {
        mc.player.sendMessage(new TextComponentString(ShimejiClient.PrefixFormat + message));
    }

    public void onCommand() {
    }

    public String arg(int arg) {
        return args()[arg];
    }

    public String[] args() {
        return commandInput.split(" ");
    }
}
