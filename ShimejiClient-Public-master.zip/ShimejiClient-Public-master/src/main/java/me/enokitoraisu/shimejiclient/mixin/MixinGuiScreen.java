package me.enokitoraisu.shimejiclient.mixin;

import me.enokitoraisu.shimejiclient.ShimejiClient;
import me.enokitoraisu.shimejiclient.module.impl.client.GuiClickCircle;
import me.enokitoraisu.shimejiclient.utils.renderer.ClickCircle;
import net.minecraft.client.gui.GuiScreen;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(GuiScreen.class)
public class MixinGuiScreen {
    @Inject(method = "drawScreen(IIF)V", at = @At(value = "HEAD"))
    public void drawScreen(int mouseX, int mouseY, float partialTicks, CallbackInfo ci) {
        GuiClickCircle module = GuiClickCircle.INSTANCE;
        ShimejiClient.screenManager.drawCircle(module.color.getIntValue());
    }

    @Inject(method = "mouseClicked(III)V", at = @At(value = "HEAD"))
    public void mouseClicked(int mouseX, int mouseY, int mouseButton, CallbackInfo ci) {
        GuiClickCircle module = GuiClickCircle.INSTANCE;
        if (module.toggled)
            ShimejiClient.screenManager.clickCircles.add(new ClickCircle(mouseX, mouseY, module.seconds.getValue(), module.radius.getValue(), module.easing.getValue()));
    }
}
