package me.enokitoraisu.shimejiclient.module.impl.hud;

import me.enokitoraisu.shimejiclient.module.Category;
import me.enokitoraisu.shimejiclient.module.Module;
import me.enokitoraisu.shimejiclient.utils.game.DisplayUtil;
import me.enokitoraisu.shimejiclient.utils.interfaces.TimedRenderer;
import me.enokitoraisu.shimejiclient.utils.math.TimerUtil;
import me.enokitoraisu.shimejiclient.utils.renderer.BonIcon;
import me.enokitoraisu.shimejiclient.utils.renderer.RenderUtil;
import me.enokitoraisu.shimejiclient.utils.renderer.font.FontUtil;
import me.enokitoraisu.shimejiclient.value.values.IntegerValue;
import org.lwjgl.input.Keyboard;

import java.awt.*;
import java.util.Collections;
import java.util.Comparator;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.stream.Collectors;

public class NewNotifications extends Module {
    public static NewNotifications INSTANCE = new NewNotifications();
    private final IntegerValue seconds = register(new IntegerValue("Seconds", 2, 1, 10));
    public CopyOnWriteArrayList<Base> bases = new CopyOnWriteArrayList<>();
    public TimerUtil time = new TimerUtil();

    public NewNotifications() {
        super("NewNotifications", Category.HUD, Keyboard.KEY_NONE);
        INSTANCE = this;
    }

    @Override
    public void onRender2D() {
        bases.removeIf(Base::hasExpired);
        bases.forEach(Base::render);
    }

    public void add(String message, Type type) {
        int y = DisplayUtil.getHeight() - 40;
        bases = bases.stream().sorted(Comparator.comparingInt(value -> value.y)).collect(Collectors.toCollection(CopyOnWriteArrayList::new));
        Collections.reverse(bases);
        for (Base base : bases) {
            if (base.y >= y) {
                y -= base.height + 2;
            } else {
                break;
            }
        }

        String icon;
        switch (type) {
            case WARN:
                icon = BonIcon.WARNING;
                break;
            case ERROR:
                icon = BonIcon.CANCEL;
                break;
            case INFO:
            default:
                icon = BonIcon.INFO;
                break;
        }

        Base baseA = new Base(message, DisplayUtil.getWidth(), y, (int) FontUtil.sfui18.getStringWidth(message) + (int) FontUtil.bonicon40.getStringWidth(icon) + 20, 20, type);
        bases.add(baseA);
    }

    public enum Type {
        INFO, WARN, ERROR
    }

    public class Base implements TimedRenderer {
        public final String message;
        public final int width;
        public final int height;
        public final Type type;
        public final long time;
        public int x;
        public int y;

        public Base(String message, int x, int y, int width, int height, Type type) {
            this.message = message;
            this.x = x;
            this.y = y;
            this.width = width;
            this.height = height;
            this.type = type;
            this.time = System.currentTimeMillis();
        }

        @Override
        public void render() {
            float value = getProgress();
            float value1;
            if (value < 0.2) {
                value1 = 1 - (float) Math.pow(1 - value * 5, 3);
            } else if (value > 0.8) {
                value1 = (float) Math.pow(5 - value * 5, 3);
            } else {
                value1 = 1.0f;
            }

            int color;
            String icon;
            switch (type) {
                case WARN:
                    color = new Color(0xFFFFFF80).hashCode();
                    icon = BonIcon.WARNING;
                    break;
                case ERROR:
                    color = new Color(0xFFFF8080).hashCode();
                    icon = BonIcon.CANCEL;
                    break;
                case INFO:
                default:
                    color = new Color(0xFF80FF80).hashCode();
                    icon = BonIcon.INFO;
                    break;
            }

            float x_var = x - width * value1;
            RenderUtil.drawRect(x_var, y, width, height, 0x80000000);
            RenderUtil.drawRect(x_var, y + height - 1, width * value, 1, color);
            FontUtil.sfui18.drawStringWithShadow(message, x_var + 10 + width / 2f - FontUtil.sfui18.getStringWidth(message) / 2f, y + height / 2f - FontUtil.sfui18.getHeight() / 2f, -1);
            FontUtil.bonicon20.drawStringWithShadow(icon, x_var + 10 - FontUtil.bonicon20.getStringWidth(icon) / 2f, y + height / 2f - FontUtil.bonicon20.getHeight() / 2f, color);
        }

        @Override
        public long getCreationTime() {
            return time;
        }

        @Override
        public long getMaxAge() {
            return seconds.getValue() * 1000L;
        }
    }
}
