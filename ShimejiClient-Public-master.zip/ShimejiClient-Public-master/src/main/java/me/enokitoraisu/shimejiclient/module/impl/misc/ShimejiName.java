package me.enokitoraisu.shimejiclient.module.impl.misc;

import me.enokitoraisu.shimejiclient.ShimejiClient;
import me.enokitoraisu.shimejiclient.event.TextEvent;
import me.enokitoraisu.shimejiclient.manager.ListManager;
import me.enokitoraisu.shimejiclient.module.Category;
import me.enokitoraisu.shimejiclient.module.Module;
import me.enokitoraisu.shimejiclient.value.values.BooleanValue;
import me.enokitoraisu.shimejiclient.value.values.StringValue;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import org.lwjgl.input.Keyboard;

import java.util.Map;
import java.util.UUID;

@SuppressWarnings("unused")
public class ShimejiName extends Module {
    private final BooleanValue nickName = register(new BooleanValue("NickName", false));
    public BooleanValue self = register(new BooleanValue("Self", false));
    public BooleanValue protect = register(new BooleanValue("Protector", false, v -> !self.getValue()));
    public StringValue name = register(new StringValue("Name", "Me", v -> protect.getValue()));

    public ShimejiName() {
        super("ShimejiName", Category.MISC, Keyboard.KEY_NONE);
    }

    @SubscribeEvent
    public void onText(TextEvent event) {
        if (nickName.getValue()) {
            for (Map.Entry<UUID, ListManager.Nick> entry : ShimejiClient.listManager.nicknames.entrySet()) {
                ListManager.Nick nick = entry.getValue();
                if (event.getText().contains(nick.username)) {
                    event.setText(event.getText().replace(nick.username, nick.username + " (" + nick.nickname + ")"));
                }
            }
        }

        if (event.getText().contains(mc.getSession().getUsername())) {
            if (self.getValue())
                event.setText(event.getText().replace(mc.getSession().getUsername(), mc.getSession().getUsername() + " \u00A77(\u00A7aShimeji\u00A77)\u00A7r"));
            else if (protect.getValue())
                event.setText(event.getText().replace(mc.getSession().getUsername(), name.getValue()));
        }
    }
}
