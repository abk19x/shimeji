package me.enokitoraisu.shimejiclient.utils.renderer.newfont;

import java.awt.*;
import java.awt.font.GlyphVector;
import java.lang.ref.WeakReference;
import java.text.Bidi;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.WeakHashMap;

class StringCache {
    private final GlyphCache glyphCache;
    private final WeakHashMap<Key, Entry> stringCache = new WeakHashMap<>();
    private final WeakHashMap<String, Key> weakRefCache = new WeakHashMap<>();
    private final Key lookupKey = new Key();
    GlyphCache.Glyph[][] digitGlyphs = new GlyphCache.Glyph[4][];
    private boolean digitGlyphsReady = false;
    boolean antiAliasEnabled = false;
    private final Thread mainThread;
    public float size;

    private static class Key {
        public String str;

        @Override
        public int hashCode() {
            int code = 0, length = str.length();

            boolean colorCode = false;

            for (int index = 0; index < length; index++) {
                char c = str.charAt(index);
                if (c >= '0' && c <= '9' && !colorCode) {
                    c = '0';
                }
                code = (code * 31) + c;
                colorCode = (c == '\u00A7');
            }

            return code;
        }

        @Override
        public boolean equals(Object o) {
            if (o == null) {
                return false;
            }

            String other = o.toString();
            int length = str.length();

            if (length != other.length()) {
                return false;
            }

            boolean colorCode = false;

            for (int index = 0; index < length; index++) {
                char c1 = str.charAt(index);
                char c2 = other.charAt(index);

                if (c1 != c2 && (c1 < '0' || c1 > '9' || c2 < '0' || c2 > '9' || colorCode)) {
                    return false;
                }
                colorCode = (c1 == '\u00A7');
            }

            return true;
        }

        @Override
        public String toString() {
            return str;
        }
    }

    static class Entry {
        public WeakReference<Key> keyRef;
        public float advance;
        public GlyphCache.Glyph[] glyphs;
        public ColorCode[] colors;
        public boolean specialRender;
    }

    static class ColorCode implements Comparable<Integer> {
        public static final byte UNDERLINE = 1;
        public static final byte STRIKETHROUGH = 2;
        public int stringIndex;
        public int stripIndex;
        public byte fontStyle;
        public byte colorCode;
        public byte renderStyle;

        @Override
        public int compareTo(Integer i) {
            return Integer.compare(stringIndex, i);
        }
    }

    public StringCache() {
        mainThread = Thread.currentThread();
        glyphCache = new GlyphCache();
    }

    public StringCache(float fontSize, boolean antiAlias, String name) {
        this();
        size = fontSize;
        setFont(fontSize, antiAlias, name);
    }

    public void clear() {
        glyphCache.clear();
    }

    private void setFont(float fontSize, boolean antiAlias, String name) {
        glyphCache.setFont(fontSize, antiAlias, name);
        antiAliasEnabled = antiAlias;
        weakRefCache.clear();
        stringCache.clear();

        cacheDightGlyphs();
    }

    private void cacheDightGlyphs() {
        digitGlyphsReady = false;
        digitGlyphs[Font.PLAIN] = cacheString("0123456789").glyphs;
        digitGlyphs[Font.BOLD] = cacheString("\u00A7l0123456789").glyphs;
        digitGlyphs[Font.ITALIC] = cacheString("\u00A7o0123456789").glyphs;
        digitGlyphs[Font.BOLD | Font.ITALIC] = cacheString("\u00A7l\u00A7o0123456789").glyphs;
        digitGlyphsReady = true;
    }

    Entry cacheString(String str) {
        Key key;
        Entry entry = null;

        if (mainThread == Thread.currentThread()) {
            lookupKey.str = str;
            entry = stringCache.get(lookupKey);
        }
        if (entry == null) {
            char[] text = str.toCharArray();
            entry = new Entry();
            int length = stripColorCodes(entry, str, text);
            List<GlyphCache.Glyph> glyphList = new ArrayList<>();
            entry.advance = layoutBidiString(glyphList, text, 0, length, entry.colors);
            entry.glyphs = new GlyphCache.Glyph[glyphList.size()];
            entry.glyphs = glyphList.toArray(entry.glyphs);
            Arrays.sort(entry.glyphs);

            int colorIndex = 0, shift = 0;
            for (int glyphIndex = 0; glyphIndex < entry.glyphs.length; glyphIndex++) {
                GlyphCache.Glyph glyph = entry.glyphs[glyphIndex];

                while (colorIndex < entry.colors.length && glyph.stringIndex + shift >= entry.colors[colorIndex].stringIndex) {
                    shift += 2;
                    colorIndex++;
                }
                glyph.stringIndex += shift;
            }

            if (mainThread == Thread.currentThread()) {
                key = new Key();

                key.str = str;
                entry.keyRef = new WeakReference<>(key);
                stringCache.put(key, entry);
            }
        }

        if (mainThread == Thread.currentThread()) {
            Key oldKey = entry.keyRef.get();
            if (oldKey != null) {
                //weakRefCache.put(str, oldKey);
            }
            lookupKey.str = null;
        }

        return entry;
    }

    private int stripColorCodes(Entry cacheEntry, String str, char[] text) {
        List<ColorCode> colorList = new ArrayList<>();
        int start = 0, shift = 0, next;

        byte fontStyle = Font.PLAIN;
        byte renderStyle = 0;
        byte colorCode = -1;

        while ((next = str.indexOf('\u00A7', start)) != -1 && next + 1 < str.length()) {
            System.arraycopy(text, next - shift + 2, text, next - shift, text.length - next - 2);

            int code = "0123456789abcdefklmnor".indexOf(Character.toLowerCase(str.charAt(next + 1)));
            switch (code) {
                case 16:
                    break;

                case 17:
                    fontStyle |= Font.BOLD;
                    break;

                case 18:
                    renderStyle |= ColorCode.STRIKETHROUGH;
                    cacheEntry.specialRender = true;
                    break;

                case 19:
                    renderStyle |= ColorCode.UNDERLINE;
                    cacheEntry.specialRender = true;
                    break;

                case 20:
                    fontStyle |= Font.ITALIC;
                    break;

                case 21:
                    fontStyle = Font.PLAIN;
                    renderStyle = 0;
                    break;

                default:
                    if (code >= 0) {
                        colorCode = (byte) code;
                        fontStyle = Font.PLAIN;
                        renderStyle = 0;
                    }
                    break;
            }

            ColorCode entry = new ColorCode();
            entry.stringIndex = next;
            entry.stripIndex = next - shift;
            entry.colorCode = colorCode;
            entry.fontStyle = fontStyle;
            entry.renderStyle = renderStyle;
            colorList.add(entry);

            start = next + 2;
            shift += 2;
        }

        cacheEntry.colors = new ColorCode[colorList.size()];
        cacheEntry.colors = colorList.toArray(cacheEntry.colors);

        return text.length - shift;
    }

    private float layoutBidiString(List<GlyphCache.Glyph> glyphList, char[] text, int start, int limit, ColorCode[] colors) {
        float advance = 0;

        if (Bidi.requiresBidi(text, start, limit)) {
            Bidi bidi = new Bidi(text, start, null, 0, limit - start, Bidi.DIRECTION_DEFAULT_LEFT_TO_RIGHT);

            if (bidi.isRightToLeft()) {
                return layoutStyle(glyphList, text, start, limit, Font.LAYOUT_RIGHT_TO_LEFT, advance, colors);
            }

            else {
                int runCount = bidi.getRunCount();
                byte[] levels = new byte[runCount];
                Integer[] ranges = new Integer[runCount];

                for (int index = 0; index < runCount; index++) {
                    levels[index] = (byte) bidi.getRunLevel(index);
                    ranges[index] = index;
                }
                Bidi.reorderVisually(levels, 0, ranges, 0, runCount);

                for (int visualIndex = 0; visualIndex < runCount; visualIndex++) {
                    int logicalIndex = ranges[visualIndex];

                    int layoutFlag = (bidi.getRunLevel(logicalIndex) & 1) == 1 ? Font.LAYOUT_RIGHT_TO_LEFT : Font.LAYOUT_LEFT_TO_RIGHT;
                    advance = layoutStyle(glyphList, text, start + bidi.getRunStart(logicalIndex), start + bidi.getRunLimit(logicalIndex),
                            layoutFlag, advance, colors);
                }
            }

            return advance;
        }

        else {
            return layoutStyle(glyphList, text, start, limit, Font.LAYOUT_LEFT_TO_RIGHT, advance, colors);
        }
    }

    private float layoutStyle(List<GlyphCache.Glyph> glyphList, char[] text, int start, int limit, int layoutFlags, float advance, ColorCode[] colors) {
        int currentFontStyle = Font.PLAIN;

        int colorIndex = Arrays.binarySearch(colors, start);

        if (colorIndex < 0) {
            colorIndex = -colorIndex - 2;
        }

        while (start < limit) {
            int next = limit;

            while (colorIndex >= 0 && colorIndex < (colors.length - 1) && colors[colorIndex].stripIndex == colors[colorIndex + 1].stripIndex) {
                colorIndex++;
            }

            if (colorIndex >= 0 && colorIndex < colors.length) {
                currentFontStyle = colors[colorIndex].fontStyle;
            }

            while (++colorIndex < colors.length) {
                if (colors[colorIndex].fontStyle != currentFontStyle) {
                    next = colors[colorIndex].stripIndex;
                    break;
                }
            }

            advance = layoutString(glyphList, text, start, next, layoutFlags, advance, currentFontStyle);
            start = next;
        }

        return advance;
    }

    private float layoutString(List<GlyphCache.Glyph> glyphList, char[] text, int start, int limit, int layoutFlags, float advance, int style) {
        if (digitGlyphsReady) {
            for (int index = start; index < limit; index++) {
                if (text[index] >= '0' && text[index] <= '9') {
                    text[index] = '0';
                }
            }
        }

        while (start < limit) {
            Font font = glyphCache.lookupFont(text, start, limit, style);
            int next = font.canDisplayUpTo(text, start, limit);

            if (next == -1) {
                next = limit;
            }

            if (next == start) {
                next++;
            }

            advance = layoutFont(glyphList, text, start, next, layoutFlags, advance, font);
            start = next;
        }

        return advance;
    }

    private float layoutFont(List<GlyphCache.Glyph> glyphList, char[] text, int start, int limit, int layoutFlags, float advance, Font font) {
        if (mainThread == Thread.currentThread()) {
            glyphCache.cacheGlyphs(font, text, start, limit, layoutFlags);
        }

        GlyphVector vector = glyphCache.layoutGlyphVector(font, text, start, limit, layoutFlags);

        GlyphCache.Glyph glyph = null;
        int numGlyphs = vector.getNumGlyphs();
        for (int index = 0; index < numGlyphs; index++) {
            Point position = vector.getGlyphPixelBounds(index, null, advance, 0).getLocation();

            if (glyph != null) {
                glyph.advance = position.x - glyph.x;
            }

            glyph = new GlyphCache.Glyph();
            glyph.stringIndex = start + vector.getGlyphCharIndex(index);
            glyph.texture = glyphCache.lookupGlyph(font, vector.getGlyphCode(index));
            glyph.x = position.x;
            glyph.y = position.y;
            glyphList.add(glyph);
        }

        advance += vector.getGlyphPosition(numGlyphs).getX();
        if (glyph != null) {
            glyph.advance = advance - glyph.x;
        }

        return advance;
    }
}