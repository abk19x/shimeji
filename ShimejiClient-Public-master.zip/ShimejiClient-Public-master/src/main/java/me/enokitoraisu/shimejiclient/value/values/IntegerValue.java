package me.enokitoraisu.shimejiclient.value.values;

import me.enokitoraisu.shimejiclient.value.ValueBase;
import net.minecraft.util.math.MathHelper;

import java.util.function.Predicate;

public class IntegerValue extends ValueBase<Integer> {
    private Integer min, max;

    public IntegerValue(String name, Integer value, Integer min, Integer max) {
        this(name, value, min, max, v -> true);
    }

    public IntegerValue(String name, Integer value, Integer min, Integer max, Predicate<Integer> visibility) {
        super(name, value, visibility);
        this.min = min;
        this.max = max;
    }

    @Override
    public void setValue(Integer value) {
        this.value = MathHelper.clamp(value, min, max);
    }

    public Integer getMin() {
        return min;
    }

    public void setMin(Integer min) {
        this.min = min;
    }

    public Integer getMax() {
        return max;
    }

    public void setMax(Integer max) {
        this.max = max;
    }
}
