package me.enokitoraisu.shimejiclient.utils.math;

public class Widget<T extends Integer> {
    private T x;
    private T y;
    private T width;
    private T height;

    public Widget(T x, T y, T width, T height) {
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
    }

    public static <T extends Integer> Widget<T> createWidget(T y, T x, T width, T height) {
        return new Widget<>(x, y, width, height);
    }

    public T getX() {
        return x;
    }

    public void setX(T x) {
        this.x = x;
    }

    public T getY() {
        return y;
    }

    public void setY(T y) {
        this.y = y;
    }

    public T getWidth() {
        return width;
    }

    public void setWidth(T width) {
        this.width = width;
    }

    public T getHeight() {
        return height;
    }

    public void setHeight(T height) {
        this.height = height;
    }
}
