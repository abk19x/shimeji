package me.enokitoraisu.shimejiclient.module.impl.combat;

import me.enokitoraisu.shimejiclient.module.Category;
import me.enokitoraisu.shimejiclient.module.Module;
import me.enokitoraisu.shimejiclient.module.impl.hud.NewNotifications;
import me.enokitoraisu.shimejiclient.utils.entity.BlockUtil;
import me.enokitoraisu.shimejiclient.utils.entity.InventoryUtil;
import me.enokitoraisu.shimejiclient.value.values.BooleanValue;
import me.enokitoraisu.shimejiclient.value.values.FloatValue;
import me.enokitoraisu.shimejiclient.value.values.ModeValue;
import net.minecraft.block.BlockEnderChest;
import net.minecraft.block.BlockObsidian;
import net.minecraft.block.BlockPistonBase;
import net.minecraft.network.play.client.CPacketEntityAction;
import net.minecraft.network.play.client.CPacketPlayer;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;
import org.lwjgl.input.Keyboard;

import static net.minecraft.network.play.client.CPacketEntityAction.Action.START_SNEAKING;
import static net.minecraft.network.play.client.CPacketEntityAction.Action.STOP_SNEAKING;

@SuppressWarnings("unused")
public class Burrow extends Module {
    public BooleanValue rotate = this.register(new BooleanValue("Rotate", false));
    public FloatValue offset = this.register(new FloatValue("Offset", 2.0F, -20.0F, 20.0F));
    public BooleanValue sneak = this.register(new BooleanValue("Sneak", false));
    public ModeValue block = this.register(new ModeValue("Block", "Obsidian", "Obsidian", "EnderChest", "Piston"));
    public BooleanValue silentSwitch = this.register(new BooleanValue("SilentSwitch", false));
    private BlockPos originalPos;
    private int oldSlot = -1;
    private Class blockClass;

    public Burrow() {
        super("Burrow", Category.COMBAT, Keyboard.KEY_NONE);
    }

    @Override
    public void onEnable() {
        originalPos = new BlockPos(mc.player.posX, mc.player.posY, mc.player.posZ);
        oldSlot = mc.player.inventory.currentItem;
    }

    @Override
    public void onTick() {
        if (block.getValue().equals("Obsidian")) blockClass = BlockObsidian.class;
        if (block.getValue().equals("EnderChest")) blockClass = BlockEnderChest.class;
        if (block.getValue().equals("Piston")) blockClass = BlockPistonBase.class;
        if (InventoryUtil.findHotbarBlock(blockClass) == -1) {
            sendNotify("Can't find " + block.getValue().toLowerCase() + " in hotbar!", NewNotifications.Type.ERROR);
            this.toggle();
        } else {
            InventoryUtil.switchToSlot(InventoryUtil.findHotbarBlock(blockClass), silentSwitch.getValue());
            mc.player.connection.sendPacket(new CPacketPlayer.Position(mc.player.posX, mc.player.posY + 0.41999998688698D, mc.player.posZ, true));
            mc.player.connection.sendPacket(new CPacketPlayer.Position(mc.player.posX, mc.player.posY + 0.7531999805211997D, mc.player.posZ, true));
            mc.player.connection.sendPacket(new CPacketPlayer.Position(mc.player.posX, mc.player.posY + 1.00133597911214D, mc.player.posZ, true));
            mc.player.connection.sendPacket(new CPacketPlayer.Position(mc.player.posX, mc.player.posY + 1.16610926093821D, mc.player.posZ, true));
            boolean sneaking = mc.player.isSneaking();
            if (sneak.getValue()) {
                if (sneaking) {
                    mc.player.connection.sendPacket(new CPacketEntityAction(mc.player, START_SNEAKING));
                }
            }
            BlockUtil.placeBlock(originalPos, EnumHand.MAIN_HAND, rotate.getValue(), true, false);
            mc.player.connection.sendPacket(new CPacketPlayer.Position(mc.player.posX, mc.player.posY + offset.getValue(), mc.player.posZ, mc.player.onGround));
            InventoryUtil.switchToSlot(oldSlot, silentSwitch.getValue());
            if (sneak.getValue()) {
                if (sneaking) {
                    mc.player.connection.sendPacket(new CPacketEntityAction(mc.player, STOP_SNEAKING));
                }
            }
            this.toggle();
        }
    }
}
