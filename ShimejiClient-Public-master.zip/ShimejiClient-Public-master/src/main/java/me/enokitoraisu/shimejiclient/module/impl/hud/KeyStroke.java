package me.enokitoraisu.shimejiclient.module.impl.hud;

import me.enokitoraisu.shimejiclient.module.Category;
import me.enokitoraisu.shimejiclient.module.HudModule;
import me.enokitoraisu.shimejiclient.utils.renderer.RenderUtil;
import me.enokitoraisu.shimejiclient.utils.renderer.font.FontUtil;
import me.enokitoraisu.shimejiclient.value.values.IntegerValue;
import net.minecraft.client.settings.GameSettings;
import org.lwjgl.input.Keyboard;

@SuppressWarnings("unused")
public class KeyStroke extends HudModule {
    public IntegerValue offsetSetting = register(new IntegerValue("Offset", 1, 0, 5));
    public IntegerValue scaleSetting = register(new IntegerValue("Scale", 10, 10, 30));

    public KeyStroke() {
        super("KeyStroke", Category.HUD, Keyboard.KEY_NONE, 1, 1, 10, 10);
    }

    @Override
    public boolean drawScreen() {
        int x = offsetSetting.getValue() + getX();
        int y = offsetSetting.getValue() + getY();
        setWidth(scaleSetting.getValue() * 3 + offsetSetting.getValue() * 2);
        setHeight(scaleSetting.getValue() * 3 + offsetSetting.getValue() * 2);

        int scale = scaleSetting.getValue();
        int offset = offsetSetting.getValue();

        GameSettings gameSettings = mc.gameSettings;

        RenderUtil.drawRect(x + scale, y - offset, scale, scale, gameSettings.keyBindForward.isKeyDown() ? 0xbf000000 : 0x80000000);
        FontUtil.sfui20.drawStringWithShadow(
                "W",
                (x + scale) - (FontUtil.sfui20.getStringWidth("W") / 2f - scale / 2f),
                y - offset - (FontUtil.sfui20.getHeight() / 2f - scale / 2f),
                -1
        );

        RenderUtil.drawRect(x - offset, y + scale, scale, scale, gameSettings.keyBindLeft.isKeyDown() ? 0xbf000000 : 0x80000000);
        FontUtil.sfui20.drawStringWithShadow(
                "A",
                (x - offset) - (FontUtil.sfui20.getStringWidth("A") / 2f - scale / 2f),
                (y + scale) - (FontUtil.sfui20.getHeight() / 2f - scale / 2f),
                -1
        );

        RenderUtil.drawRect(x + scale, y + scale, scale, scale, gameSettings.keyBindBack.isKeyDown() ? 0xbf000000 : 0x80000000);
        FontUtil.sfui20.drawStringWithShadow(
                "S",
                (x + scale) - (FontUtil.sfui20.getStringWidth("S") / 2f - scale / 2f),
                (y + scale) - (FontUtil.sfui20.getHeight() / 2f - scale / 2f),
                -1
        );

        RenderUtil.drawRect(x + scale * 2 + offset, y + scale, scale, scale, gameSettings.keyBindRight.isKeyDown() ? 0xbf000000 : 0x80000000);
        FontUtil.sfui20.drawStringWithShadow(
                "D",
                (x + scale * 2 + offset) - (FontUtil.sfui20.getStringWidth("D") / 2f - scale / 2f),
                (y + scale) - (FontUtil.sfui20.getHeight() / 2f - scale / 2f),
                -1
        );

        RenderUtil.drawRect(x - offset, (y + offset) + scale * 2, scale * 3 + offset * 2, scale, gameSettings.keyBindJump.isKeyDown() ? 0xbf000000 : 0x80000000);
        FontUtil.sfui20.drawStringWithShadow(
                "-",
                (x + scale) - (FontUtil.sfui20.getStringWidth("-") / 2f - scale / 2f),
                (y + scale * 2 + offset) - (FontUtil.sfui20.getHeight() / 2f - scale / 2f),
                -1
        );
        return true;
    }
}
