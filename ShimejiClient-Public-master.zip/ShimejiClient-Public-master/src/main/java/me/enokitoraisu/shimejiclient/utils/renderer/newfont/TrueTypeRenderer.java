package me.enokitoraisu.shimejiclient.utils.renderer.newfont;

import com.mojang.realmsclient.gui.ChatFormatting;
import net.minecraft.client.renderer.BufferBuilder;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import org.lwjgl.opengl.GL11;

import java.awt.*;

public class TrueTypeRenderer implements IFontRenderer {
    private static final int BASELINE_OFFSET = 7;
    private static final int UNDERLINE_OFFSET = 1;
    private static final int UNDERLINE_THICKNESS = 2;
    private static final int STRIKETHROUGH_OFFSET = -6;
    private static final int STRIKETHROUGH_THICKNESS = 2;

    private final StringCache cache;

    /**
     * {@link ChatFormatting#values()}
     */
    private final int[] formattedColorTable = new int[]{0x0, 0xAA, 0xAA00, 0xAAAA, 0xAA0000, 0xAA00AA, 0xFFAA00, 0xAAAAAA, 0x555555, 0x5555FF, 0x55FF55, 0x55FFFF, 0xFF5555, 0xFF55FF, 0xFFFF55, 0xFFFFFF};

    TrueTypeRenderer(StringCache cache) {
        this.cache = cache;
    }

    public void init() {
    }

    public void clear() {
        cache.clear();
    }

    public float getHeight() {
        return cache.size / 2F;
    }

    public float drawStringWithFullShadow(String str, float startX, float startY, int color, int align) {
        for (int i = -2; i <= 2; i++) {
            for (int j = -2; j <= 2; j++) {
                float x = i / 2F, y = j / 2F;
                drawString(str, startX + x, startY + y, (color & 0xFCFCFC) >> 2 | color & 0xFF000000, align);
            }
        }
        return drawString(str, startX, startY, color, align);
    }

    public float drawStringWithShadow(String str, float startX, float startY, int color, int align) {
        drawString(str, startX + 0.5F, startY + 0.5F, (color & 0xFCFCFC) >> 2 | color & 0xFF000000, align);
        return drawString(str, startX, startY, color, align);
    }

    @Override
    public float drawString(String str, float startX, float startY, int color, float align) {
        if (str == null || str.isEmpty()) {
            return 0;
        }

        GL11.glTexEnvi(GL11.GL_TEXTURE_ENV, GL11.GL_TEXTURE_ENV_MODE, GL11.GL_MODULATE);

        StringCache.Entry entry = cache.cacheString(str);

        startY += BASELINE_OFFSET;

        GlStateManager.color((color >> 16 & 0xff) / 255F, (color >> 8 & 0xff) / 255F, (color & 0xff) / 255F);

        if (cache.antiAliasEnabled) {
            GlStateManager.enableBlend();
            GlStateManager.blendFunc(GL11.GL_SRC_ALPHA, GL11.GL_ONE_MINUS_SRC_ALPHA);
        }
        startX = startX - entry.advance * align;

        Tessellator tessellator = Tessellator.getInstance();
        BufferBuilder renderer = tessellator.getBuffer();

        int fontStyle = Font.PLAIN;

        for (int glyphIndex = 0, colorIndex = 0; glyphIndex < entry.glyphs.length; glyphIndex++) {
            while (colorIndex < entry.colors.length && entry.glyphs[glyphIndex].stringIndex >= entry.colors[colorIndex].stringIndex) {
                color = formattedColorTable[entry.colors[colorIndex].colorCode];
                fontStyle = entry.colors[colorIndex].fontStyle;
                colorIndex++;
            }

            GlyphCache.Glyph glyph = entry.glyphs[glyphIndex];
            GlyphCache.Entry texture = glyph.texture;
            int glyphX = glyph.x;

            char c = str.charAt(glyph.stringIndex);
            if (c >= '0' && c <= '9') {
                int oldWidth = texture.width;
                texture = cache.digitGlyphs[fontStyle][c - '0'].texture;
                int newWidth = texture.width;
                glyphX += (oldWidth - newWidth) >> 1;
            }

            float x1 = startX + (glyphX) / 2.0F;
            float x2 = startX + (glyphX + texture.width) / 2.0F;
            float y1 = startY + (glyph.y) / 2.0F;
            float y2 = startY + (glyph.y + texture.height) / 2.0F;

            int a = color >> 24 & 0xff;
            int r = color >> 16 & 0xff;
            int g = color >> 8 & 0xff;
            int b = color & 0xff;

            renderer.begin(7, DefaultVertexFormats.POSITION_TEX_COLOR);
            GlStateManager.bindTexture(texture.textureName);

            renderer.pos(x1, y1, 0).tex(texture.u1, texture.v1 - 0.002F).color(r, g, b, a).endVertex();
            renderer.pos(x1, y2, 0).tex(texture.u1, texture.v2).color(r, g, b, a).endVertex();
            renderer.pos(x2, y2, 0).tex(texture.u2, texture.v2).color(r, g, b, a).endVertex();
            renderer.pos(x2, y1, 0).tex(texture.u2, texture.v1 - 0.002F).color(r, g, b, a).endVertex();

            tessellator.draw();
        }

        if (entry.specialRender) {
            int renderStyle = 0;

            GlStateManager.disableTexture2D();
            renderer.begin(7, DefaultVertexFormats.POSITION_COLOR);

            for (int glyphIndex = 0, colorIndex = 0; glyphIndex < entry.glyphs.length; glyphIndex++) {
                while (colorIndex < entry.colors.length && entry.glyphs[glyphIndex].stringIndex >= entry.colors[colorIndex].stringIndex) {
                    renderStyle = entry.colors[colorIndex].renderStyle;
                    colorIndex++;
                }

                GlyphCache.Glyph glyph = entry.glyphs[glyphIndex];

                float glyphSpace = glyph.advance - glyph.texture.width;

                int a = color >> 24 & 0xff;
                int r = color >> 16 & 0xff;
                int g = color >> 8 & 0xff;
                int b = color & 0xff;

                if ((renderStyle & StringCache.ColorCode.UNDERLINE) != 0) {
                    drawI1(startX, startY, renderer, glyph, glyphSpace, a, r, g, b, UNDERLINE_OFFSET, UNDERLINE_THICKNESS);
                }

                if ((renderStyle & StringCache.ColorCode.STRIKETHROUGH) != 0) {
                    drawI1(startX, startY, renderer, glyph, glyphSpace, a, r, g, b, STRIKETHROUGH_OFFSET, STRIKETHROUGH_THICKNESS);
                }
            }

            tessellator.draw();
            GlStateManager.enableTexture2D();
        }

        return entry.advance / 2;
    }

    private void drawI1(float startX, float startY, BufferBuilder renderer, GlyphCache.Glyph glyph, float glyphSpace, int a, int r, int g, int b, int underlineOffset, int underlineThickness) {
        float x1 = startX + (glyph.x - glyphSpace) / 2.0F;
        float x2 = startX + (glyph.x + glyph.advance) / 2.0F;
        float y1 = startY + (underlineOffset) / 2.0F;
        float y2 = startY + (underlineOffset + underlineThickness) / 2.0F;

        renderer.pos(x1, y1 - 0.1F, 0).color(r, g, b, a).endVertex();
        renderer.pos(x1, y2, 0).color(r, g, b, a).endVertex();
        renderer.pos(x2, y2, 0).color(r, g, b, a).endVertex();
        renderer.pos(x2, y1, 0).color(r, g, b, a).endVertex();
    }

    @SuppressWarnings("unused")
    @Override
    public float getStringWidth(String str) {
        if (str == null || str.isEmpty()) {
            return 0;
        }

        StringCache.Entry entry = cache.cacheString(str);

        return entry.advance / 2;
    }

    private int sizeString(String str, float width, boolean breakAtSpaces) {
        if (str == null || str.isEmpty()) {
            return 0;
        }

        width += width;

        GlyphCache.Glyph[] glyphs = cache.cacheString(str).glyphs;

        int wsIndex = -1;

        float advance = 0;
        int index = 0;
        while (index < glyphs.length && advance <= width) {
            if (breakAtSpaces) {
                char c = str.charAt(glyphs[index].stringIndex);
                if (c == ' ') {
                    wsIndex = index;
                } else if (c == '\n') {
                    wsIndex = index;
                    break;
                }
            }

            float nextAdvance = advance + glyphs[index].advance;
            if (nextAdvance <= width) {
                advance = nextAdvance;
                index++;
            } else {
                break;
            }
        }

        if (index < glyphs.length && wsIndex != -1 && wsIndex < index) {
            index = wsIndex;
        }

        return index < glyphs.length ? glyphs[index].stringIndex : str.length();
    }

    @SuppressWarnings("unused")
    @Override
    public int sizeStringToWidth(String str, float width) {
        return sizeString(str, width, false);
    }

    @SuppressWarnings("unused")
    @Override
    public String trimStringToWidth(String str, float width, boolean reverse) {
        if (reverse)
            str = new StringBuilder(str).reverse().toString();

        int length = sizeString(str, width, false);
        str = str.substring(0, length);

        if (reverse) {
            str = (new StringBuilder(str)).reverse().toString();
        }

        return str;
    }
}