package me.enokitoraisu.shimejiclient.utils.renderer;

public class BonIcon {
    //SpotifyStatus
    public static String PREVIOUS = "!";
    public static String NEXT = "\"";
    public static String PLAY = "2";
    public static String PAUSE = "4";
    public static String REPEAT = "5";
    public static String REPEAT_ON = "6";
    public static String REPEAT_ON_ONE = "7";
    public static String SHUFFLE = "8";
    public static String SHUFFLE_ON = "9";

    public static String CHECKBOX_LINE_BLANK = "a";
    public static String ADD = "b";
    public static String ADD_CIRCLE = "c";
    public static String ADD_BOX = "d";
    public static String CHECK = "e";
    public static String CHECK_CIRCLE = "f";
    public static String CHECK_BOX = "g";
    public static String CLOSE = "h";
    public static String CANCEL = "i";
    public static String DISABLE_DEFAULT = "j";
    public static String DELETE = "k";
    public static String FAVORITE = "l";
    public static String DOWNLOAD = "m";
    public static String PERSON = "n";
    public static String GROUP = "o";
    public static String GROUPS = "p";
    public static String PUBLIC = "q";
    public static String OPEN_NEW = "r";
    public static String POWER = "s";
    public static String REFRESH = "t";
    public static String SETTINGS = "u";
    public static String VISIBILITY = "v";
    public static String WARNING = "w";
    public static String INFO = "x";
    public static String LEFT_MOUSE = "y";
    public static String RIGHT_MOUSE = "z";

    public static String SWORDS = "A";
    public static String HOME = "B";
    public static String STAR = "C";
    public static String BOLT = "D";
    public static String RUN = "E";
    public static String WALK = "F";
    public static String Transfer_Within_Station = "G";
    public static String LIST_ALT = "H";
    public static String LIST = "I";
    public static String REORDER = "J";
    public static String SCREENSHOT = "K";
    public static String DESKTOP_WINDOWS = "L";
    public static String TV = "M";
    public static String APPS = "N";
    public static String MORE_VERTICAL = "O";
    //public static String ? = "P";
    public static String TUNE = "Q";
    public static String ARROW_BACK = "R";
    public static String ARROW_FORWARD = "S";
    public static String ARROW_UPWARD = "T";
    public static String ARROW_DOWNWARD = "U";
    public static String LOGOUT = "V";
    public static String LOGIN = "W";
    public static String EXPAND_LESS = "X";
    public static String EXPAND_MORE = "Y";
    public static String CIRCLE = "Z";
}
