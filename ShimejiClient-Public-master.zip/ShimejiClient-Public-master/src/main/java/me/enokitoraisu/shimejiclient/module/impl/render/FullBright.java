package me.enokitoraisu.shimejiclient.module.impl.render;

import me.enokitoraisu.shimejiclient.module.Category;
import me.enokitoraisu.shimejiclient.module.Module;
import me.enokitoraisu.shimejiclient.value.values.ModeValue;
import net.minecraft.init.MobEffects;
import net.minecraft.potion.PotionEffect;
import org.lwjgl.input.Keyboard;

@SuppressWarnings("unused")
public class FullBright extends Module {
    private final ModeValue mode = register(new ModeValue("Mode", "Gamma", "Gamma", "Effect"));
    private float lastGamma;

    public FullBright() {
        super("FullBright", Category.RENDER, Keyboard.KEY_NONE);
    }


    public void onEnable() {
        lastGamma = mc.gameSettings.gammaSetting;
    }

    public void onDisable() {
        mc.gameSettings.gammaSetting = this.lastGamma;
        mc.player.removeActivePotionEffect(MobEffects.NIGHT_VISION);
    }

    @Override
    public void onTick() {
        switch (mode.getValue()) {
            case "Gamma":
                mc.gameSettings.gammaSetting = 1000;
                break;
            case "Effect":
                mc.player.addPotionEffect(new PotionEffect(MobEffects.NIGHT_VISION, 1201, 0));
                break;
            default:
                throw new IllegalStateException("Unexpected value: " + mode.getValue());
        }
    }
}
