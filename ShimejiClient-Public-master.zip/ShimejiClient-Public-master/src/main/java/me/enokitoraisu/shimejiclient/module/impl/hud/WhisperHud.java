package me.enokitoraisu.shimejiclient.module.impl.hud;

import me.enokitoraisu.shimejiclient.event.PacketEvent;
import me.enokitoraisu.shimejiclient.module.Category;
import me.enokitoraisu.shimejiclient.module.HudModule;
import me.enokitoraisu.shimejiclient.utils.renderer.RenderUtil;
import me.enokitoraisu.shimejiclient.utils.renderer.font.FontUtil;
import me.enokitoraisu.shimejiclient.value.values.BooleanValue;
import net.minecraft.network.play.server.SPacketChat;
import net.minecraft.util.math.MathHelper;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import org.lwjgl.input.Keyboard;
import org.lwjgl.input.Mouse;

import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.regex.Pattern;

public class WhisperHud extends HudModule {
    private final BooleanValue timestamp = register(new BooleanValue("Timestamp", true));
    private final BooleanValue font = register(new BooleanValue("CustomFont", false));
    private final BooleanValue rect = register(new BooleanValue("Rect", true));
    private final CopyOnWriteArrayList<Message> messages = new CopyOnWriteArrayList<>();
    private int offset = 0;

    public WhisperHud() {
        super("WhisperHud", Category.HUD, Keyboard.KEY_NONE, 10, 10, 300, 153);
    }

    @Override
    public boolean drawScreen() {
        if (rect.getValue())
            RenderUtil.drawRect(getX(), getY(), getWidth(), getHeight(), 0x80000000);
        for (Message message : messages) {
            if (message.y - offset >= 0 && message.y < getHeight() + offset) {
                String formattedDateTime = DateTimeFormatter.ofPattern("HH:mm:ss").format(LocalDateTime.ofInstant(Instant.ofEpochMilli(message.time), ZoneId.systemDefault()));
                String text = (timestamp.getValue() ? "\u00A77[\u00A7f" + formattedDateTime + "\u00A77]\u00A7r " : "") + message.message;
                if (font.getValue()) {
                    FontUtil.sfui18.drawStringWithShadow(text, getX() + 1, getY() + 1 + message.y - offset, -1);
                } else {
                    mc.fontRenderer.drawStringWithShadow(text, getX() + 1, getY() + message.y - offset, -1);
                }
            }
        }

        return false;
    }

    @Override
    public void onEnable() {
        this.messages.clear();
        this.offset = 0;
    }

    @Override
    public void drawChatScreen(int mouseX, int mouseY) {
        if (messages.isEmpty()) return;
        if (getMaxHeight() - getHeight() < 0) return;
        if (bounding(mouseX, mouseY)) {
            int scroll = Mouse.getDWheel();
            if (scroll < 0) {
                offset += mc.fontRenderer.FONT_HEIGHT;
                offset = MathHelper.clamp(offset, 0, getMaxHeight() - getHeight());
            } else if (scroll > 0) {
                offset -= mc.fontRenderer.FONT_HEIGHT;
                offset = MathHelper.clamp(offset, 0, getMaxHeight());
            }
        }
    }

    public int getMaxHeight() {
        int y = 0;
        for (int i = 0; i < messages.size(); i++) {
            y += mc.fontRenderer.FONT_HEIGHT;
        }

        return y;
    }

    @SubscribeEvent
    public void onPacketReceived(PacketEvent.Receive event) {
        if (event.getPacket() instanceof SPacketChat) {
            if (event.isCanceled()) return;
            SPacketChat packet = (SPacketChat) event.getPacket();
            String msg = packet.getChatComponent().getUnformattedText();
            if (isMatch(msg)) {
                messages.add(new Message(packet.getChatComponent().getFormattedText(), -mc.fontRenderer.FONT_HEIGHT));
                messages.forEach(message -> message.y += mc.fontRenderer.FONT_HEIGHT);
                event.setCanceled(true);
            }
        }
    }

    /**
     * @link <a href="https://github.com/SpartanB312/Epsilon/blob/0ed8952ec69e8ad6791d26ffbfd607362cecf6a7/Client/src/main/kotlin/club/eridani/epsilon/client/util/text/MessageDetection.kt#L58-L64">Code By Epsilon</a>
     */
    public boolean isMatch(String msg) {
        return Pattern.compile("^To (.+?): (.+?)").matcher(msg).matches() ||
                Pattern.compile("^You whisper to (.+?): (.+?)").matcher(msg).matches() ||
                Pattern.compile("^(.+?) whispers to you?: (.+?)").matcher(msg).matches() ||
                Pattern.compile("^\\[?(.+?)( )?->( )?\\w+?]?( )?:? (.+?)").matcher(msg).matches() ||
                Pattern.compile("^From (.+?): (.+?)").matcher(msg).matches() ||
                Pattern.compile("^. (.+?) » \\w+? » (.+?)").matcher(msg).matches();
    }

    public static class Message {
        public final String message;
        public long time;
        public int y;

        public Message(String message, int y) {
            this.message = message;
            this.time = System.currentTimeMillis();
            this.y = y;
        }
    }
}
