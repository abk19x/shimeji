package me.enokitoraisu.shimejiclient.utils.renderer;

import me.enokitoraisu.shimejiclient.utils.interfaces.Util;
import me.enokitoraisu.shimejiclient.utils.renderer.font.FontUtil;
import me.enokitoraisu.shimejiclient.utils.renderer.font.MinecraftFontRenderer;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.RenderGlobal;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import org.lwjgl.opengl.GL11;

public class RenderUtil3D implements Util {
    public static void drawBox(BlockPos pos, int box_color, int outline_color, boolean box, boolean outline, float outline_width) {
        float box_red = (float) (box_color >> 16 & 0xFF) / 255.0f;
        float box_green = (float) (box_color >> 8 & 0xFF) / 255.0f;
        float box_blue = (float) (box_color & 0xFF) / 255.0f;
        float box_alpha = (float) (box_color >> 24 & 0xFF) / 255.0f;

        float outline_red = (float) (outline_color >> 16 & 0xFF) / 255.0f;
        float outline_green = (float) (outline_color >> 8 & 0xFF) / 255.0f;
        float outline_blue = (float) (outline_color & 0xFF) / 255.0f;
        float outline_alpha = (float) (outline_color >> 24 & 0xFF) / 255.0f;

        double x = pos.getX() - mc.getRenderManager().viewerPosX;
        double y = pos.getY() - mc.getRenderManager().viewerPosY;
        double z = pos.getZ() - mc.getRenderManager().viewerPosZ;

        AxisAlignedBB axisAlignedBB = new AxisAlignedBB(0, 0, 0, 1, 1, 1);

        GlStateManager.pushMatrix();
        GlStateManager.translate(x, y, z);
        GlStateManager.enableBlend();
        GlStateManager.disableDepth();
        GlStateManager.tryBlendFuncSeparate(770, 771, 0, 1);
        GlStateManager.disableTexture2D();
        GlStateManager.depthMask(false);
        GL11.glEnable(2848);
        GL11.glHint(3154, 4354);
        GL11.glLineWidth(outline_width);
        if (outline)
            RenderGlobal.drawSelectionBoundingBox(axisAlignedBB, outline_red, outline_green, outline_blue, outline_alpha);
        if (box) RenderGlobal.renderFilledBox(axisAlignedBB, box_red, box_green, box_blue, box_alpha);
        GL11.glDisable(2848);

        GlStateManager.enableDepth();
        GlStateManager.depthMask(true);
        GlStateManager.translate(-x, -y, -z);
        GlStateManager.enableTexture2D();
        GlStateManager.disableBlend();
        GlStateManager.popMatrix();
    }

    public static void drawCenterScaledBox(BlockPos pos, float scaleOffset, int[] color/*0:box, 1:outline*/) {
        float box_red = (float) (color[0] >> 16 & 0xFF) / 255.0f;
        float box_green = (float) (color[0] >> 8 & 0xFF) / 255.0f;
        float box_blue = (float) (color[0] & 0xFF) / 255.0f;
        float box_alpha = (float) (color[0] >> 24 & 0xFF) / 255.0f;

        float outline_red = (float) (color[1] >> 16 & 0xFF) / 255.0f;
        float outline_green = (float) (color[1] >> 8 & 0xFF) / 255.0f;
        float outline_blue = (float) (color[1] & 0xFF) / 255.0f;
        float outline_alpha = (float) (color[1] >> 24 & 0xFF) / 255.0f;

        double x = pos.getX() - mc.getRenderManager().viewerPosX;
        double y = pos.getY() - mc.getRenderManager().viewerPosY;
        double z = pos.getZ() - mc.getRenderManager().viewerPosZ;

        double minXoffset = 0.5 - scaleOffset * 0.5f;
        double minYoffset = 0.5 - scaleOffset * 0.5f;
        double minZoffset = 0.5 - scaleOffset * 0.5f;
        double maxXoffset = 0.5 + scaleOffset * 0.5f;
        double maxYoffset = 0.5 + scaleOffset * 0.5f;
        double maxZoffset = 0.5 + scaleOffset * 0.5f;

        AxisAlignedBB axisAlignedBB = new AxisAlignedBB(minXoffset, minYoffset, minZoffset, maxXoffset, maxYoffset, maxZoffset);

        GlStateManager.pushMatrix();
        GlStateManager.translate(x, y, z);
        GlStateManager.enableBlend();
        GlStateManager.disableDepth();
        GlStateManager.tryBlendFuncSeparate(770, 771, 0, 1);
        GlStateManager.disableTexture2D();
        GlStateManager.depthMask(false);
        GL11.glEnable(2848);
        GL11.glHint(3154, 4354);
        GL11.glLineWidth(2.0f);
        RenderGlobal.drawSelectionBoundingBox(axisAlignedBB, outline_red, outline_green, outline_blue, outline_alpha);
        RenderGlobal.renderFilledBox(axisAlignedBB, box_red, box_green, box_blue, box_alpha);
        GL11.glDisable(2848);
        GlStateManager.enableDepth();
        GlStateManager.depthMask(true);
        GlStateManager.translate(-x, -y, -z);
        GlStateManager.enableTexture2D();
        GlStateManager.disableBlend();
        GlStateManager.popMatrix();
    }

    public static void drawReverseCenterScaledBox(BlockPos pos, float scaleOffset, int[] color/*0:box, 1:outline*/) {
        float box_red = (float) (color[0] >> 16 & 0xFF) / 255.0f;
        float box_green = (float) (color[0] >> 8 & 0xFF) / 255.0f;
        float box_blue = (float) (color[0] & 0xFF) / 255.0f;
        float box_alpha = (float) (color[0] >> 24 & 0xFF) / 255.0f;

        float outline_red = (float) (color[1] >> 16 & 0xFF) / 255.0f;
        float outline_green = (float) (color[1] >> 8 & 0xFF) / 255.0f;
        float outline_blue = (float) (color[1] & 0xFF) / 255.0f;
        float outline_alpha = (float) (color[1] >> 24 & 0xFF) / 255.0f;

        double x = pos.getX() - mc.getRenderManager().viewerPosX;
        double y = pos.getY() - mc.getRenderManager().viewerPosY;
        double z = pos.getZ() - mc.getRenderManager().viewerPosZ;

        AxisAlignedBB axisAlignedBB = new AxisAlignedBB(1.0 - scaleOffset, 1.0 - scaleOffset, 1.0 - scaleOffset, 1.0 - scaleOffset, 1.0 - scaleOffset, 1.0 - scaleOffset);

        GlStateManager.pushMatrix();
        GlStateManager.translate(x, y, z);
        GlStateManager.enableBlend();
        GlStateManager.disableDepth();
        GlStateManager.tryBlendFuncSeparate(770, 771, 0, 1);
        GlStateManager.disableTexture2D();
        GlStateManager.depthMask(false);
        GL11.glEnable(2848);
        GL11.glHint(3154, 4354);
        GL11.glLineWidth(2.0f);
        RenderGlobal.drawSelectionBoundingBox(axisAlignedBB, outline_red, outline_green, outline_blue, outline_alpha);
        RenderGlobal.renderFilledBox(axisAlignedBB, box_red, box_green, box_blue, box_alpha);
        GL11.glDisable(2848);
        GlStateManager.enableDepth();
        GlStateManager.depthMask(true);
        GlStateManager.translate(-x, -y, -z);
        GlStateManager.enableTexture2D();
        GlStateManager.disableBlend();
        GlStateManager.popMatrix();
    }

    public static void drawHeightScaledBox(BlockPos pos, float height, int[] color/*0:box, 1:outline*/) {
        float box_red = (float) (color[0] >> 16 & 0xFF) / 255.0f;
        float box_green = (float) (color[0] >> 8 & 0xFF) / 255.0f;
        float box_blue = (float) (color[0] & 0xFF) / 255.0f;
        float box_alpha = (float) (color[0] >> 24 & 0xFF) / 255.0f;

        float outline_red = (float) (color[1] >> 16 & 0xFF) / 255.0f;
        float outline_green = (float) (color[1] >> 8 & 0xFF) / 255.0f;
        float outline_blue = (float) (color[1] & 0xFF) / 255.0f;
        float outline_alpha = (float) (color[1] >> 24 & 0xFF) / 255.0f;

        double x = pos.getX() - mc.getRenderManager().viewerPosX;
        double y = pos.getY() - mc.getRenderManager().viewerPosY;
        double z = pos.getZ() - mc.getRenderManager().viewerPosZ;

        AxisAlignedBB axisAlignedBB = new AxisAlignedBB(0, 0, 0, 1, height, 1);

        GlStateManager.pushMatrix();
        GlStateManager.translate(x, y, z);
        GlStateManager.enableBlend();
        GlStateManager.disableDepth();
        GlStateManager.tryBlendFuncSeparate(770, 771, 0, 1);
        GlStateManager.disableTexture2D();
        GlStateManager.depthMask(false);
        GL11.glEnable(GL11.GL_LINE_SMOOTH);
        GL11.glHint(GL11.GL_LINE_SMOOTH_HINT, GL11.GL_NICEST);
        GL11.glLineWidth(2.0f);
        RenderGlobal.drawSelectionBoundingBox(axisAlignedBB, outline_red, outline_green, outline_blue, outline_alpha);
        RenderGlobal.renderFilledBox(axisAlignedBB, box_red, box_green, box_blue, box_alpha);
        GL11.glDisable(GL11.GL_LINE_SMOOTH);
        GlStateManager.enableDepth();
        GlStateManager.depthMask(true);
        GlStateManager.translate(-x, -y, -z);
        GlStateManager.enableTexture2D();
        GlStateManager.disableBlend();
        GlStateManager.popMatrix();
    }

    public static void drawString3D(BlockPos pos, String text, int color) {
        GlStateManager.pushMatrix();
        glBillboardDistanceScaled(pos.getX() + 0.5f, pos.getY() + 0.5f, pos.getZ() + 0.5f, mc.player, 1.0f);
        GlStateManager.disableDepth();
        GlStateManager.translate(-(FontUtil.sfui20.getStringWidth(text) / 2.0), 0.0, 0.0);
        FontUtil.sfui20.drawStringWithShadow(text, 0, 0, color);
        GlStateManager.enableDepth();
        GlStateManager.popMatrix();
    }

    public static void drawString3D(BlockPos pos, String text, MinecraftFontRenderer fontRenderer, boolean shadow, int color) {
        GlStateManager.pushMatrix();
        glBillboardDistanceScaled(pos.getX() + 0.5f, pos.getY() + 0.5f, pos.getZ() + 0.5f, mc.player, 1.0f);
        GlStateManager.disableDepth();
        GlStateManager.translate(-(fontRenderer.getStringWidth(text) / 2.0), 0.0, 0.0);
        if (shadow) {
            fontRenderer.drawString(text, 0, 0, color);
        } else {
            fontRenderer.drawString(text, 0, 0, color);
        }
        GlStateManager.enableDepth();
        GlStateManager.popMatrix();
    }

    public static void drawString3D(BlockPos pos, String text, FontRenderer fontRenderer, boolean shadow, int color) {
        GlStateManager.pushMatrix();
        glBillboardDistanceScaled(pos.getX() + 0.5f, pos.getY() + 0.5f, pos.getZ() + 0.5f, mc.player, 1.0f);
        GlStateManager.disableDepth();
        GlStateManager.translate(-(fontRenderer.getStringWidth(text) / 2.0), 0.0, 0.0);
        fontRenderer.drawString(text, 0, 0, color, shadow);
        GlStateManager.enableDepth();
        GlStateManager.popMatrix();
    }

    public static void glBillboard(float x, float y, float z) {
        float scale = 0.02666667f;
        GlStateManager.translate(x - mc.getRenderManager().viewerPosX, y - mc.getRenderManager().viewerPosY, z - mc.getRenderManager().viewerPosZ);
        GlStateManager.glNormal3f(0.0f, 1.0f, 0.0f);
        GlStateManager.rotate(-mc.player.rotationYaw, 0.0f, 1.0f, 0.0f);
        GlStateManager.rotate(mc.player.rotationPitch, mc.gameSettings.thirdPersonView == 2 ? -1.0f : 1.0f, 0.0f, 0.0f);
        GlStateManager.scale(-scale, -scale, scale);
    }

    public static void glBillboardDistanceScaled(float x, float y, float z, EntityPlayer player, float scale) {
        glBillboard(x, y, z);
        double distance = player.getDistance(x, y, z);
        float scaleDistance = (float) distance / 2.0f / (2.0f + (2.0f - scale));
        if (scaleDistance < 1.0f) {
            scaleDistance = 1.0f;
        }
        GlStateManager.scale(scaleDistance, scaleDistance, scaleDistance);
    }
}
