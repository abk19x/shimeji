package me.enokitoraisu.shimejiclient.module.impl.player;

import me.enokitoraisu.shimejiclient.event.PacketEvent;
import me.enokitoraisu.shimejiclient.mixin.AccessorMinecraft;
import me.enokitoraisu.shimejiclient.module.Category;
import me.enokitoraisu.shimejiclient.module.Module;
import me.enokitoraisu.shimejiclient.utils.entity.InventoryUtil;
import me.enokitoraisu.shimejiclient.value.values.BooleanValue;
import net.minecraft.item.ItemExpBottle;
import net.minecraft.network.play.client.CPacketPlayer;
import net.minecraft.network.play.client.CPacketPlayerTryUseItem;
import net.minecraftforge.fml.common.eventhandler.Event;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import org.lwjgl.input.Keyboard;

@SuppressWarnings("unused")
public class FastPlace extends Module {
    private final BooleanValue footExp = register(new BooleanValue("FootExp", false));

    public FastPlace() {
        super("FastPlace", Category.PLAYER, Keyboard.KEY_NONE);
    }

    public void onTick() {
        if (InventoryUtil.HoldItem(ItemExpBottle.class)) {
            ((AccessorMinecraft) mc).rightClickDelayTimer(0);
        }
    }

    @SubscribeEvent
    public void onPacketSend(Event event) {
        if (footExp.getValue()) {
            if (event instanceof PacketEvent.Send) {
                PacketEvent.Send send = (PacketEvent.Send) event;
                if (send.getPacket() instanceof CPacketPlayerTryUseItem)
                    mc.player.connection.sendPacket(new CPacketPlayer.Rotation(mc.player.rotationYaw, 90.0f, mc.player.onGround));
            }

            if (event instanceof PacketEvent.Sent) {
                PacketEvent.Sent send = (PacketEvent.Sent) event;
                if (send.getPacket() instanceof CPacketPlayerTryUseItem)
                    mc.player.connection.sendPacket(new CPacketPlayer.Rotation(mc.player.rotationYaw, mc.player.rotationPitch, mc.player.onGround));
            }
        }
    }
}
