package me.enokitoraisu.shimejiclient.gui.shimeji.componet.componets;

import me.enokitoraisu.shimejiclient.gui.GuiSetting;
import me.enokitoraisu.shimejiclient.gui.shimeji.componet.Component;
import me.enokitoraisu.shimejiclient.utils.renderer.RenderUtil;
import me.enokitoraisu.shimejiclient.utils.renderer.font.FontUtil;
import me.enokitoraisu.shimejiclient.value.values.IntegerValue;

public class IntegerButton extends Component {
    private final IntegerValue integerValue;
    private float value;
    private boolean changing;

    public IntegerButton(IntegerValue integerValue, int x, int width, int height) {
        this.integerValue = integerValue;
        this.x = x;
        this.width = width;
        this.height = height;
        this.changing = false;
        this.value = (float) (this.integerValue.getValue() - this.integerValue.getMin()) / (float) (this.integerValue.getMax() - this.integerValue.getMin());
    }

    @Override
    public void drawScreen(int mouseX, int mouseY, int offsetY) {
        this.visible = this.integerValue.getVisibility();
        if (this.visible) {
            this.y = offsetY;
            RenderUtil.drawRect(this.x, offsetY, this.width, this.height, 0xCB191919);

            if (bounding(mouseX, mouseY))
                RenderUtil.drawRect(x, offsetY, width, height, 0x40000000);

            RenderUtil.drawDoubleRectWH(x + 1.5f, offsetY + 1.5f, width - 3, height - 3, 0x80191919);
            float renderValue = (integerValue.getValue().floatValue() - integerValue.getMin().floatValue()) / (integerValue.getMax().floatValue() - integerValue.getMin().floatValue());
            RenderUtil.drawRect(this.x + 2, offsetY + 2, (this.width - 4) * renderValue, height - 4, GuiSetting.getAccent());
            FontUtil.sfui18.drawStringWithShadow(String.format("%s : %d", integerValue.getName(), integerValue.getValue()), x + 5, offsetY + (height / 2f - FontUtil.sfui18.getHeight() / 2f), -1);


            if (this.x - 10 < mouseX && this.x + this.width + 10 > mouseX && this.changing) {
                this.value = ((float) mouseX - (float) this.x) / (float) this.width;
                if (this.value > 1.0f) this.value = 1.0f;
                if (this.value < 0.0f) this.value = 0.0f;
                this.integerValue.setValue((int) (this.integerValue.getMin() + (this.integerValue.getMax() - this.integerValue.getMin()) * this.value));
            }
        }
    }

    @Override
    public void mouseClicked(int mouseX, int mouseY, int mouseButton) {
        if (this.visible) {
            if (this.bounding(mouseX, mouseY) && mouseButton == 0) {
                this.changing = true;
            }
        }
    }

    @Override
    public void mouseReleased(int mouseX, int mouseY, int state) {
        this.changing = false;
    }
}
