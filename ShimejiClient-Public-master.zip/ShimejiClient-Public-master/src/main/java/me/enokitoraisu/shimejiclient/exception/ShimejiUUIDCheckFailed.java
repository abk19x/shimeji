package me.enokitoraisu.shimejiclient.exception;

public class ShimejiUUIDCheckFailed extends Throwable {
    public ShimejiUUIDCheckFailed(String s) {
        super(s);
    }
}
