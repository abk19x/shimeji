package me.enokitoraisu.shimejiclient.module.impl.misc;

import me.enokitoraisu.shimejiclient.ShimejiClient;
import me.enokitoraisu.shimejiclient.event.PacketEvent;
import me.enokitoraisu.shimejiclient.module.Category;
import me.enokitoraisu.shimejiclient.module.Module;
import me.enokitoraisu.shimejiclient.utils.math.MathUtil;
import me.enokitoraisu.shimejiclient.value.values.IntegerValue;
import me.enokitoraisu.shimejiclient.value.values.ModeValue;
import net.minecraft.network.play.server.SPacketChat;
import net.minecraft.util.text.Style;
import net.minecraft.util.text.TextComponentString;
import net.minecraft.util.text.event.HoverEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import org.lwjgl.input.Keyboard;

import java.util.Arrays;
import java.util.regex.Pattern;

public class AntiUnicodeSpam extends Module {
    private int iChar = 0;
    private int iPage = 0;
    private final ModeValue mode = register(new ModeValue("Mode", "Flag", "Flag", "Resources"));
    private final IntegerValue flagChar = register(new IntegerValue("FlagChar", 10, 10, 50, v -> mode.getValue().equals("Flag")));
    private final IntegerValue flagPages = register(new IntegerValue("FlagPage", 150, 100, 180, v -> mode.getValue().equals("Resources")));


    public AntiUnicodeSpam() {
        super("AntiUnicodeSpam", Category.MISC, Keyboard.KEY_NONE);
    }

    @SubscribeEvent
    public void onPacketReceived(PacketEvent.Receive event) {
        if (event.getPacket() instanceof SPacketChat) {
            SPacketChat packet = (SPacketChat) event.getPacket();

            String message = MathUtil.cleanColor(packet.getChatComponent().getUnformattedText());

            switch (mode.getValue()) {
                case "Flag":
                    if (check(message)) {
                        event.setCanceled(true);
                        mc.player.sendMessage(new TextComponentString(ShimejiClient.PrefixFormat + "\u00A7eWarning Message \u00A7f" + iChar).setStyle(new Style().setHoverEvent(new HoverEvent(HoverEvent.Action.SHOW_TEXT, detectTextComponent(packet.getChatComponent().getUnformattedText())))));
                        iChar++;
                    }
                    break;
                case "Resources":
                    if (checkResource(message)) {
                        event.setCanceled(true);
                        mc.player.sendMessage(new TextComponentString(ShimejiClient.PrefixFormat + "\u00A7eWarning Message Page \u00A7f" + iPage).setStyle(new Style().setHoverEvent(new HoverEvent(HoverEvent.Action.SHOW_TEXT, new TextComponentString(packet.getChatComponent().getUnformattedText())))));
                        iPage++;
                    }
                    break;
            }

        }
    }

    public boolean checkResource(String message) {
        String[] pages = new String[message.length()];
        int flag = 0;

        for (int i1 = 0; i1 < message.length(); i1++) {
            char charInfo = message.charAt(i1);
            int page = charInfo / 256;
            if (Arrays.stream(pages).noneMatch(str -> String.format("%02x", page).equalsIgnoreCase(str)))
                flag++;
            pages[i1] = String.format("%02x", page);
        }

        return flag > flagPages.getValue();
    }

    public boolean check(String s) {
        int i = 0;
        Pattern pattern = Pattern.compile("[^\\u0000-\\u007F\\uFF01-\\uFF5E\\uFF10-\\uFF19\\u3040-\\u309F\\u30A0-\\u30FF\\uFF66-\\uFF9F\\u3000\\u4E00-\\u9FFF\\u0400-\\u04FF\\uAC00-\\uD7A3]");
        for (Character c : s.toCharArray()) {
            if (pattern.matcher(c.toString()).find())
                i++;
        }

        return i > flagChar.getValue();
    }

    public TextComponentString detectTextComponent(String s) {
        TextComponentString components = new TextComponentString("");
        int i = 0;
        Pattern pattern = Pattern.compile("[^\\u0000-\\u007F\\uFF01-\\uFF5E\\uFF10-\\uFF19\\u3040-\\u309F\\u30A0-\\u30FF\\uFF66-\\uFF9F\\u3000\\u4E00-\\u9FFF\\u0400-\\u04FF\\uAC00-\\uD7A3]");
        for (Character c : s.toCharArray()) {
            if (pattern.matcher(c.toString()).find()) {
                if (i > flagChar.getValue()) {
                    components.appendText(String.format("\u00A7c%s\u00A7r", c));
                } else {
                    components.appendText(String.format("\u00A7e%s\u00A7r", c));
                }
                i++;
            } else {
                components.appendText(String.format("\u00A7f%s\u00A7r", c));
            }
        }

        return components;
    }
}