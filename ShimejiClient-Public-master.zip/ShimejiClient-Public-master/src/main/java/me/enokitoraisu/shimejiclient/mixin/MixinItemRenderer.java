package me.enokitoraisu.shimejiclient.mixin;

import me.enokitoraisu.shimejiclient.event.FireEffectEvent;
import me.enokitoraisu.shimejiclient.event.ItemRendererEvent;
import me.enokitoraisu.shimejiclient.event.SideItemRendererEvent;
import net.minecraft.client.entity.AbstractClientPlayer;
import net.minecraft.client.renderer.ItemRenderer;
import net.minecraft.item.ItemStack;
import net.minecraft.util.EnumHand;
import net.minecraft.util.EnumHandSide;
import net.minecraftforge.common.MinecraftForge;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ItemRenderer.class)
public abstract class MixinItemRenderer {
    @Inject(method = "renderFireInFirstPerson()V", at = @At(value = "HEAD"), cancellable = true)
    private void renderFireInFirstPerson(CallbackInfo ci) {
        FireEffectEvent fireEffectEvent = new FireEffectEvent();
        MinecraftForge.EVENT_BUS.post(fireEffectEvent);
        if (fireEffectEvent.isCanceled()) ci.cancel();
    }

    @Inject(method = "transformSideFirstPerson(Lnet/minecraft/util/EnumHandSide;F)V", at = @At(value = "TAIL"))
    public void transformSideFirstPerson(EnumHandSide hand, float p_187459_2_, CallbackInfo ci) {
        SideItemRendererEvent event = new SideItemRendererEvent(hand, p_187459_2_);
        MinecraftForge.EVENT_BUS.post(event);
    }

    @Inject(method = "renderItemInFirstPerson(Lnet/minecraft/client/entity/AbstractClientPlayer;FFLnet/minecraft/util/EnumHand;FLnet/minecraft/item/ItemStack;F)V", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/renderer/GlStateManager;pushMatrix()V", shift = At.Shift.AFTER))
    public void renderItemInFirstPerson(AbstractClientPlayer player, float p_187457_2_, float p_187457_3_, EnumHand hand, float p_187457_5_, ItemStack stack, float p_187457_7_, CallbackInfo ci) {
        ItemRendererEvent event = new ItemRendererEvent(player, p_187457_2_, p_187457_3_, hand, p_187457_5_, stack, p_187457_7_);
        MinecraftForge.EVENT_BUS.post(event);
    }
}
