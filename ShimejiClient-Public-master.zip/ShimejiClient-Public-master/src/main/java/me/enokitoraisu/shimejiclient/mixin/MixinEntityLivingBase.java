package me.enokitoraisu.shimejiclient.mixin;

import me.enokitoraisu.shimejiclient.event.SwingAnimationEvent;
import me.enokitoraisu.shimejiclient.module.impl.hud.PotionHud;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.init.MobEffects;
import net.minecraft.potion.Potion;
import net.minecraft.potion.PotionEffect;
import net.minecraftforge.common.MinecraftForge;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(EntityLivingBase.class)
public abstract class MixinEntityLivingBase {
    @Shadow
    public abstract boolean isPotionActive(Potion potionIn);

    @Shadow
    public abstract PotionEffect getActivePotionEffect(Potion potionIn);

    @Inject(method = "getArmSwingAnimationEnd()I", at = @At(value = "HEAD"), cancellable = true)
    private void getArmSwingAnimationEnd(CallbackInfoReturnable<Integer> cir) {
        SwingAnimationEvent armSwingAnimation = new SwingAnimationEvent(EntityLivingBase.class.cast(this), 6);
        MinecraftForge.EVENT_BUS.post(armSwingAnimation);
        cir.setReturnValue(getSpeed(armSwingAnimation.getSpeed()));
    }

    @Inject(method = "addPotionEffect(Lnet/minecraft/potion/PotionEffect;)V", at = @At(value = "INVOKE", target = "Ljava/util/Map;put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;"))
    public void putEffect(PotionEffect potioneffectIn, CallbackInfo ci) {
        if (EntityLivingBase.class.cast(this) == Minecraft.getMinecraft().player)
            PotionHud.effects.put(potioneffectIn.getPotion(), new PotionHud.Effect(potioneffectIn, EntityLivingBase.class.cast(this)));
    }

    @Inject(method = "addPotionEffect(Lnet/minecraft/potion/PotionEffect;)V", at = @At(value = "INVOKE", target = "Lnet/minecraft/potion/PotionEffect;combine(Lnet/minecraft/potion/PotionEffect;)V", shift = At.Shift.BEFORE))
    public void combineEffect(PotionEffect potioneffectIn, CallbackInfo ci) {
        if (EntityLivingBase.class.cast(this) == Minecraft.getMinecraft().player) {
            PotionHud.Effect effect = PotionHud.effects.get(potioneffectIn.getPotion());
            if (effect != null && effect.getEntity() != Minecraft.getMinecraft().player) {
                if (potioneffectIn.getAmplifier() > effect.getPotionEffect().getAmplifier()) {
                    effect.setMaxDuration(potioneffectIn.getDuration());
                } else if (potioneffectIn.getAmplifier() == effect.getPotionEffect().getAmplifier() && effect.getPotionEffect().getDuration() < potioneffectIn.getDuration()) {
                    effect.setMaxDuration(potioneffectIn.getDuration());
                }
            }
        }
    }

    @Inject(method = "removeActivePotionEffect(Lnet/minecraft/potion/Potion;)Lnet/minecraft/potion/PotionEffect;", at = @At(value = "INVOKE", target = "Ljava/util/Map;remove(Ljava/lang/Object;)Ljava/lang/Object;", shift = At.Shift.BEFORE))
    public void removeEffect(Potion potioneffectin, CallbackInfoReturnable<PotionEffect> cir) {
        if (EntityLivingBase.class.cast(this) == Minecraft.getMinecraft().player)
            PotionHud.effects.remove(potioneffectin);
    }

    @Inject(method = "clearActivePotions()V", at = @At(value = "INVOKE", target = "Ljava/util/Collection;iterator()Ljava/util/Iterator;"))
    public void removeEffect(CallbackInfo ci) {
        if (EntityLivingBase.class.cast(this) == Minecraft.getMinecraft().player)
            PotionHud.effects.clear();
    }

    @Inject(method = "onFinishedPotionEffect(Lnet/minecraft/potion/PotionEffect;)V", at = @At(value = "INVOKE", target = "Lnet/minecraft/potion/Potion;removeAttributesModifiersFromEntity(Lnet/minecraft/entity/EntityLivingBase;Lnet/minecraft/entity/ai/attributes/AbstractAttributeMap;I)V"))
    public void onFinishedPotionEffect(PotionEffect effect, CallbackInfo ci) {
        if (EntityLivingBase.class.cast(this) == Minecraft.getMinecraft().player)
            PotionHud.effects.remove(effect.getPotion());
    }

    private int getSpeed(int speed) {
        if (this.isPotionActive(MobEffects.HASTE)) {
            return speed - (1 + this.getActivePotionEffect(MobEffects.HASTE).getAmplifier());
        } else {
            return this.isPotionActive(MobEffects.MINING_FATIGUE) ? speed + (1 + this.getActivePotionEffect(MobEffects.MINING_FATIGUE).getAmplifier()) * 2 : speed;
        }
    }
}