package me.enokitoraisu.shimejiclient.utils.renderer;

import me.enokitoraisu.shimejiclient.utils.math.ColorConverter;
import me.enokitoraisu.shimejiclient.utils.math.Easings;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.util.math.MathHelper;
import org.lwjgl.opengl.GL11;

public class ClickCircle {
    private final String easing;
    public float x, y;
    public int seconds;
    public long time;
    public int radius;

    public ClickCircle(float x, float y, int seconds, int radius, String easing) {
        this.x = x;
        this.y = y;
        this.seconds = seconds;
        this.time = System.currentTimeMillis();
        this.radius = radius;
        this.easing = easing;
    }

    public void draw(int color) {
        float value = MathHelper.clamp((float) (System.currentTimeMillis() - time) / (seconds * 1000F), 0F, 1F);

        drawCircle(x, y, radius * (float) Easings.toOutEasing(easing, value), new ColorConverter(color).setAlpha((int) (255 * (1 - (float) Easings.toOutEasing(easing, value)))));
    }

    public void drawCircle(float centerX, float centerY, float radius, int color) {
        GlStateManager.color(1F, 1F, 1F, 1F);
        GlStateManager.disableAlpha();
        GlStateManager.enableBlend();
        GlStateManager.disableTexture2D();
        GlStateManager.tryBlendFuncSeparate(GlStateManager.SourceFactor.SRC_ALPHA, GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA, GlStateManager.SourceFactor.ONE, GlStateManager.DestFactor.ZERO);
        GlStateManager.color((color >> 16 & 0xFF) / 255.0F, (color >> 8 & 0xFF) / 255.0F, (color & 0xFF) / 255.0F, (color >> 24 & 0xFF) / 255.0F);
        GL11.glBegin(GL11.GL_POLYGON);
        for (int i = 0; i <= 360; i++)
            GL11.glVertex2d(centerX + MathHelper.sin(i * (float) Math.PI / 180F) * radius, centerY + MathHelper.cos(i * (float) Math.PI / 180F) * radius);
        GL11.glEnd();
        GL11.glEnable(GL11.GL_LINE_SMOOTH);
        GL11.glLineWidth(.5F);
        GL11.glBegin(GL11.GL_LINE_LOOP);
        for (int i = 0; i <= 360; i++)
            GL11.glVertex2d(centerX + MathHelper.sin(i * (float) Math.PI / 180F) * radius, centerY + MathHelper.cos(i * (float) Math.PI / 180F) * radius);
        GL11.glEnd();
        GL11.glDisable(GL11.GL_LINE_SMOOTH);
        GlStateManager.enableTexture2D();
        GlStateManager.disableBlend();
        GlStateManager.enableAlpha();
        GlStateManager.color(1.0F, 1.0F, 1.0F, 1.0F);
    }

    public boolean isRemovable() {
        return System.currentTimeMillis() > time + (seconds * 1000L);
    }
}
