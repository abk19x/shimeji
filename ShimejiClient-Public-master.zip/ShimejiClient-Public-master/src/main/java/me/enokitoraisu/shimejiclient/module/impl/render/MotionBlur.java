package me.enokitoraisu.shimejiclient.module.impl.render;

import me.enokitoraisu.shimejiclient.module.Category;
import me.enokitoraisu.shimejiclient.module.Module;
import me.enokitoraisu.shimejiclient.value.values.IntegerValue;
import org.lwjgl.input.Keyboard;

@SuppressWarnings("unused")
public class MotionBlur extends Module {
    public static MotionBlur INSTANCE = new MotionBlur();

    public IntegerValue amount = register(new IntegerValue("Amount", 1, 1, 8));

    public MotionBlur() {
        super("MotionBlur", Category.RENDER, Keyboard.KEY_NONE);
        INSTANCE = this;
    }

    public void onTick() {
        setTags(amount.getValue().toString());
    }
}
