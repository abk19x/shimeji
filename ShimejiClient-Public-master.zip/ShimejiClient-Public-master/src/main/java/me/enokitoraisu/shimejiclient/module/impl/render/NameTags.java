package me.enokitoraisu.shimejiclient.module.impl.render;

import me.enokitoraisu.shimejiclient.module.Category;
import me.enokitoraisu.shimejiclient.module.Module;
import me.enokitoraisu.shimejiclient.utils.renderer.RenderUtil;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.entity.player.EntityPlayer;
import org.lwjgl.input.Keyboard;

@SuppressWarnings("unused")
public class NameTags extends Module {
    public NameTags() {
        super("NameTags", Category.RENDER, Keyboard.KEY_NONE);
    }

    private void drawNameTags(EntityPlayer player) {
        String text = String.format("\u00A7a[\u00A7f%.0f\u00A7a]\u00A7r \u00A7f%s\u00A7r \u00A7f:\u00A7r %.1f", player.getDistance(mc.player), player.getDisplayName().getUnformattedText(), player.getHealth());
        float health = player.getHealth() / player.getMaxHealth();
        int color = health > 0.6 ? 0xFF00FF00 : health > 0.3 ? 0xFFFFFF00 : 0xFFFF0000;

        GlStateManager.pushMatrix();
        double xx = player.lastTickPosX + (player.posX - player.lastTickPosX) * mc.getRenderPartialTicks() - mc.getRenderManager().viewerPosX;
        double yy = player.lastTickPosY + (player.posY - player.lastTickPosY) * mc.getRenderPartialTicks() - mc.getRenderManager().viewerPosY;
        double zz = player.lastTickPosZ + (player.posZ - player.lastTickPosZ) * mc.getRenderPartialTicks() - mc.getRenderManager().viewerPosZ;
        GlStateManager.translate(xx, yy + 2, zz);
        GlStateManager.glNormal3f(0.0f, 1.0f, 0.0f);
        GlStateManager.rotate(-mc.player.rotationYaw, 0.0f, 1.0f, 0.0f);
        GlStateManager.rotate(mc.player.rotationPitch, 1.0f, 0.0f, 0.0f);
        GlStateManager.scale(-0.02666667f, -0.02666667f, 0.02666667f);
        double distance = player.getDistance(mc.player);
        float scaleDistance = (float) distance / 2.0f / (2.0f + (2.0f - 1.0f));
        if (scaleDistance < 0.5f) {
            scaleDistance = 0.5f;
        }
        GlStateManager.scale(scaleDistance, scaleDistance, scaleDistance);
        GlStateManager.disableDepth();
        GlStateManager.translate(-(mc.fontRenderer.getStringWidth(text) / 2.0), -mc.fontRenderer.FONT_HEIGHT, 0.0);

        RenderUtil.drawRect(-1, -1, mc.fontRenderer.getStringWidth(text) + 2, mc.fontRenderer.FONT_HEIGHT + 1, 0xbf000000);
        mc.fontRenderer.drawStringWithShadow(text, 0.0f, 0.0f, color);
        GlStateManager.enableDepth();
        GlStateManager.popMatrix();
    }

    @Override
    public void onRender3D() {
        mc.world.loadedEntityList.stream().filter(entity -> entity instanceof EntityPlayer).filter(entity -> entity != mc.player).map(EntityPlayer.class::cast).forEach(this::drawNameTags);
    }
}
