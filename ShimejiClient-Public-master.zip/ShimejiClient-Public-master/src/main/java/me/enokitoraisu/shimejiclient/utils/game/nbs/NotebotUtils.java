package me.enokitoraisu.shimejiclient.utils.game.nbs;

public class NotebotUtils {
    //public static Note getNoteFromNoteBlock(BlockNote note, NotebotMode mode) {
    //return new Note(instrument, level);
    //}

    public enum NotebotMode {
        AnyInstrument, ExactInstruments
    }
}