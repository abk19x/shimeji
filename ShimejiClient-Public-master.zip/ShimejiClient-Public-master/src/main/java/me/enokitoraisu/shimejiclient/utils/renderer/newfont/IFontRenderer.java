package me.enokitoraisu.shimejiclient.utils.renderer.newfont;

public interface IFontRenderer {
    float drawString(String str, float startX, float startY, int color, float align);
    float getStringWidth(String str);
    @SuppressWarnings("unused") int sizeStringToWidth(String str, float width);
    @SuppressWarnings("unused") String trimStringToWidth(String str, float width, boolean reverse);
}