package me.enokitoraisu.shimejiclient.mixin;

import me.enokitoraisu.shimejiclient.ShimejiClient;
import me.enokitoraisu.shimejiclient.event.MoveEvent;
import me.enokitoraisu.shimejiclient.event.SwingArmEvent;
import me.enokitoraisu.shimejiclient.module.Module;
import me.enokitoraisu.shimejiclient.module.impl.misc.PortalGodMode;
import me.enokitoraisu.shimejiclient.module.impl.movement.NoSlow;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.entity.MoverType;
import net.minecraft.util.EnumHand;
import net.minecraftforge.common.MinecraftForge;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(EntityPlayerSP.class)
public class MixinEntityPlayerSP {
    @Redirect(method = "onLivingUpdate()V", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/entity/EntityPlayerSP;isHandActive()Z"))
    public boolean isHandActive(EntityPlayerSP sp) {
        if (NoSlow.INSTANCE.toggled && NoSlow.INSTANCE.mode.getValue().equals("Vanilla")) {
            return false;
        } else {
            return sp.isHandActive();
        }
    }

    @Redirect(method = "onLivingUpdate()V", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/gui/GuiScreen;doesGuiPauseGame()Z", ordinal = 0))
    public boolean doesGuiPauseGame(GuiScreen instance) {
        if (PortalGodMode.INSTANCE.toggled && PortalGodMode.INSTANCE.close.getValue()) {
            return true;
        } else {
            return instance.doesGuiPauseGame();
        }
    }

    @Inject(method = "onUpdateWalkingPlayer()V", at = @At(value = "HEAD"))
    public void onUpdateWalkingPlayer(CallbackInfo ci) {
        ShimejiClient.moduleManager.modules.stream().filter(Module::isToggled).forEach(Module::onUpdate);
    }

    @Inject(method = "move", at = @At(value = "HEAD"), cancellable = true)
    public void move(MoverType type, double x, double y, double z, CallbackInfo ci) {
        MoveEvent moveEvent = new MoveEvent(type, x, y, z);
        MinecraftForge.EVENT_BUS.post(moveEvent);
        if (moveEvent.isCanceled()) ci.cancel();
    }

    @Inject(method = "swingArm(Lnet/minecraft/util/EnumHand;)V", at = @At(value = "HEAD"), cancellable = true)
    public void swingArm(EnumHand hand, CallbackInfo ci) {
        SwingArmEvent swingArmEvent = new SwingArmEvent(hand);
        MinecraftForge.EVENT_BUS.post(swingArmEvent);
        if (swingArmEvent.isCanceled()) ci.cancel();
    }
}
