package me.enokitoraisu.shimejiclient.mixin;

import me.enokitoraisu.shimejiclient.event.HurtEffectEvent;
import me.enokitoraisu.shimejiclient.module.impl.render.CameraClip;
import me.enokitoraisu.shimejiclient.module.impl.render.MotionBlur;
import me.enokitoraisu.shimejiclient.utils.renderer.MotionBlurUtil;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.WorldClient;
import net.minecraft.client.renderer.EntityRenderer;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.OpenGlHelper;
import net.minecraft.client.shader.ShaderGroup;
import net.minecraft.util.math.RayTraceResult;
import net.minecraft.util.math.Vec3d;
import net.minecraftforge.common.MinecraftForge;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.ArrayList;
import java.util.List;

@Mixin(EntityRenderer.class)
public class MixinEntityRenderer {
    private final ShaderGroup theShaderGroup;
    @Shadow
    private boolean useShader;
    @Shadow
    @Final
    private Minecraft mc;

    public MixinEntityRenderer(ShaderGroup theShaderGroup) {
        this.theShaderGroup = theShaderGroup;
    }

    @Redirect(method = "orientCamera(F)V", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/multiplayer/WorldClient;rayTraceBlocks(Lnet/minecraft/util/math/Vec3d;Lnet/minecraft/util/math/Vec3d;)Lnet/minecraft/util/math/RayTraceResult;"))
    public RayTraceResult rayTraceBlocks(WorldClient world, Vec3d start, Vec3d end) {
        return CameraClip.INSTANCE.toggled ? null : world.rayTraceBlocks(start, end);
    }

    @Inject(method = "hurtCameraEffect(F)V", at = @At(value = "HEAD"), cancellable = true)
    public void hurtCameraEffect(float partialTicks, CallbackInfo info) {
        HurtEffectEvent hurtEffectEvent = new HurtEffectEvent();
        MinecraftForge.EVENT_BUS.post(hurtEffectEvent);
        if (hurtEffectEvent.isCanceled()) {
            info.cancel();
        }
    }

    @Inject(method = "updateCameraAndRender(FJ)V", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/shader/Framebuffer;bindFramebuffer(Z)V", shift = At.Shift.BEFORE))
    public void updateCameraAndRender(float partialTicks, long nanoTime, CallbackInfo ci) {
        List<ShaderGroup> shaders = new ArrayList<>();
        if (this.theShaderGroup != null && this.useShader) shaders.add(this.theShaderGroup);
        ShaderGroup motionBlur = MotionBlurUtil.instance.getShader();

        if (MotionBlur.INSTANCE.toggled) {
            if (motionBlur != null) shaders.add(motionBlur);
            for (ShaderGroup shader : shaders) {
                GlStateManager.pushMatrix();
                GlStateManager.loadIdentity();
                shader.render(partialTicks);
                GlStateManager.popMatrix();
            }
        }
    }

    @Inject(method = "updateShaderGroupSize(II)V", at = @At(value = "RETURN"))
    public void updateShaderGroupSize(int width, int height, CallbackInfo ci) {
        if (mc.world == null) return;
        if (OpenGlHelper.shadersSupported) {
            ShaderGroup motionBlur = MotionBlurUtil.instance.getShader();
            if (motionBlur != null) {
                motionBlur.createBindFramebuffers(width, height);
            }
        }
    }
}
