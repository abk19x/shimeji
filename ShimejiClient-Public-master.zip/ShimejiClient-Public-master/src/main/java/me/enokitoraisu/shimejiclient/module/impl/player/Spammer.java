package me.enokitoraisu.shimejiclient.module.impl.player;

import me.enokitoraisu.shimejiclient.module.Category;
import me.enokitoraisu.shimejiclient.module.Module;
import me.enokitoraisu.shimejiclient.utils.math.TimerUtil;
import me.enokitoraisu.shimejiclient.value.values.BooleanValue;
import me.enokitoraisu.shimejiclient.value.values.IntegerValue;
import me.enokitoraisu.shimejiclient.value.values.StringValue;
import net.minecraft.util.ChatAllowedCharacters;
import org.lwjgl.input.Keyboard;

import java.util.Random;

@SuppressWarnings("unused")
public class Spammer extends Module {
    private final StringValue message = register(new StringValue("Message", "Message"));
    private final IntegerValue delay = register(new IntegerValue("Delay", 1, 1, 10));
    private final BooleanValue randomChars = register(new BooleanValue("RandomChars", false));
    private final BooleanValue space = register(new BooleanValue("Space", false, v -> randomChars.getValue()));
    private final IntegerValue charCount = register(new IntegerValue("CharCount", 2, 2, 200, v -> randomChars.getValue()));
    private final TimerUtil timer = new TimerUtil();
    private final Random random = new Random(321284879);

    public Spammer() {
        super("Spammer", Category.PLAYER, Keyboard.KEY_NONE);
    }

    @Override
    public void onTick() {
        if (timer.passedS(delay.getValue())) {
            StringBuilder chars = new StringBuilder(space.getValue() && randomChars.getValue() ? " " : "");
            if (randomChars.getValue()) {
                for (int i = 0; i < charCount.getValue(); i++) {
                    char cha_r = (char) random.nextInt(65535);
                    if (ChatAllowedCharacters.isAllowedCharacter(cha_r)) {
                        chars.append(cha_r);
                    } else {
                        i--;
                    }
                }
            }
            mc.player.sendChatMessage(message.getValue() + chars);
            timer.reset();
        }
    }
}
