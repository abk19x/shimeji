package me.enokitoraisu.shimejiclient.value.values;

import me.enokitoraisu.shimejiclient.value.ValueBase;
import net.minecraft.util.math.MathHelper;

import java.util.Arrays;
import java.util.List;
import java.util.function.Predicate;

public class ModeValue extends ValueBase<String> {
    public List<String> list;
    private int current;

    public ModeValue(String name, String value, String... values) {
        this(name, value, v -> true, values);
    }

    public ModeValue(String name, String value, Predicate<String> visibility, String... values) {
        super(name, value, visibility);
        this.list = Arrays.asList(values);
        this.current = this.list.indexOf(value);
    }

    public void cycle() {
        if (current < list.size() - 1) current++;
        else current = 0;
    }

    public void reverse() {
        if (current > 0) current--;
        else current = list.size() - 1;
    }

    public int getCurrent() {
        return current;
    }

    public void setValueOfIndex(int index) {
        this.current = MathHelper.clamp(index, 0, list.size() - 1);
    }

    @Override
    public String getValue() {
        if (current >= list.size()) {
            return this.list.get(0);
        } else {
            return this.list.get(current);
        }
    }

    @Override
    public void setValue(String value) {
        boolean settable = false;
        for (String s : list) {
            if (s.equals(value)) {
                settable = true;
                break;
            }
        }
        if (settable)
            this.current = list.indexOf(value);
    }

    public String getNext() {
        if (current + 1 >= list.size()) {
            return this.list.get(0);
        } else {
            return this.list.get(current + 1);
        }
    }
}
