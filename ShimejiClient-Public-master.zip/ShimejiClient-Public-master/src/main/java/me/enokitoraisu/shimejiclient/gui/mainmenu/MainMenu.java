package me.enokitoraisu.shimejiclient.gui.mainmenu;

import me.enokitoraisu.shimejiclient.utils.other.ArrayUtil;
import me.enokitoraisu.shimejiclient.utils.renderer.RenderUtil;
import me.enokitoraisu.shimejiclient.utils.renderer.font.FontUtil;
import net.minecraft.client.Minecraft;
import net.minecraft.client.audio.PositionedSoundRecord;
import net.minecraft.client.gui.GuiMultiplayer;
import net.minecraft.client.gui.GuiOptions;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.GuiWorldSelection;
import net.minecraft.client.renderer.BufferBuilder;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.texture.DynamicTexture;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.init.SoundEvents;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.math.MathHelper;
import net.minecraftforge.fml.client.GuiModList;
import org.lwjgl.util.glu.Project;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Calendar;

import static me.enokitoraisu.shimejiclient.ShimejiClient.*;
import static org.lwjgl.opengl.GL11.*;

public class MainMenu extends GuiScreen {
    private static final ResourceLocation[] TITLE_PANORAMA_PATHS = new ResourceLocation[]{
            new ResourceLocation("textures/gui/title/background/panorama_0.png"),
            new ResourceLocation("textures/gui/title/background/panorama_1.png"),
            new ResourceLocation("textures/gui/title/background/panorama_2.png"),
            new ResourceLocation("textures/gui/title/background/panorama_3.png"),
            new ResourceLocation("textures/gui/title/background/panorama_4.png"),
            new ResourceLocation("textures/gui/title/background/panorama_5.png")
    };
    private final Minecraft mc = Minecraft.getMinecraft();
    private final String[] ButtonName = {
            "SinglePlayer",
            "MultiPlayer",
            "ModList",
            "Setting",
            "Exit"
    };
    private final ResourceLocation backgroundTexture;
    private float panoramaTimer;

    public MainMenu() {
        DynamicTexture viewportTexture = new DynamicTexture(256, 256);
        this.backgroundTexture = mc.getTextureManager().getDynamicTextureLocation("background", viewportTexture);
    }

    public void drawScreen(int mouseX, int mouseY, float partialTicks) {
        this.panoramaTimer += partialTicks;
        GlStateManager.disableAlpha();
        this.renderSkybox();
        GlStateManager.enableAlpha();
        Calendar calendar = Calendar.getInstance();
        SimpleDateFormat days = new SimpleDateFormat("yyyy/MM/dd");
        SimpleDateFormat time = new SimpleDateFormat("HH:mm:ss");
        String Timestamp = "Date: " + days.format(calendar.getTime()) + ", Time: " + time.format(calendar.getTime());

        FontUtil.sfui18.drawStringWithShadow(ModName + " " + ModVersion + " Made by " + ArrayUtil.toString(Authors), 0, 1, -1);
        FontUtil.sfui18.drawStringWithShadow(Timestamp, 0, FontUtil.sfui18.getHeight() + 2, -1);

        String copyright = "Copyright Mojang AB. Do not distribute!";
        FontUtil.sfui18.drawStringWithShadow(copyright, width - FontUtil.sfui18.getStringWidth(copyright), height - FontUtil.sfui18.getHeight() - 1, -1);

/*
Mode Change Circle
        boolean circlehover = mouseX >= 0 && mouseY >= height - 40 && mouseX < 40 && mouseY < height;
        RenderUtil.drawCircle(0, height, 40.0f, circlehover ? 0xbf000000 : 0x80000000);
        FontUtil.icon30.drawCenteredString("<-", 20, height - 20, -1);
*/

        FontUtil.righteous50.drawStringWithShadow(ModName, width / 2f - FontUtil.righteous50.getStringWidth(ModName) / 2f, height / 2f - FontUtil.righteous50.getHeight() * 3, 0xffffffff);
        int offset = 10;
        for (String buttons : ButtonName) {
            float x = width / 2f;
            float y = (height / 2f - ((FontUtil.sfui20.getHeight() + 20) * 2)) + (FontUtil.sfui20.getHeight() + offset) + (width / 32f);
            boolean isHover = mouseX >= x - 50 && mouseY >= y - 5 && mouseX < x + 50 && mouseY < y + FontUtil.sfui20.getHeight() + 5;

            RenderUtil.drawRect(x - 50, y - 5, 100, FontUtil.sfui20.getHeight() + 10, isHover ? 0xbf000000 : 0x80000000);
            FontUtil.sfui20.drawStringWithShadow(buttons, (int) ((int) x - (FontUtil.sfui20.getStringWidth(buttons) / 2f)), (int) y, 0xffffffff);
            offset += FontUtil.sfui20.getHeight() + 12;
        }

        super.drawScreen(mouseX, mouseY, partialTicks);
    }

    public void mouseClicked(int mouseX, int mouseY, int button) {
        int offset = 10;
        for (String buttons : ButtonName) {
            float x = width / 2f;
            float y = (height / 2f - ((FontUtil.sfui20.getHeight() + 20) * 2)) + (FontUtil.sfui20.getHeight() + offset) + (width / 32f);

            if (button == 0) {
                if (mouseX >= x - 50 && mouseY >= y - 4 && mouseX < x + 50 && mouseY < y + FontUtil.sfui20.getHeight() + 4) {
                    mc.getSoundHandler().playSound(PositionedSoundRecord.getMasterRecord(SoundEvents.UI_BUTTON_CLICK, 1.0f));
                    switch (buttons) {
                        case "SinglePlayer":
                            mc.displayGuiScreen(new GuiWorldSelection(this));
                            break;
                        case "MultiPlayer":
                            mc.displayGuiScreen(new GuiMultiplayer(this));
                            break;
                        case "ModList":
                            mc.displayGuiScreen(new GuiModList(this));
                            break;
                        case "Setting":
                            mc.displayGuiScreen(new GuiOptions(this, mc.gameSettings));
                            break;
                        case "Exit":
                            mc.shutdown();
                            break;
                    }
                }
            }
            offset += FontUtil.sfui20.getHeight() + 12;
        }
/*
Mode Change Circle
        if (mouseX >= 0 && mouseY >= height - 40 && mouseX < 40 && mouseY < height && button == 0) {
            MMainMenu.INSTANCE.styleSetting.setValue("Apple");
            mc.displayGuiScreen(new NewMainMenu());
        }
*/
        try {
            super.mouseClicked(mouseX, mouseY, button);
        } catch (IOException ignored) {
        }
    }

    private void renderSkybox() {
        mc.getFramebuffer().unbindFramebuffer();
        GlStateManager.viewport(0, 0, 256, 256);
        this.drawPanorama();
        this.rotateAndBlurSkybox();
        this.rotateAndBlurSkybox();
        this.rotateAndBlurSkybox();
        this.rotateAndBlurSkybox();
        this.rotateAndBlurSkybox();
        this.rotateAndBlurSkybox();
        this.rotateAndBlurSkybox();
        mc.getFramebuffer().bindFramebuffer(true);
        GlStateManager.viewport(0, 0, mc.displayWidth, mc.displayHeight);
        float f = 120.0F / (float) (Math.max(this.width, this.height));
        float f1 = (float) this.height * f / 256.0F;
        float f2 = (float) this.width * f / 256.0F;
        int i = this.width;
        int j = this.height;
        Tessellator tessellator = Tessellator.getInstance();
        BufferBuilder bufferbuilder = tessellator.getBuffer();
        bufferbuilder.begin(7, DefaultVertexFormats.POSITION_TEX_COLOR);
        bufferbuilder.pos(0.0D, j, this.zLevel).tex((0.5F - f1), (0.5F + f2)).color(1.0F, 1.0F, 1.0F, 1.0F).endVertex();
        bufferbuilder.pos(i, j, this.zLevel).tex((0.5F - f1), (0.5F - f2)).color(1.0F, 1.0F, 1.0F, 1.0F).endVertex();
        bufferbuilder.pos(i, 0.0D, this.zLevel).tex((0.5F + f1), (0.5F - f2)).color(1.0F, 1.0F, 1.0F, 1.0F).endVertex();
        bufferbuilder.pos(0.0D, 0.0D, this.zLevel).tex((0.5F + f1), (0.5F + f2)).color(1.0F, 1.0F, 1.0F, 1.0F).endVertex();
        tessellator.draw();
    }

    private void rotateAndBlurSkybox() {
        mc.getTextureManager().bindTexture(this.backgroundTexture);
        GlStateManager.glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
        GlStateManager.glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
        GlStateManager.glCopyTexSubImage2D(GL_TEXTURE_2D, 0, 0, 0, 0, 0, 256, 256);
        GlStateManager.enableBlend();
        GlStateManager.tryBlendFuncSeparate(GlStateManager.SourceFactor.SRC_ALPHA, GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA, GlStateManager.SourceFactor.ONE, GlStateManager.DestFactor.ZERO);
        GlStateManager.colorMask(true, true, true, false);
        Tessellator tessellator = Tessellator.getInstance();
        BufferBuilder bufferbuilder = tessellator.getBuffer();
        bufferbuilder.begin(GL_QUADS, DefaultVertexFormats.POSITION_TEX_COLOR);
        GlStateManager.disableAlpha();

        for (int j = 0; j < 3; ++j) {
            float f = 1.0F / (float) (j + 1);
            int k = this.width;
            int l = this.height;
            float f1 = (float) (j - 1) / 256.0F;
            bufferbuilder.pos(k, l, this.zLevel).tex((0.0F + f1), 1.0D).color(1.0F, 1.0F, 1.0F, f).endVertex();
            bufferbuilder.pos(k, 0.0D, this.zLevel).tex((1.0F + f1), 1.0D).color(1.0F, 1.0F, 1.0F, f).endVertex();
            bufferbuilder.pos(0.0D, 0.0D, this.zLevel).tex((1.0F + f1), 0.0D).color(1.0F, 1.0F, 1.0F, f).endVertex();
            bufferbuilder.pos(0.0D, l, this.zLevel).tex((0.0F + f1), 0.0D).color(1.0F, 1.0F, 1.0F, f).endVertex();
        }

        tessellator.draw();
        GlStateManager.enableAlpha();
        GlStateManager.colorMask(true, true, true, true);
    }

    private void drawPanorama() {
        Tessellator tessellator = Tessellator.getInstance();
        BufferBuilder bufferbuilder = tessellator.getBuffer();
        GlStateManager.matrixMode(GL_PROJECTION);
        GlStateManager.pushMatrix();
        GlStateManager.loadIdentity();
        Project.gluPerspective(120.0F, 1.0F, 0.05F, 10.0F);
        GlStateManager.matrixMode(GL_MODELVIEW);
        GlStateManager.pushMatrix();
        GlStateManager.loadIdentity();
        GlStateManager.color(1.0F, 1.0F, 1.0F, 1.0F);
        GlStateManager.rotate(180.0F, 1.0F, 0.0F, 0.0F);
        GlStateManager.rotate(90.0F, 0.0F, 0.0F, 1.0F);
        GlStateManager.enableBlend();
        GlStateManager.disableAlpha();
        GlStateManager.disableCull();
        GlStateManager.depthMask(false);
        GlStateManager.tryBlendFuncSeparate(GlStateManager.SourceFactor.SRC_ALPHA, GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA, GlStateManager.SourceFactor.ONE, GlStateManager.DestFactor.ZERO);

        for (int j = 0; j < 64; ++j) {
            GlStateManager.pushMatrix();
            float f = ((float) (j % 8) / 8.0F - 0.5F) / 64.0F;
            float f1 = ((float) (j / 8) / 8.0F - 0.5F) / 64.0F;
            GlStateManager.translate(f, f1, 0.0F);
            GlStateManager.rotate(MathHelper.sin(this.panoramaTimer / 400.0F) * 25.0F + 20.0F, 1.0F, 0.0F, 0.0F);
            GlStateManager.rotate(-this.panoramaTimer * 0.1F, 0.0F, 1.0F, 0.0F);

            for (int k = 0; k < 6; ++k) {
                GlStateManager.pushMatrix();
                if (k == 1) GlStateManager.rotate(90.0F, 0.0F, 1.0F, 0.0F);
                if (k == 2) GlStateManager.rotate(180.0F, 0.0F, 1.0F, 0.0F);
                if (k == 3) GlStateManager.rotate(-90.0F, 0.0F, 1.0F, 0.0F);
                if (k == 4) GlStateManager.rotate(90.0F, 1.0F, 0.0F, 0.0F);
                if (k == 5) GlStateManager.rotate(-90.0F, 1.0F, 0.0F, 0.0F);
                mc.getTextureManager().bindTexture(TITLE_PANORAMA_PATHS[k]);
                bufferbuilder.begin(GL_QUADS, DefaultVertexFormats.POSITION_TEX_COLOR);
                int l = 255 / (j + 1);
                bufferbuilder.pos(-1.0D, -1.0D, 1.0D).tex(0.0D, 0.0D).color(255, 255, 255, l).endVertex();
                bufferbuilder.pos(1.0D, -1.0D, 1.0D).tex(1.0D, 0.0D).color(255, 255, 255, l).endVertex();
                bufferbuilder.pos(1.0D, 1.0D, 1.0D).tex(1.0D, 1.0D).color(255, 255, 255, l).endVertex();
                bufferbuilder.pos(-1.0D, 1.0D, 1.0D).tex(0.0D, 1.0D).color(255, 255, 255, l).endVertex();
                tessellator.draw();
                GlStateManager.popMatrix();
            }
            GlStateManager.popMatrix();
            GlStateManager.colorMask(true, true, true, false);
        }
        bufferbuilder.setTranslation(0.0D, 0.0D, 0.0D);
        GlStateManager.colorMask(true, true, true, true);
        GlStateManager.matrixMode(GL_PROJECTION);
        GlStateManager.popMatrix();
        GlStateManager.matrixMode(GL_MODELVIEW);
        GlStateManager.popMatrix();
        GlStateManager.depthMask(true);
        GlStateManager.enableCull();
        GlStateManager.enableDepth();
    }
}
