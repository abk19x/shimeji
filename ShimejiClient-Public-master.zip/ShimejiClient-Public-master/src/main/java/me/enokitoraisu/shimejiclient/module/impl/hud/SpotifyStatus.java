package me.enokitoraisu.shimejiclient.module.impl.hud;

import me.enokitoraisu.shimejiclient.ShimejiClient;
import me.enokitoraisu.shimejiclient.manager.SpotifyManager;
import me.enokitoraisu.shimejiclient.module.Category;
import me.enokitoraisu.shimejiclient.module.HudModule;
import me.enokitoraisu.shimejiclient.utils.animation.Animate;
import me.enokitoraisu.shimejiclient.utils.animation.Easing;
import me.enokitoraisu.shimejiclient.utils.game.MouseUtil;
import me.enokitoraisu.shimejiclient.utils.math.ColorUtil;
import me.enokitoraisu.shimejiclient.utils.math.TimerUtil;
import me.enokitoraisu.shimejiclient.utils.renderer.BonIcon;
import me.enokitoraisu.shimejiclient.utils.renderer.RenderUtil;
import me.enokitoraisu.shimejiclient.utils.renderer.font.FontUtil;
import me.enokitoraisu.shimejiclient.utils.renderer.newfont.FontContainer;
import me.enokitoraisu.shimejiclient.value.values.StringValue;
import me.spotify.webapi.modelobjects.miscellaneous.CurrentlyPlayingContext;
import me.spotify.webapi.modelobjects.specification.ArtistSimplified;
import me.spotify.webapi.modelobjects.specification.Track;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.IImageBuffer;
import net.minecraft.client.renderer.ThreadDownloadImageData;
import net.minecraft.util.ResourceLocation;
import org.lwjgl.input.Keyboard;
import org.lwjgl.opengl.GL11;

import java.awt.*;
import java.awt.image.BufferedImage;
import java.util.Objects;
import java.util.concurrent.TimeUnit;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class SpotifyStatus extends HudModule {
    private final StringValue clientId = register(new StringValue("ClientID", "", true));
    private final Animate animate = new Animate();
    private final TimerUtil timer = new TimerUtil();
    public boolean playingMusic;
    private String currentId = "";
    private CurrentlyPlayingContext currentPlayingContext;
    private Track currentTrack;
    private float progress;
    private boolean downloadedCover;
    private ResourceLocation currentAlbumCover;
    private Color imageColor = Color.WHITE;
    private Color imageColor2 = Color.WHITE;

    public SpotifyStatus() {
        super("SpotifyStatus", "The client may freeze if turned on during initial setup. this is not a crash", Category.HUD, Keyboard.KEY_NONE, 10, 10, 140, 50);
    }

    @Override
    public void onEnable() {
        if (!fullNullCheck() || !matchID(clientId.getValue()).find()) {
            this.toggle();
            return;
        }
        if (ShimejiClient.spotifyManager == null) {
            ShimejiClient.spotifyManager = new SpotifyManager();

            if (clientId.getValue().equals("")) {
                toggle();
            } else {
                if (!Objects.equals(currentId, clientId.getValue())) {
                    currentId = clientId.getValue();
                    ShimejiClient.spotifyManager.build(clientId.getValue());
                    ShimejiClient.spotifyManager.startConnection();
                }
            }
        } else if (!Objects.equals(currentId, clientId.getValue())) {
            ShimejiClient.spotifyManager = null;
            ShimejiClient.spotifyManager = new SpotifyManager();
            currentId = clientId.getValue();
            ShimejiClient.spotifyManager.build(clientId.getValue());
            ShimejiClient.spotifyManager.startConnection();
        }
    }

    public Matcher matchID(String string) {
        return Pattern.compile("[a-fA-F0-9]{32}").matcher(string);
    }

    @Override
    public boolean drawScreen() {
        if (ShimejiClient.spotifyManager == null || ShimejiClient.spotifyManager.currentTrack == null || ShimejiClient.spotifyManager.currentPlayingContext == null)
            return true;
        if (currentTrack != ShimejiClient.spotifyManager.currentTrack || currentPlayingContext != ShimejiClient.spotifyManager.currentPlayingContext) {
            this.currentTrack = ShimejiClient.spotifyManager.currentTrack;
            this.currentPlayingContext = ShimejiClient.spotifyManager.currentPlayingContext;
        }
        this.playingMusic = currentPlayingContext.getIs_playing();

        RenderUtil.drawVerticalGradientRect(getX(), getY(), getWidth(), getHeight(), this.imageColor.getRGB(), this.imageColor2.getRGB());
        if (currentAlbumCover != null && downloadedCover) {
            mc.getTextureManager().bindTexture(currentAlbumCover);
            GlStateManager.color(1, 1, 1);
            GlStateManager.enableBlend();
            RenderUtil.drawImage(getX() + 2, getY() + 2, getHeight() - 10, getHeight() - 10);
        }
        GL11.glEnable(GL11.GL_SCISSOR_TEST);
        RenderUtil.glScissor(getX() + (getHeight() - 5), getY() + 3, getWidth() - (getHeight() - 5) - 3, FontContainer.SFUI20.getHeight() + 1.6f);
        if ((getHeight() - 5) + FontContainer.SFUI20.getStringWidth(currentTrack.getName()) > getWidth())
            animate.setEase(Easing.LINEAR).setSpeed(100).setMin(0).setMax(100).setReversed(timer.passedS(3)).update();
        else animate.setValue(0);
        float f = getWidth() - FontContainer.SFUI20.getStringWidth(currentTrack.getName()) - (getHeight() - 5) - 3;
        FontContainer.SFUI20.drawStringWithShadow(currentTrack.getName(), (getX() + (getHeight() - 5)) + f * (animate.getValue() / animate.getMax()), getY() + 4, -1, 0);
        GL11.glDisable(GL11.GL_SCISSOR_TEST);
        FontContainer.SFUI16.drawStringWithShadow(toStringArtists(currentTrack.getArtists()), getX() + (getHeight() - 5), getY() + 5 + FontContainer.SFUI20.getHeight(), -1, 0);
        if (timer.passedS(6)) {
            animate.reset();
            timer.reset();
        }

        FontUtil.bonicon20.drawString(currentPlayingContext.getShuffle_state() ? BonIcon.SHUFFLE_ON : BonIcon.SHUFFLE, getX() + (getHeight() - 5), getY() + (getHeight() - 15), -1);
        FontUtil.bonicon20.drawString(BonIcon.PREVIOUS, getX() + (getHeight() - 5) + 15, getY() + (getHeight() - 15), -1);
        FontUtil.bonicon20.drawString(playingMusic ? BonIcon.PLAY : BonIcon.PAUSE, getX() + (getHeight() - 5) + 30, getY() + (getHeight() - 15), -1);
        FontUtil.bonicon20.drawString(BonIcon.NEXT, getX() + (getHeight() - 5) + 45, getY() + (getHeight() - 15), -1);
        FontUtil.bonicon20.drawString(getRepeatButtonText(currentPlayingContext.getRepeat_state()), getX() + (getHeight() - 5) + 60, getY() + (getHeight() - 15), -1);

        progress = animate((float) (getWidth() - 32) * ((float) currentPlayingContext.getProgress_ms() / (float) currentTrack.getDurationMs()), progress, 0.05F);
        RenderUtil.drawRect(getX() + 2, getY() + (getHeight() - 5), getWidth() - 32, 3, 0xFF999999);
        RenderUtil.drawRect(getX() + 2, getY() + (getHeight() - 5), progress, 3, imageColor.getRGB());

        int d = currentPlayingContext.getProgress_ms();
        long ds = TimeUnit.MILLISECONDS.toSeconds(d) % 60;
        long dm = TimeUnit.MILLISECONDS.toMinutes(d) % 60;

        String r = String.format("%s:%s", dm < 10 ? "0" + dm : dm, ds < 10 ? "0" + ds : ds);

        FontContainer.SFUI16.drawStringWithShadow(r, getX() + (getWidth() - FontContainer.SFUI16.getStringWidth(r) - 2), getY() + (getHeight() - FontContainer.SFUI16.getHeight()), -1, 0);

        if (currentAlbumCover == null || !currentAlbumCover.toString().toLowerCase().contains(currentTrack.getAlbum().getId().toLowerCase())) {
            downloadedCover = false;
            @SuppressWarnings("all") ThreadDownloadImageData albumCover = new ThreadDownloadImageData(null, currentTrack.getAlbum().getImages()[1].getUrl(), null, new IImageBuffer() {
                @SuppressWarnings("all")
                @Override
                public BufferedImage parseUserSkin(BufferedImage image) {
                    imageColor = ColorUtil.averageColor(image, image.getWidth(), image.getHeight() / 2, 1);
                    imageColor2 = ColorUtil.darker(imageColor, 0.65F);
                    downloadedCover = true;
                    return image;
                }

                @Override
                public void skinAvailable() {
                }
            });
            mc.getTextureManager().loadTexture(currentAlbumCover = new ResourceLocation("spotifyAlbums/" + currentTrack.getAlbum().getId()), albumCover);
        }

        return !bounding(MouseUtil.getMouseX(), MouseUtil.getMouseY(), getX() + (getHeight() - 5), getY() + (getHeight() - 15), 75, FontUtil.bonicon20.getHeight());
    }

    @Override
    public boolean clicked(int mouseX, int mouseY, int button) {
        if (ShimejiClient.spotifyManager == null || ShimejiClient.spotifyManager.currentTrack == null || ShimejiClient.spotifyManager.currentPlayingContext == null)
            return false;

        String SHUFFLE_TEXT = currentPlayingContext.getShuffle_state() ? BonIcon.SHUFFLE_ON : BonIcon.SHUFFLE;
        String PLAYING_TEXT = playingMusic ? BonIcon.PLAY : BonIcon.PAUSE;
        if (button == 0 && bounding(mouseX, mouseY, getX() + (getHeight() - 5), getY() + (getHeight() - 15), (float) FontUtil.bonicon20.getStringWidth(SHUFFLE_TEXT), FontUtil.bonicon20.getHeight())) {
            new Thread(ShimejiClient.spotifyManager::toggleShuffleState).start();
            return true;
        }

        if (button == 0 && bounding(mouseX, mouseY, getX() + (getHeight() - 5) + 15, getY() + (getHeight() - 15), (float) FontUtil.bonicon20.getStringWidth(BonIcon.PREVIOUS), FontUtil.bonicon20.getHeight())) {
            new Thread(ShimejiClient.spotifyManager::skipToPreviousTrack).start();
            return true;
        }

        if (button == 0 && bounding(mouseX, mouseY, getX() + (getHeight() - 5) + 30, getY() + (getHeight() - 15), (float) FontUtil.bonicon20.getStringWidth(PLAYING_TEXT), FontUtil.bonicon20.getHeight())) {
            if (playingMusic) new Thread(ShimejiClient.spotifyManager::pausePlayback).start();
            else new Thread(ShimejiClient.spotifyManager::resumePlayback).start();
            return true;
        }

        if (button == 0 && bounding(mouseX, mouseY, getX() + (getHeight() - 5) + 45, getY() + (getHeight() - 15), (float) FontUtil.bonicon20.getStringWidth(BonIcon.NEXT), FontUtil.bonicon20.getHeight())) {
            new Thread(ShimejiClient.spotifyManager::skipTrack).start();
            return true;
        }

        if (button == 0 && bounding(mouseX, mouseY, getX() + (getHeight() - 5) + 60, getY() + (getHeight() - 15), (float) FontUtil.bonicon20.getStringWidth(getRepeatButtonText(currentPlayingContext.getRepeat_state())), FontUtil.bonicon20.getHeight())) {
            new Thread(() -> ShimejiClient.spotifyManager.changeRepeatState(getNextRepeatText(currentPlayingContext.getRepeat_state()))).start();
            return true;
        }
        return false;
    }

    public String getRepeatButtonText(String state) {
        switch (state) {
            case "context":
                return BonIcon.REPEAT_ON;
            case "track":
                return BonIcon.REPEAT_ON_ONE;
            case "off":
            default:
                return BonIcon.REPEAT;
        }
    }

    public String getNextRepeatText(String state) {
        switch (state) {
            case "off":
                return "context";
            case "context":
                return "track";
            case "track":
                return "off";
            default:
                return "";
        }
    }

    private String toStringArtists(ArtistSimplified[] artists) {
        StringBuilder text = new StringBuilder();
        for (int i = 0; i < artists.length; i++) {
            text.append(artists[i].getName());
            if (i != artists.length - 1)
                text.append(", ");
        }
        return text.toString();
    }

    public float animate(float target, float current, float speed) {
        boolean larger = target > current;

        if (speed < 0.0) {
            speed = 0.0f;
        } else if (speed > 1.0) {
            speed = 1.0f;
        }

        float dif = Math.max(target, current) - Math.min(target, current);
        float factor = dif * speed;

        if (factor < 0.1) {
            factor = 0.1f;
        }

        if (Math.abs(current - target) < factor) {
            current = target;
        } else if (larger) {
            current += factor;
        } else {
            current -= factor;
        }

        return current;
    }
}
