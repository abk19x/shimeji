package me.enokitoraisu.shimejiclient.module.impl.misc;

import me.enokitoraisu.shimejiclient.event.PrintChatEvent;
import me.enokitoraisu.shimejiclient.module.Category;
import me.enokitoraisu.shimejiclient.module.Module;
import me.enokitoraisu.shimejiclient.utils.math.MathUtil;
import net.minecraft.client.gui.GuiNewChat;
import net.minecraft.client.gui.GuiUtilRenderComponents;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.text.ITextComponent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import org.lwjgl.input.Keyboard;

import java.util.List;

public class AntiSpam extends Module {
    public AntiSpam() {
        super("AntiSpam", Category.MISC, Keyboard.KEY_NONE);
    }

    @SubscribeEvent
    public void onPrintChat(PrintChatEvent event) {
        if (!event.getDrawnChatLines().isEmpty()) {
            final GuiNewChat chat = mc.ingameGUI.getChatGUI();
            final int maxTextLength = MathHelper.floor(chat.getChatWidth() / chat.getChatScale());
            final List<ITextComponent> newLines = GuiUtilRenderComponents.splitText(event.getChatComponent(), maxTextLength, mc.fontRenderer, false, false);
            int spamCounter = 1;
            int matchingLines = 0;
            for (int i = event.getDrawnChatLines().size() - 1; i >= 0; --i) {
                final String oldLine = event.getDrawnChatLines().get(i).getChatComponent().getUnformattedText();
                if (matchingLines <= newLines.size() - 1) {
                    final String newLine = newLines.get(matchingLines).getUnformattedText();
                    if (matchingLines < newLines.size() - 1) {
                        if (oldLine.equals(newLine)) {
                            ++matchingLines;
                            continue;
                        }
                        matchingLines = 0;
                        continue;
                    } else {
                        if (!oldLine.startsWith(newLine)) {
                            matchingLines = 0;
                            continue;
                        }
                        if (i > 0 && matchingLines == newLines.size() - 1) {
                            final String twoLines = oldLine + event.getDrawnChatLines().get(i - 1).getChatComponent().getUnformattedText();
                            final String addedText = MathUtil.cleanColor(twoLines.substring(newLine.length()));
                            if (addedText.startsWith(" [x") && addedText.endsWith("]")) {
                                final String oldSpamCounter = addedText.substring(3, addedText.length() - 1);
                                if (isInteger(oldSpamCounter)) {
                                    spamCounter += Integer.parseInt(oldSpamCounter);
                                    ++matchingLines;
                                    continue;
                                }
                            }
                        }
                        if (oldLine.length() == newLine.length()) {
                            ++spamCounter;
                        } else {
                            final String addedText2 = MathUtil.cleanColor(oldLine.substring(newLine.length()));
                            if (!addedText2.startsWith(" [x") || !addedText2.endsWith("]")) {
                                matchingLines = 0;
                                continue;
                            }
                            final String oldSpamCounter2 = addedText2.substring(3, addedText2.length() - 1);
                            if (!isInteger(oldSpamCounter2)) {
                                matchingLines = 0;
                                continue;
                            }
                            spamCounter += Integer.parseInt(oldSpamCounter2);
                        }
                    }
                }
                if (i + matchingLines >= i) {
                    event.getDrawnChatLines().subList(i, i + matchingLines + 1).clear();
                }
                matchingLines = 0;
            }
            if (spamCounter > 1) {
                event.getChatComponent().appendText(" \u00A7r[x" + spamCounter + "]");
            }
        }
    }

    public boolean isInteger(String s) {
        try {
            Integer.parseInt(s);
            return true;
        } catch (NumberFormatException ignored) {
            return false;
        }
    }
}
