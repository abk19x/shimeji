package me.enokitoraisu.shimejiclient.mixin;

import me.enokitoraisu.shimejiclient.ShimejiClient;
import me.enokitoraisu.shimejiclient.ShimejiRPC;
import me.enokitoraisu.shimejiclient.utils.animation.Delta;
import net.minecraft.client.Minecraft;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Constant;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyConstant;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import static me.enokitoraisu.shimejiclient.ShimejiClient.ModName;
import static me.enokitoraisu.shimejiclient.ShimejiClient.ModVersion;

@Mixin(Minecraft.class)
public abstract class MixinMinecraft {
    private static final Logger ShimejiLOGGER = LogManager.getLogger("ShimejiClient/Minecraft");

    @Inject(method = "shutdown()V", at = @At(value = "HEAD"))
    private void shutdown(CallbackInfo ci) {
        ShimejiClient.configManager.saveConfigs();
        ShimejiLOGGER.info("Config saved!");
        ShimejiRPC.stop();
        ShimejiLOGGER.info("DiscordRPC Stopped!");
        ShimejiLOGGER.info("{} ShutDown", ModName);
    }

    @ModifyConstant(method = "createDisplay()V", constant = @Constant(stringValue = "Minecraft 1.12.2"))
    private String setTitle(String newTitle) {
        return String.format("%s %s", ModName, ModVersion);
    }

    @Inject(method = "runGameLoop()V", at = @At(value = "HEAD"))
    private void runGameLoop(CallbackInfo ci) {
        Delta.updateDeltaTime();
    }
}
