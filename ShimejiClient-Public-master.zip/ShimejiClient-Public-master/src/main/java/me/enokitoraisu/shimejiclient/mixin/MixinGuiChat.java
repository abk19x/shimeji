package me.enokitoraisu.shimejiclient.mixin;

import me.enokitoraisu.shimejiclient.ShimejiClient;
import me.enokitoraisu.shimejiclient.module.HudModule;
import me.enokitoraisu.shimejiclient.module.Module;
import net.minecraft.client.gui.GuiChat;
import net.minecraft.client.gui.GuiScreen;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(GuiChat.class)
public abstract class MixinGuiChat extends GuiScreen {
    @Inject(method = "drawScreen(IIF)V", at = @At(value = "HEAD"))
    public void drawScreen(int mouseX, int mouseY, float partialTicks, CallbackInfo ci) {
        for (Module m : ShimejiClient.moduleManager.modules) {
            if (m.isToggled() && m instanceof HudModule) {
                HudModule hudModule = (HudModule) m;
                hudModule.drag(mouseX, mouseY);
                hudModule.drawChatScreen(mouseX, mouseY);
            }
        }
    }

    @Inject(method = "mouseClicked(III)V", at = @At(value = "HEAD"))
    public void mouseClicked(int mouseX, int mouseY, int mouseButton, CallbackInfo ci) {
        ShimejiClient.moduleManager.modules.stream()
                .filter(m -> m.isToggled() && m instanceof HudModule)
                .map(m -> (HudModule) m)
                .filter(hudModule -> hudModule.bounding(mouseX, mouseY))
                .forEach(hudModule -> {
                    if (!hudModule.clicked(mouseX, mouseY, mouseButton)) hudModule.setClicked(true);
                });
    }

    @Override
    public void mouseReleased(int mouseX, int mouseY, int state) {
        for (Module m : ShimejiClient.moduleManager.modules) {
            if (m.isToggled() && m instanceof HudModule) {
                HudModule hudModule = (HudModule) m;
                if (hudModule.isClicked()) hudModule.setClicked(false);
            }
        }
    }

    @Inject(method = "onGuiClosed()V", at = @At(value = "HEAD"))
    public void onGuiClosed(CallbackInfo ci) {
        for (Module m : ShimejiClient.moduleManager.modules) {
            if (m.isToggled() && m instanceof HudModule) {
                HudModule hudModule = (HudModule) m;
                if (hudModule.isClicked()) {
                    hudModule.setClicked(false);
                    hudModule.setDragging(false);
                }
            }
        }
    }
}
