package me.enokitoraisu.shimejiclient.module.impl.client;

@SuppressWarnings("unused")
public class MFriendGui/* extends Module*/ {
    /*
    public MFriendGui() {
        super("FriendGui", Category.CLIENT, Keyboard.KEY_NONE);
    }

    @Override
    public void onEnable() {
        mc.displayGuiScreen(new FriendGui());
        toggle();
    }
     */
}
