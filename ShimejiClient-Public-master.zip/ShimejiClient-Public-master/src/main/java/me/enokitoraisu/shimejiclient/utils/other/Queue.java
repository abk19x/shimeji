package me.enokitoraisu.shimejiclient.utils.other;

import java.util.ArrayList;
import java.util.List;

public class Queue<T> {
    final ArrayList<T> queue = new ArrayList<>();

    public Queue(List<T> elements) {
        queue.addAll(elements);
    }

    public Queue() {
        this(new ArrayList<>());
    }

    public ArrayList<T> getQueue() {
        return queue;
    }

    public T poll() {
        if (queue.isEmpty()) {
            return null;
        }
        T element = queue.get(0);
        queue.remove(0);
        return element;
    }

    public void add(T element) {
        queue.add(element);
    }
}