package me.enokitoraisu.shimejiclient.mixin;

import me.enokitoraisu.shimejiclient.event.BlockEvent;
import me.enokitoraisu.shimejiclient.event.ClickBlockEvent;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.multiplayer.PlayerControllerMP;
import net.minecraft.client.multiplayer.WorldClient;
import net.minecraft.util.EnumActionResult;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraftforge.common.MinecraftForge;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(PlayerControllerMP.class)
public class MixinPlayerControllerMP {
    @Shadow
    @Final
    private Minecraft mc;

    @Inject(method = "processRightClickBlock(Lnet/minecraft/client/entity/EntityPlayerSP;Lnet/minecraft/client/multiplayer/WorldClient;Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/util/EnumFacing;Lnet/minecraft/util/math/Vec3d;Lnet/minecraft/util/EnumHand;)Lnet/minecraft/util/EnumActionResult;", at = @At(value = "TAIL"))
    public void processRightClickBlockReturn(EntityPlayerSP player, WorldClient worldIn, BlockPos pos, EnumFacing direction, Vec3d vec, EnumHand hand, CallbackInfoReturnable<EnumActionResult> cir) {
        BlockEvent.Place placeEvent = new BlockEvent.Place(pos);
        MinecraftForge.EVENT_BUS.post(placeEvent);
    }

    @Inject(method = "onPlayerDamageBlock(Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/util/EnumFacing;)Z", at = @At(value = "HEAD"), cancellable = true)
    public void onPlayerDamageBlock(BlockPos posBlock, EnumFacing directionFacing, CallbackInfoReturnable<Boolean> cir) {
        BlockEvent.Damage damageEvent = new BlockEvent.Damage(posBlock);
        MinecraftForge.EVENT_BUS.post(damageEvent);
        if (damageEvent.isCanceled()) {
            cir.setReturnValue(false);
        }
    }

    @Inject(method = "onPlayerDestroyBlock(Lnet/minecraft/util/math/BlockPos;)Z", at = @At(value = "RETURN"))
    public void onPlayerDestroyBlockReturn(BlockPos pos, CallbackInfoReturnable<Boolean> cir) {
        BlockEvent.Break breakEvent = new BlockEvent.Break(pos);
        MinecraftForge.EVENT_BUS.post(breakEvent);
    }

    @Inject(method = "clickBlock(Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/util/EnumFacing;)Z", at = @At(value = "HEAD"), cancellable = true)
    public void clickBlock(BlockPos loc, EnumFacing face, CallbackInfoReturnable<Boolean> cir) {
        ClickBlockEvent clickBlockEvent = new ClickBlockEvent(loc, face);
        MinecraftForge.EVENT_BUS.post(clickBlockEvent);
        if (clickBlockEvent.isCanceled()) {
            cir.setReturnValue(true);
        }
    }
}
