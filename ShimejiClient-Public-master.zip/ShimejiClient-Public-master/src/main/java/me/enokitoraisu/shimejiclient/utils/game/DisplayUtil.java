package me.enokitoraisu.shimejiclient.utils.game;

import me.enokitoraisu.shimejiclient.utils.interfaces.Util;
import net.minecraft.client.gui.ScaledResolution;
import org.lwjgl.opengl.Display;

public class DisplayUtil implements Util {
    public static int getWidth() {
        return new ScaledResolution(mc).getScaledWidth();
    }

    public static int getHeight() {
        return new ScaledResolution(mc).getScaledHeight();
    }

    public static ScaledResolution getScaledResolution() {
        return new ScaledResolution(mc);
    }

    public static void setTitle(String title) {
        if (!Display.getTitle().equals(title))
            Display.setTitle(title);
    }
}
