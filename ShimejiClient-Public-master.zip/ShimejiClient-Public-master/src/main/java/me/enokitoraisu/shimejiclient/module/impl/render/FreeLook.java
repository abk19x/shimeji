package me.enokitoraisu.shimejiclient.module.impl.render;

import me.enokitoraisu.shimejiclient.event.TurnEvent;
import me.enokitoraisu.shimejiclient.module.Category;
import me.enokitoraisu.shimejiclient.module.Module;
import me.enokitoraisu.shimejiclient.value.values.BooleanValue;
import net.minecraft.util.math.MathHelper;
import net.minecraftforge.client.event.EntityViewRenderEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import org.lwjgl.input.Keyboard;

@SuppressWarnings("unused")
public class FreeLook extends Module {
    private final BooleanValue third = register(new BooleanValue("Always", true));

    private int enablePersonView;
    private float yaw = 0;
    private float pitch = 0;

    public FreeLook() {
        super("FreeLook", Category.RENDER, Keyboard.KEY_NONE);
    }

    @Override
    public void onEnable() {
        if (fullNullCheck()) {
            this.enablePersonView = mc.gameSettings.thirdPersonView;
            this.yaw = 0;
            this.pitch = 0;
            if (!this.third.getValue()) mc.gameSettings.thirdPersonView = 1;
        }
    }

    @Override
    public void onTick() {
        if (this.third.getValue())
            mc.gameSettings.thirdPersonView = 1;
    }

    @Override
    public void onDisable() {
        mc.gameSettings.thirdPersonView = enablePersonView;
    }

    @SubscribeEvent
    public void onCameraSetup(EntityViewRenderEvent.CameraSetup event) {
        event.setYaw(event.getYaw() + this.yaw);
        event.setPitch(event.getPitch() + this.pitch);
    }

    @SubscribeEvent
    public void onTurn(TurnEvent event) {
        this.yaw = this.yaw + event.getYaw() * 0.15F;
        this.pitch = this.pitch - event.getPitch() * 0.15F;
        this.pitch = MathHelper.clamp(this.pitch, -90.0F, 90.0F);
        event.setCanceled(true);
    }
}
