package me.enokitoraisu.shimejiclient.module.impl.render;

import me.enokitoraisu.shimejiclient.module.Category;
import me.enokitoraisu.shimejiclient.module.Module;
import org.lwjgl.input.Keyboard;

@SuppressWarnings("unused")
public class CameraClip extends Module {
    public static CameraClip INSTANCE = new CameraClip();

    public CameraClip() {
        super("CameraClip", Category.RENDER, Keyboard.KEY_NONE);
        INSTANCE = this;
    }
}
