package me.enokitoraisu.shimejiclient.utils.game.nbs;

import java.io.File;

public abstract class SongDecoder {
    public abstract Song parse(File file);
}