package me.enokitoraisu.shimejiclient.manager;

import me.enokitoraisu.shimejiclient.ShimejiClient;
import me.enokitoraisu.shimejiclient.module.Category;
import me.enokitoraisu.shimejiclient.module.HudModule;
import me.enokitoraisu.shimejiclient.module.Module;
import org.apache.logging.log4j.LogManager;
import org.reflections.Reflections;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Set;

public class ModuleManager {
    public ArrayList<Module> modules = new ArrayList<>();

    public ModuleManager() {
        Reflections reflections = new Reflections("me.enokitoraisu.shimejiclient.module.impl");
        Set<Class<? extends Module>> subTypes = reflections.getSubTypesOf(Module.class);

        for (Class<? extends Module> subType : subTypes) {
            try {
                if (subType != HudModule.class)
                    modules.add(subType.newInstance());
            } catch (InstantiationException | NoClassDefFoundError | IllegalAccessException e) {
                LogManager.getLogger(String.format("%s/ModuleManager", ShimejiClient.ModID)).error(e);
            }
        }

        /*
        //hud
        modules.add(new MArrayList());
        modules.add(new Coords());
        modules.add(new Greeter());
        modules.add(new WaterMark());
        modules.add(new TargetHUD());
        modules.add(new KeyStroke());
        modules.add(new NewDragHUD());
        //client
        modules.add(new Gui());
        modules.add(new MDiscordRPC());
        modules.add(new Notification());
        modules.add(new MMainMenu());
        modules.add(new ChatNotify());
        modules.add(new AutoSave());
        //combat
        modules.add(new TPAura());
        modules.add(new Criticals());
        modules.add(new InstantBurrow());
        modules.add(new KillAura());
        //misc
        modules.add(new Suicide());
        modules.add(new ChatAppend());
        modules.add(new Timer());
        modules.add(new ChatIgnore());
        modules.add(new PingSpoof());
        modules.add(new NoSwing());
        modules.add(new ShimejiName());
        modules.add(new AntiAntiXray());
        modules.add(new AntiGhostBlock());
        modules.add(new SpeedMine());
        //movement
        modules.add(new AutoSprint());
        modules.add(new AutoWalk());
        modules.add(new Flight());
        modules.add(new Speed());
        modules.add(new NoSlow());
        modules.add(new Velocity());
        modules.add(new AirJump());
        modules.add(new Eagle());
        //player
        modules.add(new AutoTunnel());
        modules.add(new AutoNaeta());
        modules.add(new RollbackDetect());
        modules.add(new Scaffold());
        modules.add(new FastPlace());
        modules.add(new MiddleClick());
        modules.add(new NoFall());
        modules.add(new BuildRandom());
        modules.add(new FloorBuilder());
        //render
        modules.add(new Animation());
        modules.add(new FullBright());
        modules.add(new Capes());
        modules.add(new NameTags());
        modules.add(new NoRender());
        modules.add(new CameraClip());
        modules.add(new MotionBlur());
        modules.add(new ShulkerESP());
        modules.add(new BurrowESP());
        modules.add(new BreakingESP());
        modules.add(new FreeLook());
        //sort
         */

        modules.sort(Comparator.comparing(Module::getName));
    }

    public List<Module> getModulesWithCategories(Category c) {
        ArrayList<Module> arrayList = new ArrayList<>();
        for (Module module : this.modules) {
            if (module.category != c) continue;
            arrayList.add(module);
        }
        return arrayList;
    }

    public List<Module> getModuleList() {
        return this.modules;
    }
}