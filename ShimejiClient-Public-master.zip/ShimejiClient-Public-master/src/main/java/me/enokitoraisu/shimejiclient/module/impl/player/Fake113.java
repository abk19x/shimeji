package me.enokitoraisu.shimejiclient.module.impl.player;

import me.enokitoraisu.shimejiclient.event.PacketEvent;
import me.enokitoraisu.shimejiclient.module.Category;
import me.enokitoraisu.shimejiclient.module.Module;
import net.minecraft.item.*;
import net.minecraft.network.play.client.CPacketPlayerTryUseItem;
import net.minecraft.util.EnumHand;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import org.lwjgl.input.Keyboard;

public class Fake113 extends Module {
    public Fake113() {
        super("Fake1.13", Category.MISC, Keyboard.KEY_NONE);
    }

    @SubscribeEvent
    public void onUsedItem(PacketEvent.Send event) {
        if (event.getPacket() instanceof CPacketPlayerTryUseItem) {
            ItemStack heldStack = mc.player.inventory.getStackInSlot(mc.player.inventory.currentItem);
            if (heldStack.getItem() instanceof ItemSnowball ||
                    heldStack.getItem() instanceof ItemLingeringPotion ||
                    heldStack.getItem() instanceof ItemSplashPotion ||
                    heldStack.getItem() instanceof ItemEnderPearl ||
                    heldStack.getItem() instanceof ItemEnderEye ||
                    heldStack.getItem() instanceof ItemExpBottle ||
                    heldStack.getItem() instanceof ItemElytra) {
                mc.player.swingArm(EnumHand.MAIN_HAND);
            }
        }
    }
}
