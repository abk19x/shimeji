package me.enokitoraisu.shimejiclient.module.impl.combat;

import me.enokitoraisu.shimejiclient.event.PacketEvent;
import me.enokitoraisu.shimejiclient.module.Category;
import me.enokitoraisu.shimejiclient.module.Module;
import me.enokitoraisu.shimejiclient.value.values.ModeValue;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.network.play.client.CPacketPlayer;
import net.minecraft.network.play.client.CPacketUseEntity;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import org.lwjgl.input.Keyboard;

@SuppressWarnings("unused")
public class Criticals extends Module {
    public ModeValue mode = register(new ModeValue("Mode", "Packet", "Packet", "NCP"));

    public Criticals() {
        super("Criticals", Category.COMBAT, Keyboard.KEY_NONE);
    }

    public void onTick() {
        setTags(mode.getValue());
    }

    @SubscribeEvent
    public void onPacket(PacketEvent.Send event) {
        switch (mode.getValue()) {
            case "Packet":
                if (event.getPacket() instanceof CPacketUseEntity) {
                    CPacketUseEntity packet = (CPacketUseEntity) event.packet;
                    if (packet.getAction() == CPacketUseEntity.Action.ATTACK && packet.getEntityFromWorld(mc.world) instanceof EntityLivingBase) {
                        mc.player.connection.sendPacket(new CPacketPlayer.Position(mc.player.posX, mc.player.posY + 0.000000128, mc.player.posZ, true));
                        mc.player.connection.sendPacket(new CPacketPlayer.Position(mc.player.posX, mc.player.posY, mc.player.posZ, false));
                    }
                }
                break;
            case "NCP":
                if (event.packet instanceof CPacketUseEntity) {
                    CPacketUseEntity packet = (CPacketUseEntity) event.packet;
                    if (packet.getAction() == CPacketUseEntity.Action.ATTACK && packet.getEntityFromWorld(mc.world) instanceof EntityLivingBase) {
                        double random = Math.random() * 0.0003;
                        mc.player.connection.sendPacket(new CPacketPlayer.Position(mc.player.posX, mc.player.posY + 0.06252F + random, mc.player.posZ, true));
                        mc.player.connection.sendPacket(new CPacketPlayer.Position(mc.player.posX, mc.player.posY + random, mc.player.posZ, false));
                    }
                }
                break;
        }
    }
}
