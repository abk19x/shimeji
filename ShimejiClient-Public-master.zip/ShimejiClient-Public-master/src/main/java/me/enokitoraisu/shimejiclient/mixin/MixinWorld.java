package me.enokitoraisu.shimejiclient.mixin;

import me.enokitoraisu.shimejiclient.event.SpawnParticleEvent;
import net.minecraft.util.EnumParticleTypes;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;
import net.minecraftforge.common.MinecraftForge;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(World.class)
public class MixinWorld {
    @Inject(method = "spawnParticle(Lnet/minecraft/util/EnumParticleTypes;DDDDDD[I)V", at = @At(value = "HEAD"), cancellable = true)
    public void spawnParticle(EnumParticleTypes particleType, double xCoord, double yCoord, double zCoord, double xSpeed, double ySpeed, double zSpeed, int[] parameters, CallbackInfo ci) {
        SpawnParticleEvent spawnParticleEvent = new SpawnParticleEvent(particleType, new Vec3d(xCoord, yCoord, zCoord), xSpeed, ySpeed, zSpeed, parameters);
        MinecraftForge.EVENT_BUS.post(spawnParticleEvent);

        if (spawnParticleEvent.isCanceled())
            ci.cancel();
    }
}
