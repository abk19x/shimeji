package me.enokitoraisu.shimejiclient.value.values;

import me.enokitoraisu.shimejiclient.value.ValueBase;

import java.util.function.Predicate;

public class StringValue extends ValueBase<String> {
    private final boolean password;

    public StringValue(String name, String value) {
        this(name, value, false, v -> true);
    }

    public StringValue(String name, String value, Predicate<String> visibility) {
        this(name, value, false, visibility);
    }

    public StringValue(String name, String value, boolean password) {
        this(name, value, password, v -> true);
    }

    public StringValue(String name, String value, boolean password, Predicate<String> visibility) {
        super(name, value, visibility);
        this.password = password;
    }

    public boolean isPassword() {
        return password;
    }
}
