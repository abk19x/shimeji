package me.enokitoraisu.shimejiclient.module.impl.player;

import me.enokitoraisu.shimejiclient.ShimejiClient;
import me.enokitoraisu.shimejiclient.event.PacketEvent;
import me.enokitoraisu.shimejiclient.module.Category;
import me.enokitoraisu.shimejiclient.module.Module;
import me.enokitoraisu.shimejiclient.value.values.ModeValue;
import net.minecraft.network.play.server.SPacketPlayerPosLook;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import org.lwjgl.input.Keyboard;

@SuppressWarnings("unused")
public class RollbackDetect extends Module {
    public ModeValue style = register(new ModeValue("Style", "Sushi", "Sushi", "Shimeji"));

    public RollbackDetect() {
        super("RollbackDetect", Category.PLAYER, Keyboard.KEY_NONE);
    }

    @SubscribeEvent
    public void GetPacket(PacketEvent.Receive Packet) {
        if (fullNullCheck()) {
            if (Packet.getPacket() instanceof SPacketPlayerPosLook) {
                SPacketPlayerPosLook e = (SPacketPlayerPosLook) Packet.getPacket();
                if (style.getValue().equals("Sushi")) {
                    sendMessage(String.format("\u304A\u3044\u30ED\u30EB\u30D0\u3069\u308A\u3083\u30FC\u30FC\u30FC\u30FC %s %s %s", e.getX(), e.getY(), e.getZ()));
                } else if (style.getValue().equals("Shimeji")) {
                    sendMessage(String.format(ShimejiClient.PrefixFormat + "Rollback %.1f %.0f %.1f", e.getX(), e.getY(), e.getZ()));
                }
            }
        }
    }
}
