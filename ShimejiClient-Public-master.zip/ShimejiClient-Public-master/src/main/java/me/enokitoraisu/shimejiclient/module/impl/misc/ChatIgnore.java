package me.enokitoraisu.shimejiclient.module.impl.misc;

import me.enokitoraisu.shimejiclient.ShimejiClient;
import me.enokitoraisu.shimejiclient.event.PacketEvent;
import me.enokitoraisu.shimejiclient.module.Category;
import me.enokitoraisu.shimejiclient.module.Module;
import me.enokitoraisu.shimejiclient.utils.chat.SenderUtil;
import me.enokitoraisu.shimejiclient.value.values.BooleanValue;
import net.minecraft.network.play.server.SPacketChat;
import net.minecraft.util.text.Style;
import net.minecraft.util.text.TextComponentString;
import net.minecraft.util.text.event.HoverEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import org.lwjgl.input.Keyboard;

import java.util.ArrayList;
import java.util.List;

@SuppressWarnings("unused")
public class ChatIgnore extends Module {
    public static ChatIgnore INSTANCE = new ChatIgnore();
    //private final Map<Integer, Map<String, Integer>> messageIDs = new HashMap<>();
    public List<String> ignore_user = new ArrayList<>();
    public SenderUtil sender = new SenderUtil();

    public BooleanValue debug = register(new BooleanValue("Debug", false));

    public ChatIgnore() {
        super("ChatIgnore", Category.MISC, Keyboard.KEY_NONE);
        INSTANCE = this;
    }

    @SubscribeEvent
    public void onPacket(PacketEvent.Receive event) {
        if (fullNullCheck()) {
            if (event.getPacket() instanceof SPacketChat) {
                for (String s : ignore_user) {
                    String message = ((SPacketChat) event.getPacket()).getChatComponent().getUnformattedText();
                    if (s.equalsIgnoreCase(message.split(">")[0].replace("<", "").replace("\u00A7r", ""))) {
                        event.setCanceled(true);
                        logger.info(String.format("Ignore Message %s > %s", s, message.replace("\u00A7r", "").replaceAll(String.format("<%s> ", s), "")));

                        if (debug.getValue()) {
                            Style latest_msg = new Style();
                            latest_msg.setHoverEvent(new HoverEvent(HoverEvent.Action.SHOW_TEXT, new TextComponentString(message)));

                            sendCustomMessage(String.format("Ignore Player %s", s), 489741561, s, latest_msg);
                        }
                    }
                }
            }
        }
    }

    public void sendCustomMessage(String msg, int Id, String key, Style s) {
        String message = String.format("%s%s", ShimejiClient.PrefixFormat, msg);

        mc.addScheduledTask(() -> sender.sendDeleteComponent(new TextComponentString(message).setStyle(s), Id, key));
    }
}
