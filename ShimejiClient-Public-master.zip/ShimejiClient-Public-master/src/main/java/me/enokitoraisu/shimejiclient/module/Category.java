package me.enokitoraisu.shimejiclient.module;

public enum Category {
    COMBAT("Combat", "E", "A"),
    MISC("Misc", "Q", "D"),
    MOVEMENT("Movement", "G", "E"),
    CLIENT("Client", "h", "Q"),
    RENDER("Render", "v", "v"),
    PLAYER("Player", "u", "n"),
    HUD("HUD", "w", "K");

    private final String name;
    private final String icon;
    private final String icon2;

    Category(String name, String icon, String icon2) {
        this.name = name;
        this.icon = icon;
        this.icon2 = icon2;
    }

    public String getName() {
        return this.name;
    }

    public String getIcon() {
        return this.icon;
    }

    public String getIcon2() {
        return this.icon2;
    }
}
