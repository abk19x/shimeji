package me.enokitoraisu.shimejiclient.gui.shimeji.componet.componets;

import me.enokitoraisu.shimejiclient.gui.GuiSetting;
import me.enokitoraisu.shimejiclient.gui.shimeji.Panel;
import me.enokitoraisu.shimejiclient.gui.shimeji.componet.Component;
import me.enokitoraisu.shimejiclient.module.Module;
import me.enokitoraisu.shimejiclient.utils.renderer.RenderUtil;
import me.enokitoraisu.shimejiclient.utils.renderer.font.FontUtil;

public class DrawnButton extends Component {
    public final Module module;
    public final ModuleButton moduleButton;

    public DrawnButton(Module module, ModuleButton moduleButton, int x, int width, int height) {
        this.module = module;
        this.moduleButton = moduleButton;
        this.x = x;
        this.width = width;
        this.height = height;
    }

    @Override
    public void drawScreen(int mouseX, int mouseY, int offsetY) {
        this.visible = true;
        if (moduleButton.components.stream().filter(Component::isVisible).count() > 2) {
            this.y = offsetY + 3;
            Panel.offset += 3;
            RenderUtil.drawRect(x, offsetY, width, 3, 0xCB191919);
            RenderUtil.drawRect(x + width * 0.125f, offsetY + 1, width * 0.75F, 1, GuiSetting.getAccent());
        } else {
            this.y = offsetY;
        }
        RenderUtil.drawRect(x, y, width, height, 0xCB191919);

        if (bounding(mouseX, mouseY))
            RenderUtil.drawRect(x, y, width, height, 0x40000000);

        RenderUtil.drawOutLineRect(x + 5, y + 2, height - 4, height - 4, 0.5f, -1);
        if (module.drawn) RenderUtil.drawRect(x + 6, y + 3, height - 6, height - 6, GuiSetting.getAccent());

        FontUtil.sfui18.drawStringWithShadow("Drawn", x + 6 + (this.height - 2), y + (height - FontUtil.sfui18.getHeight()) / 2f, -1);
    }

    @Override
    public void mouseClicked(int mouseX, int mouseY, int mouseButton) {
        if (bounding(mouseX, mouseY) && mouseButton == 0) {
            module.drawn = !module.drawn;
        }
    }
}
