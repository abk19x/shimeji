package me.enokitoraisu.shimejiclient.utils.game;

import me.enokitoraisu.shimejiclient.utils.interfaces.Util;
import net.minecraft.client.gui.ScaledResolution;
import org.lwjgl.input.Mouse;

public class MouseUtil implements Util {
    private int x;
    private int y;
    private int width;
    private int height;

    public MouseUtil(int x, int y, int width, int height) {
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
    }

    public static int convertToMouse(int key) {
        switch (key) {
            case -2:
                return 0;
            case -3:
                return 1;
            case -4:
                return 2;
            case -5:
                return 3;
            case -6:
                return 4;
        }
        return -1;
    }

    public static int getMouseX() {
        int scaledWidth = new ScaledResolution(mc).getScaledWidth();
        return Mouse.getX() * scaledWidth / mc.displayWidth;
    }

    public static int getMouseY() {
        int scaledHeight = new ScaledResolution(mc).getScaledHeight();
        return scaledHeight - Mouse.getY() * scaledHeight / mc.displayHeight - 1;
    }

    public boolean bounding(int mouseX, int mouseY) {
        return this.x < mouseX && this.x + this.width > mouseX && this.y < mouseY && this.y + this.height > mouseY;
    }

    public int getX() {
        return x;
    }

    public void setX(int x) {
        this.x = x;
    }

    public int getY() {
        return y;
    }

    public void setY(int y) {
        this.y = y;
    }

    public int getWidth() {
        return width;
    }

    public void setWidth(int width) {
        this.width = width;
    }

    public int getHeight() {
        return height;
    }

    public void setHeight(int height) {
        this.height = height;
    }

    public void setAll(int x, int y, int width, int height) {
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
    }
}