package me.enokitoraisu.shimejiclient.module.impl.client;

import me.enokitoraisu.shimejiclient.module.Category;
import me.enokitoraisu.shimejiclient.module.Module;
import me.enokitoraisu.shimejiclient.value.values.ModeValue;
import net.minecraft.client.entity.AbstractClientPlayer;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.entity.RenderPlayer;
import net.minecraft.client.renderer.entity.layers.LayerRenderer;
import net.minecraft.init.Items;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.math.MathHelper;
import org.lwjgl.input.Keyboard;

import javax.annotation.Nonnull;

@SuppressWarnings("unused")
public class Capes extends Module {
    public static Capes INSTANCE = new Capes();

    public ModeValue capeType = register(new ModeValue("Type", "Default", "Default", "Black", "Texture"));

    public Capes() {
        super("Capes", Category.CLIENT, Keyboard.KEY_NONE);
        INSTANCE = this;
    }

    @Override
    public void onTick() {
        setTags(capeType.getValue());
    }

    public static class RenderCape implements LayerRenderer<AbstractClientPlayer> {
        private final RenderPlayer playerRenderer;

        public RenderCape(RenderPlayer player) {
            this.playerRenderer = player;
        }

        @Override
        public void doRenderLayer(@Nonnull AbstractClientPlayer player, float limbSwing, float limbSwingAmount, float partialTicks, float ageInTicks, float netHeadYaw, float headPitch, float scale) {
            if (mc.player.equals(player)) {
                if (Capes.INSTANCE.toggled && mc.player.inventory.armorItemInSlot(2).getItem() != Items.ELYTRA) {
                    GlStateManager.color(1.0f, 1.0f, 1.0f, 1.0f);
                    if (Capes.INSTANCE.capeType.getValue().equals("Default"))
                        this.playerRenderer.bindTexture(new ResourceLocation("shimeji/image/default.png"));
                    if (Capes.INSTANCE.capeType.getValue().equals("Black"))
                        this.playerRenderer.bindTexture(new ResourceLocation("shimeji/image/black.png"));
                    if (Capes.INSTANCE.capeType.getValue().equals("Texture"))
                        this.playerRenderer.bindTexture(new ResourceLocation("shimeji/image/capes.png"));
                    GlStateManager.pushMatrix();
                    GlStateManager.translate(0.0f, 0.0f, 0.125f);
                    final double d0 = player.prevChasingPosX + (player.chasingPosX - player.prevChasingPosX) * partialTicks - (player.prevPosX + (player.posX - player.prevPosX) * partialTicks);
                    final double d2 = player.prevChasingPosY + (player.chasingPosY - player.prevChasingPosY) * partialTicks - (player.prevPosY + (player.posY - player.prevPosY) * partialTicks);
                    final double d3 = player.prevChasingPosZ + (player.chasingPosZ - player.prevChasingPosZ) * partialTicks - (player.prevPosZ + (player.posZ - player.prevPosZ) * partialTicks);
                    final float f11 = player.prevRenderYawOffset + (player.renderYawOffset - player.prevRenderYawOffset) * partialTicks;
                    final double d4 = MathHelper.sin(f11 * 3.1415927f / 180.0f);
                    final double d5 = -MathHelper.cos(f11 * 3.1415927f / 180.0f);
                    float f12 = (float) d2 * 10.0f;
                    f12 = MathHelper.clamp(f12, -6.0f, 32.0f);
                    float f13 = (float) (d0 * d4 + d3 * d5) * 100.0f;
                    final float f14 = (float) (d0 * d5 - d3 * d4) * 100.0f;
                    if (f13 < 0.0f) f13 = 0.0f;
                    if (f13 > 165.0f) f13 = 165.0f;
                    final float f15 = player.prevCameraYaw + (player.cameraYaw - player.prevCameraYaw) * partialTicks;
                    f12 += MathHelper.sin((player.prevDistanceWalkedModified + (player.distanceWalkedModified - player.prevDistanceWalkedModified) * partialTicks) * 6.0f) * 32.0f * f15;
                    if (player.isSneaking()) {
                        f12 += 25.0f;
                        GlStateManager.translate(0.0f, 0.142f, -0.0178f);
                    }
                    GlStateManager.rotate(6.0f + f13 / 2.0f + f12, 1.0f, 0.0f, 0.0f);
                    GlStateManager.rotate(f14 / 2.0f, 0.0f, 0.0f, 1.0f);
                    GlStateManager.rotate(-f14 / 2.0f, 0.0f, 1.0f, 0.0f);
                    GlStateManager.rotate(180.0f, 0.0f, 1.0f, 0.0f);
                    this.playerRenderer.getMainModel().renderCape(0.0625f);
                    GlStateManager.popMatrix();
                }
            }
        }

        @Override
        public boolean shouldCombineTextures() {
            return false;
        }
    }
}
