package me.enokitoraisu.shimejiclient.utils.game.nbs;

import com.google.common.collect.Multimap;
import com.google.common.collect.MultimapBuilder;

import java.io.*;

public class NBSSongDecoder extends SongDecoder {

    public static final int NOTE_OFFSET = 33; // Magic value (https://opennbs.org/nbs)

    /**
     * Sets a note at a tick in a song
     *
     * @param ticks
     * @param note
     * @param notesMap
     */
    private static void setNote(int ticks, Note note, Multimap<Integer, Note> notesMap) {
        notesMap.put(ticks, note);
    }

    private static short readShort(DataInputStream dataInputStream) throws IOException {
        int byte1 = dataInputStream.readUnsignedByte();
        int byte2 = dataInputStream.readUnsignedByte();
        return (short) (byte1 + (byte2 << 8));
    }

    private static int readInt(DataInputStream dataInputStream) throws IOException {
        int byte1 = dataInputStream.readUnsignedByte();
        int byte2 = dataInputStream.readUnsignedByte();
        int byte3 = dataInputStream.readUnsignedByte();
        int byte4 = dataInputStream.readUnsignedByte();
        return (byte1 + (byte2 << 8) + (byte3 << 16) + (byte4 << 24));
    }

    private static String readString(DataInputStream dataInputStream) throws IOException {
        int length = readInt(dataInputStream);
        StringBuilder builder = new StringBuilder(length);
        for (; length > 0; --length) {
            char c = (char) dataInputStream.readByte();
            if (c == (char) 0x0D) {
                c = ' ';
            }
            builder.append(c);
        }
        return builder.toString();
    }

    /**
     * Parses a Song from a Note Block Studio project file (.nbs)
     *
     * @param songFile .nbs file
     * @return Song object representing a Note Block Studio project
     * @see Song
     */
    @Override
    public Song parse(File songFile) {
        try {
            return parse(new FileInputStream(songFile), songFile);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        return null;
    }

    /**
     * Parses a Song from an InputStream
     *
     * @param inputStream of a Note Block Studio project file (.nbs)
     * @return Song object from the InputStream
     * @see Song
     */
    public Song parse(InputStream inputStream) {
        return parse(inputStream, null);
    }

    /**
     * Parses a Song from an InputStream and a Note Block Studio project file (.nbs)
     *
     * @param inputStream of a .nbs file
     * @param songFile    representing a .nbs file
     * @return Song object representing the given .nbs file
     * @see Song
     */
    private Song parse(InputStream inputStream, File songFile) {
        Multimap<Integer, Note> notesMap = MultimapBuilder.linkedHashKeys().arrayListValues().build();

        try {
            DataInputStream dataInputStream = new DataInputStream(inputStream);
            short length = readShort(dataInputStream);
            int nbsversion = 0;
            if (length == 0) {
                nbsversion = dataInputStream.readByte();
                dataInputStream.readByte();
                if (nbsversion >= 3) {
                    length = readShort(dataInputStream);
                }
            }
            readShort(dataInputStream);
            String title = readString(dataInputStream);
            String author = readString(dataInputStream);
            readString(dataInputStream);
            readString(dataInputStream);
            float speed = readShort(dataInputStream) / 100f;
            dataInputStream.readBoolean();
            dataInputStream.readByte();
            dataInputStream.readByte();
            readInt(dataInputStream);
            readInt(dataInputStream);
            readInt(dataInputStream);
            readInt(dataInputStream);
            readInt(dataInputStream);
            readString(dataInputStream);
            if (nbsversion >= 4) {
                dataInputStream.readByte();
                dataInputStream.readByte();
                readShort(dataInputStream);
            }

            double tick = -1;
            while (true) {
                short jumpTicks = readShort(dataInputStream);
                if (jumpTicks == 0) {
                    break;
                }
                tick += jumpTicks * (20f / speed);
                short layer = -1;
                while (true) {
                    short jumpLayers = readShort(dataInputStream);
                    if (jumpLayers == 0) {
                        break;
                    }
                    layer += jumpLayers;
                    byte instrument = dataInputStream.readByte();

                    byte key = dataInputStream.readByte();
                    if (nbsversion >= 4) {
                        dataInputStream.readByte();
                        dataInputStream.readUnsignedByte();
                        readShort(dataInputStream);
                    }

                    Note note = new Note(Instrument.fromID(instrument), key - NOTE_OFFSET);
                    setNote((int) Math.round(tick), note, notesMap);
                }
            }

            return new Song(notesMap, title, author);
        } catch (EOFException e) {
            String file = "";
            if (songFile != null) {
                file = songFile.getName();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }
}