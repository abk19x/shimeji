package me.enokitoraisu.shimejiclient.module.impl.render;

import me.enokitoraisu.shimejiclient.module.Category;
import me.enokitoraisu.shimejiclient.module.Module;
import me.enokitoraisu.shimejiclient.utils.math.ColorUtil;
import me.enokitoraisu.shimejiclient.utils.renderer.RenderUtil3D;
import me.enokitoraisu.shimejiclient.value.values.BooleanValue;
import me.enokitoraisu.shimejiclient.value.values.FloatValue;
import me.enokitoraisu.shimejiclient.value.values.IntegerValue;
import net.minecraft.tileentity.TileEntityShulkerBox;
import org.lwjgl.input.Keyboard;

import java.awt.*;

@SuppressWarnings("unused")
public class ShulkerESP extends Module {
    public BooleanValue boxSettings = register(new BooleanValue("Box", true));
    public BooleanValue outLineSettings = register(new BooleanValue("OutLine", true));
    public FloatValue outLineWidth = register(new FloatValue("OutLineWidth", 1.0f, 0.1f, 2.0f, v -> outLineSettings.getValue()));
    public IntegerValue BoxAlpha = register(new IntegerValue("BoxAlpha", 76, 0, 255, v -> boxSettings.getValue()));
    public IntegerValue OutLineAlpha = register(new IntegerValue("OutLineAlpha", 76, 0, 255, v -> outLineSettings.getValue()));

    public ShulkerESP() {
        super("ShulkerESP", Category.RENDER, Keyboard.KEY_NONE);
    }

    public void onRender3D() {
        mc.world.loadedTileEntityList.forEach(tileEntity -> {
            if (tileEntity instanceof TileEntityShulkerBox) {
                Color colordye = new Color(((TileEntityShulkerBox) tileEntity).getColor().getColorValue());
                RenderUtil3D.drawBox(
                        tileEntity.getPos(),
                        ColorUtil.toRGBA(colordye.getRed(), colordye.getGreen(), colordye.getBlue(), BoxAlpha.getValue()),
                        ColorUtil.toRGBA(colordye.getRed(), colordye.getGreen(), colordye.getBlue(), OutLineAlpha.getValue()),
                        boxSettings.getValue(),
                        outLineSettings.getValue(),
                        outLineWidth.getValue()
                );
            }
        });
    }
}
