package me.enokitoraisu.shimejiclient.utils.entity;

import me.enokitoraisu.shimejiclient.utils.interfaces.Util;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.entity.MoverType;
import net.minecraft.network.play.client.CPacketPlayer;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;

public class EntityUtil implements Util {
    public static BlockPos getPlayerPosWithEntity() {
        return new BlockPos(mc.player.getRidingEntity() != null ? mc.player.getRidingEntity().posX : mc.player.posX, mc.player.getRidingEntity() != null ? mc.player.getRidingEntity().posY : mc.player.posY, mc.player.getRidingEntity() != null ? mc.player.getRidingEntity().posZ : mc.player.posZ);
    }


    public static boolean isPlayerMoving() {
        return mc.player.movementInput.moveForward != 0 || mc.player.movementInput.moveStrafe != 0;
    }

    public static void motion(double x, double y, double z) {
        EntityPlayerSP player = mc.player;
        double dist = 5;
        for (int i = 0; i < 20 && dist > 1; i++) {
            double dx = x - player.posX;
            double dy = y - player.posY;
            double dz = z - player.posZ;

            double hdist = Math.sqrt(dx * dx + dz * dz);

            double rx = Math.atan2(dx, dz);
            double ry = Math.atan2(dy, hdist);

            dist = Math.sqrt(dx * dx + dy * dy + dz * dz);
            double o = dist > 1 ? 1 : dist;
            Vec3d vec = new Vec3d(Math.sin(rx) * Math.cos(ry) * o, o * Math.sin(ry * 1), Math.cos(rx) * Math.cos(ry) * o);
            mc.player.move(MoverType.SELF, vec.x, vec.y, vec.z);

            mc.player.connection.sendPacket(new CPacketPlayer.Position(mc.player.posX, mc.player.posY, mc.player.posZ, true));
        }
    }
}
