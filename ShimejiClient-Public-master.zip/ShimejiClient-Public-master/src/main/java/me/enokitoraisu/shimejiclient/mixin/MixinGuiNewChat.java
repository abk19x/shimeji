package me.enokitoraisu.shimejiclient.mixin;

import me.enokitoraisu.shimejiclient.event.PrintChatEvent;
import net.minecraft.client.gui.ChatLine;
import net.minecraft.client.gui.GuiNewChat;
import net.minecraft.util.text.ITextComponent;
import net.minecraftforge.common.MinecraftForge;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.List;

@Mixin(GuiNewChat.class)
public class MixinGuiNewChat {

    @Shadow
    @Final
    private List<ChatLine> drawnChatLines;

    @Inject(method = "printChatMessageWithOptionalDeletion", at = @At(value = "HEAD"), cancellable = true)
    public void printChatMessageWithOptionalDeletion(ITextComponent chatComponent, int chatLineId, CallbackInfo ci) {
        PrintChatEvent printChatEvent = new PrintChatEvent(chatComponent, chatLineId, drawnChatLines);
        MinecraftForge.EVENT_BUS.post(printChatEvent);

        if (printChatEvent.isCanceled()) {
            ci.cancel();
        }
    }
}