package me.enokitoraisu.shimejiclient.command.impl;

import me.enokitoraisu.shimejiclient.ShimejiClient;
import me.enokitoraisu.shimejiclient.command.Command;
import me.enokitoraisu.shimejiclient.module.impl.hud.NewNotifications;

public class Config extends Command {
    public Config() {
        super("Config", "Config Save or Load.");
    }

    @Override
    public void onCommand() {
        try {
            switch (arg(1).toLowerCase()) {
                case "load":
                    ShimejiClient.configManager.loadConfigs();
                    NewNotifications.INSTANCE.add("Success load Configs", NewNotifications.Type.INFO);
                    break;
                case "save":
                    ShimejiClient.configManager.saveConfigs();
                    NewNotifications.INSTANCE.add("Success save Configs", NewNotifications.Type.INFO);
                    break;
            }
        } catch (Exception ignored) {
            sendMessage("Usage: >Config <save : load>");
        }
    }
}
