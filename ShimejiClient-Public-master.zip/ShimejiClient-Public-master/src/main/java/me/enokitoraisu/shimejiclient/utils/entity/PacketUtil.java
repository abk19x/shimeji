package me.enokitoraisu.shimejiclient.utils.entity;

import me.enokitoraisu.shimejiclient.utils.interfaces.Util;
import net.minecraft.entity.Entity;
import net.minecraft.network.play.server.SPacketEntityStatus;

@SuppressWarnings("unused")
public class PacketUtil implements Util {
    //SPacketEntityStatus
    public static final byte DAMAGE = 2;
    public static final byte DEATH = 3;
    public static final byte ITEM_USE_FINISH = 9;
    public static final byte SHEEP_GRASS_EAT = 10;
    public static final byte PLAY_GUARDIAN_SOUND = 21;
    public static final byte SHIELD_BLOCK = 29;
    public static final byte SHIELD_BREAK = 30;
    public static final byte THORNS_HIT = 33;
    public static final byte DROWN_SOUND = 36;
    public static final byte GENERIC_SOUND = 37;
    public static final byte TOTEM_USE = 35;

    public static Entity getEntityStatusByEntity(SPacketEntityStatus entityStatus) {
        if (mc.player == null || mc.world == null || entityStatus == null)
            return null;
        return entityStatus.getEntity(mc.world);
    }
}
