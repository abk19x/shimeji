package me.enokitoraisu.shimejiclient.module.impl.player;

import me.enokitoraisu.shimejiclient.module.Category;
import me.enokitoraisu.shimejiclient.module.Module;
import me.enokitoraisu.shimejiclient.utils.entity.BlockUtil;
import me.enokitoraisu.shimejiclient.utils.math.TimerUtil;
import me.enokitoraisu.shimejiclient.utils.renderer.RenderUtil3D;
import me.enokitoraisu.shimejiclient.value.values.BooleanValue;
import me.enokitoraisu.shimejiclient.value.values.IntegerValue;
import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemSkull;
import net.minecraft.item.ItemStack;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;
import net.minecraftforge.client.event.RenderWorldLastEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import org.lwjgl.input.Keyboard;

import java.util.Random;

@SuppressWarnings("unused")
public class BuildRandom extends Module {
    private final TimerUtil timer = new TimerUtil();
    private final Random random = new Random();
    public IntegerValue range = register(new IntegerValue("Range", 4, 1, 6));
    public BooleanValue rotation = register(new BooleanValue("Rotate", true));
    public BooleanValue packet = register(new BooleanValue("PacketPlace", true));
    public IntegerValue delay = register(new IntegerValue("Delay", 10, 0, 50));
    private BlockPos pos;

    public BuildRandom() {
        super("BuildRandom", Category.PLAYER, Keyboard.KEY_NONE);
    }

    @Override
    public void onTick() {
        int bound = range.getValue() * 2 + 1;
        BlockPos pos;

        if (!checkHeldItem()) return;
        do {
            pos = new BlockPos(mc.player.getPosition()).add(random.nextInt(bound) - range.getValue(), random.nextInt(bound) - range.getValue(), random.nextInt(bound) - range.getValue());
        } while (timer.passedMs(delay.getValue()) && !tryToPlaceBlock(pos));
    }

    private boolean tryToPlaceBlock(BlockPos pos) {
        if (pos == null) return false;
        if (mc.world.getBlockState(pos).getMaterial().isReplaceable()) {
            this.pos = pos;
            BlockUtil.placeBlock(pos, EnumHand.MAIN_HAND, rotation.getValue(), packet.getValue(), mc.player.isSneaking());
            timer.reset();
            return true;
        }
        return false;
    }

    private boolean checkHeldItem() {
        ItemStack stack = mc.player.inventory.getCurrentItem();
        return !stack.isEmpty() && (stack.getItem() instanceof ItemBlock || stack.getItem() instanceof ItemSkull);
    }

    @SubscribeEvent
    public void onRender3D(RenderWorldLastEvent event) {
        if (pos != null) {
            RenderUtil3D.drawBox(pos, 0x4dffffff, 0xffffffff, true, true, 1.0f);
        }
    }
}
