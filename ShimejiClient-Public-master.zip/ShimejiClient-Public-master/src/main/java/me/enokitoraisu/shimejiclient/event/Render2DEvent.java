package me.enokitoraisu.shimejiclient.event;

import net.minecraft.client.gui.ScaledResolution;

public class Render2DEvent {
    private final float partialTicks;
    private final ScaledResolution resolution;

    public Render2DEvent(float partialTicks, ScaledResolution resolution) {
        this.partialTicks = partialTicks;
        this.resolution = resolution;
    }

    public float getPartialTicks() {
        return partialTicks;
    }

    public ScaledResolution getResolution() {
        return resolution;
    }
}
