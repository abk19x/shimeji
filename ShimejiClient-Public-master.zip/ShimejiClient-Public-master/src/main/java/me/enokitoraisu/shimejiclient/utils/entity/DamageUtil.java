package me.enokitoraisu.shimejiclient.utils.entity;

import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Items;
import net.minecraft.item.Item;
import net.minecraft.item.ItemPickaxe;
import net.minecraft.item.ItemSpade;
import net.minecraft.item.ItemSword;

public class DamageUtil {
    public static int getCoolDownByWeapon(EntityPlayer player) {
        Item item = player.getHeldItemMainhand().getItem();
        if (item instanceof ItemSword) return 600;
        else if (item instanceof ItemPickaxe) return 850;
        else if (item == Items.IRON_AXE) return 1100;
        else if (item == Items.STONE_HOE) return 500;
        else if (item == Items.IRON_HOE) return 350;
        else if (item == Items.WOODEN_AXE || item == Items.STONE_AXE) return 1250;
        else if (item instanceof ItemSpade || item == Items.GOLDEN_AXE || item == Items.DIAMOND_AXE || item == Items.WOODEN_HOE || item == Items.GOLDEN_HOE)
            return 1000;
        return 250;
    }
}
