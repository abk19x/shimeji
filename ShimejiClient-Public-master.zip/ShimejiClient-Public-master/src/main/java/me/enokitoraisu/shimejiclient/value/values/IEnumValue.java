package me.enokitoraisu.shimejiclient.value.values;

public interface IEnumValue {
    String display();
}
