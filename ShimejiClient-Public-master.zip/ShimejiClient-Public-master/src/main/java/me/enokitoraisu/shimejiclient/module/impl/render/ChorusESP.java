package me.enokitoraisu.shimejiclient.module.impl.render;

import me.enokitoraisu.shimejiclient.event.PacketEvent;
import me.enokitoraisu.shimejiclient.module.Category;
import me.enokitoraisu.shimejiclient.module.Module;
import me.enokitoraisu.shimejiclient.utils.math.TimerUtil;
import me.enokitoraisu.shimejiclient.utils.renderer.RenderUtil3D;
import me.enokitoraisu.shimejiclient.value.values.BooleanValue;
import me.enokitoraisu.shimejiclient.value.values.ColorValue;
import me.enokitoraisu.shimejiclient.value.values.FloatValue;
import me.enokitoraisu.shimejiclient.value.values.IntegerValue;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Items;
import net.minecraft.init.SoundEvents;
import net.minecraft.network.play.server.SPacketSoundEffect;
import net.minecraft.util.math.BlockPos;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import org.lwjgl.input.Keyboard;

import java.awt.*;
import java.util.List;
import java.util.stream.Collectors;

public class ChorusESP extends Module {
    private final IntegerValue time = register(new IntegerValue("RemoveTime", 1000, 500, 5000));
    private final ColorValue fillColor = register(new ColorValue("FillColor", new Color(0x80FFFFFF, true)));
    private final BooleanValue line = register(new BooleanValue("Line", true));
    private final ColorValue lineColor = register(new ColorValue("LineColor", new Color(0xFFFFFFFF), v -> line.getValue()));
    private final FloatValue width = register(new FloatValue("Width", 1.0F, 0.5F, 2.0F));
    private final TimerUtil timer = new TimerUtil();
    private BlockPos pos;
    private EntityPlayer player;

    public ChorusESP() {
        super("ChorusESP", Category.RENDER, Keyboard.KEY_NONE);
    }

    @SubscribeEvent
    public void onPacketReceived(PacketEvent.Receive event) {
        if (event.getPacket() instanceof SPacketSoundEffect) {
            SPacketSoundEffect packet = (SPacketSoundEffect) event.getPacket();
            if (packet.getSound() == SoundEvents.ITEM_CHORUS_FRUIT_TELEPORT) {
                List<EntityPlayer> players = mc.world.playerEntities.stream().filter(this::isHeldChorus).collect(Collectors.toList());
                if (!players.isEmpty())
                    this.player = players.get(0);
                this.pos = new BlockPos(Math.floor(packet.getX()), Math.floor(packet.getY()), Math.floor(packet.getZ()));
                timer.reset();
            }
        }
    }

    @Override
    public void onRender3D() {
        if (pos != null)
            if (timer.passedMs(time.getValue())) {
                pos = null;
                player = null;
            } else {
                RenderUtil3D.drawBox(pos, fillColor.getIntValue(), lineColor.getIntValue(), true, line.getValue(), width.getValue());
                if (player != null)
                    RenderUtil3D.drawString3D(pos, String.format("wait for %s teleport", player.getName()), mc.fontRenderer, true, -1);
            }
    }

    private boolean isHeldChorus(EntityPlayer player) {
        return player.inventory.getStackInSlot(player.inventory.currentItem).getItem() == Items.CHORUS_FRUIT;
    }
}
