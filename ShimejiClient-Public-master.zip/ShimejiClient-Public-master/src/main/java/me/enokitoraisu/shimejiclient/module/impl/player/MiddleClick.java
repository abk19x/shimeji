package me.enokitoraisu.shimejiclient.module.impl.player;

import me.enokitoraisu.shimejiclient.module.Category;
import me.enokitoraisu.shimejiclient.module.Module;
import me.enokitoraisu.shimejiclient.module.impl.hud.NewNotifications;
import me.enokitoraisu.shimejiclient.utils.entity.InventoryUtil;
import me.enokitoraisu.shimejiclient.utils.math.TimerUtil;
import me.enokitoraisu.shimejiclient.value.values.BooleanValue;
import me.enokitoraisu.shimejiclient.value.values.IntegerValue;
import me.enokitoraisu.shimejiclient.value.values.ModeValue;
import net.minecraft.init.Items;
import net.minecraft.item.ItemEnderPearl;
import net.minecraft.item.ItemExpBottle;
import net.minecraft.network.play.client.CPacketPlayer;
import net.minecraft.network.play.client.CPacketPlayerTryUseItem;
import net.minecraft.util.EnumHand;
import org.lwjgl.input.Keyboard;
import org.lwjgl.input.Mouse;

@SuppressWarnings("unused")
public class MiddleClick extends Module {
    private final ModeValue mode = register(new ModeValue("Mode", "Pearl", "Pearl", "EXPBottle"));
    private final BooleanValue packet = register(new BooleanValue("Packet", true));
    private final IntegerValue delay = register(new IntegerValue("Delay", 10, 10, 100, this::isEXPBottle));
    private final ModeValue _switch = register(new ModeValue("Switch", "Silent", "Silent", "None"));
    private final BooleanValue footExp = register(new BooleanValue("FootExp", false, v -> mode.getValue().equalsIgnoreCase("EXPBottle")));
    private final TimerUtil timerUtil = new TimerUtil();
    private boolean clicked = false;

    public MiddleClick() {
        super("MiddleClick", Category.PLAYER, Keyboard.KEY_NONE);
    }

    public boolean isEXPBottle(Object o) {
        return mode.getValue().equals("EXPBottle");
    }

    @Override
    public void onTick() {
        switch (mode.getValue()) {
            case "Pearl":
                if (Mouse.isButtonDown(2)) {
                    if (!clicked) {
                        int oldSlot = mc.player.inventory.currentItem;
                        if (mc.player.getHeldItemMainhand().getItem() == Items.ENDER_PEARL) useItem(EnumHand.MAIN_HAND);
                        else if (InventoryUtil.findHotbarBlock(ItemEnderPearl.class) == -1)
                            sendNotify("Can't find EnderPearl in Hotbar!", NewNotifications.Type.ERROR);
                        else if (_switch.getValue().equals("Silent")) {
                            InventoryUtil.switchToSlot(InventoryUtil.findHotbarBlock(ItemEnderPearl.class), false);
                            useItem(EnumHand.MAIN_HAND);
                            InventoryUtil.switchToSlot(oldSlot, false);
                        }
                    }
                    clicked = true;
                } else {
                    clicked = false;
                }
                break;

            case "EXPBottle":
                if (Mouse.isButtonDown(2)) {
                    if (timerUtil.passedMs(delay.getValue())) {
                        int oldSlot = mc.player.inventory.currentItem;
                        if (mc.player.getHeldItemMainhand().getItem() == Items.EXPERIENCE_BOTTLE) {
                            if (this.footExp.getValue())
                                mc.player.connection.sendPacket(new CPacketPlayer.Rotation(mc.player.rotationYaw, 90.0f, mc.player.onGround));
                            useItem(EnumHand.MAIN_HAND);
                        } else if (InventoryUtil.findHotbarBlock(ItemExpBottle.class) != -1 && _switch.getValue().equals("Silent")) {
                            InventoryUtil.switchToSlot(InventoryUtil.findHotbarBlock(ItemExpBottle.class), false);
                            if (this.footExp.getValue())
                                mc.player.connection.sendPacket(new CPacketPlayer.Rotation(mc.player.rotationYaw, 90.0f, mc.player.onGround));
                            useItem(EnumHand.MAIN_HAND);
                            InventoryUtil.switchToSlot(oldSlot, false);
                        }
                        timerUtil.reset();
                    }
                }
                break;
        }
    }

    private void useItem(EnumHand hand) {
        if (this.packet.getValue()) {
            mc.player.connection.sendPacket(new CPacketPlayerTryUseItem(hand));
        } else {
            mc.playerController.processRightClick(mc.player, mc.world, hand);
        }
    }
}
