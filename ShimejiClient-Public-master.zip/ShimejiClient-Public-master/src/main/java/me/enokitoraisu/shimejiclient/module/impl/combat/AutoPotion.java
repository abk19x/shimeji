package me.enokitoraisu.shimejiclient.module.impl.combat;

import me.enokitoraisu.shimejiclient.module.Category;
import me.enokitoraisu.shimejiclient.module.Module;
import me.enokitoraisu.shimejiclient.utils.entity.InventoryUtil;
import me.enokitoraisu.shimejiclient.utils.math.TimerUtil;
import me.enokitoraisu.shimejiclient.value.values.BooleanValue;
import me.enokitoraisu.shimejiclient.value.values.FloatValue;
import me.enokitoraisu.shimejiclient.value.values.IntegerValue;
import net.minecraft.init.MobEffects;
import net.minecraft.item.ItemSplashPotion;
import net.minecraft.item.ItemStack;
import net.minecraft.network.play.client.CPacketPlayer;
import net.minecraft.potion.PotionEffect;
import net.minecraft.potion.PotionUtils;
import net.minecraft.util.EnumHand;
import org.lwjgl.input.Keyboard;

@SuppressWarnings("unused")
public class AutoPotion extends Module {
    private final IntegerValue maxHealth = register(new IntegerValue("MaxHealth", 1, 0, 20));
    private final IntegerValue useDelay = register(new IntegerValue("UseDelay", 1, 0, 20));
    private final BooleanValue checkOnGround = register(new BooleanValue("OnGroundCheck", false));
    private final BooleanValue checkFallDist = register(new BooleanValue("FallDistCheck", false));
    private final FloatValue fallDist = register(new FloatValue("FallDistance", 5F, 3F, 10F));
    private final TimerUtil timer = new TimerUtil();

    public AutoPotion() {
        super("AutoPotion", Category.COMBAT, Keyboard.KEY_NONE);
    }

    @Override
    public void onTick() {
        if (mc.player.getHealth() > maxHealth.getValue()) return;
        if (checkOnGround.getValue() && !mc.player.onGround) return;
        if (checkFallDist.getValue() && mc.player.fallDistance > fallDist.getValue()) return;
        if (getPotionSlot() == -1) return;
        if (timer.passedDms(useDelay.getValue())) {
            int slot = mc.player.inventory.currentItem;
            InventoryUtil.switchToSlot(getPotionSlot(), false);
            mc.player.connection.sendPacket(new CPacketPlayer.Rotation(mc.player.rotationYaw, 90, mc.player.onGround));
            mc.playerController.processRightClick(mc.player, mc.world, EnumHand.MAIN_HAND);
            mc.player.connection.sendPacket(new CPacketPlayer.Rotation(mc.player.rotationYaw, mc.player.rotationPitch, mc.player.onGround));
            InventoryUtil.switchToSlot(slot, false);
            timer.reset();
        }
    }

    public int getPotionSlot() {
        for (int i = 0; i < 9; i++) {
            if (mc.player.inventory.getStackInSlot(i).getItem() instanceof ItemSplashPotion) {
                ItemStack item = mc.player.inventory.getStackInSlot(i);
                for (PotionEffect effect : PotionUtils.getEffectsFromStack(item)) {
                    if (effect.getPotion() == MobEffects.INSTANT_HEALTH) return i;
                }
            }
        }
        return -1;
    }
}
