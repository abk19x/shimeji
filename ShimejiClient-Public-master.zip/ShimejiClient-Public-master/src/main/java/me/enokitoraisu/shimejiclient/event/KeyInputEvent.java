package me.enokitoraisu.shimejiclient.event;

public class KeyInputEvent extends EventManager {
    private final int key;

    public KeyInputEvent(int key) {
        this.key = key;
    }

    public int getKey() {
        return key;
    }
}
