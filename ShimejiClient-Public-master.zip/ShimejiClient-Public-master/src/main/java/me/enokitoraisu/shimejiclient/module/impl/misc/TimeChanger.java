package me.enokitoraisu.shimejiclient.module.impl.misc;

import me.enokitoraisu.shimejiclient.event.PacketEvent;
import me.enokitoraisu.shimejiclient.module.Category;
import me.enokitoraisu.shimejiclient.module.Module;
import me.enokitoraisu.shimejiclient.value.values.IntegerValue;
import net.minecraft.network.play.server.SPacketTimeUpdate;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import org.lwjgl.input.Keyboard;

@SuppressWarnings("unused")
public class TimeChanger extends Module {
    public IntegerValue time = register(new IntegerValue("Time", 0, 0, 23999));

    public TimeChanger() {
        super("TimeChanger", "Change client side time.", Category.MISC, Keyboard.KEY_NONE);
    }

    @Override
    public void onUpdate() {
        if (fullNullCheck())
            mc.world.setWorldTime(time.getValue());
    }

    @SubscribeEvent
    public void onPacketEvent(PacketEvent packetEvent) {
        if (packetEvent.getPacket() instanceof SPacketTimeUpdate) packetEvent.setCanceled(true);
    }

}
