package me.enokitoraisu.shimejiclient.module.impl.combat;

import me.enokitoraisu.shimejiclient.event.PacketEvent;
import me.enokitoraisu.shimejiclient.module.Category;
import me.enokitoraisu.shimejiclient.module.Module;
import me.enokitoraisu.shimejiclient.utils.entity.BlockUtil;
import me.enokitoraisu.shimejiclient.utils.entity.FriendUtil;
import me.enokitoraisu.shimejiclient.utils.entity.InventoryUtil;
import me.enokitoraisu.shimejiclient.utils.math.TimerUtil;
import me.enokitoraisu.shimejiclient.utils.renderer.RenderUtil3D;
import me.enokitoraisu.shimejiclient.value.values.*;
import net.minecraft.block.BlockGlowstone;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemPickaxe;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemSword;
import net.minecraft.network.play.client.CPacketEntityAction;
import net.minecraft.network.play.client.CPacketPlayer;
import net.minecraft.network.play.client.CPacketPlayerTryUseItemOnBlock;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import org.lwjgl.input.Keyboard;

import java.awt.*;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

public class AnchorAura extends Module {
    private final FloatValue findRange = register(new FloatValue("TargetRange", 4, 3, 6));
    private final IntegerValue delay = register(new IntegerValue("Delay", 0, 0, 10));
    private final BooleanValue swing = register(new BooleanValue("Swing", true));
    private final ModeValue swingTiming = register(new ModeValue("SwingTiming", "Pre", v -> swing.getValue(), "Pre", "Post"));
    private final BooleanValue rotate = register(new BooleanValue("Rotate", false));
    private final BooleanValue spam = register(new BooleanValue("PacketSpam", false));
    private final BooleanValue render = register(new BooleanValue("Render", true));
    private final ColorValue fill = register(new ColorValue("Fill", new Color(0x80FFFFFF), v -> render.getValue()));
    private final ColorValue line = register(new ColorValue("Line", new Color(0x80FFFFFF), v -> render.getValue()));
    private final TimerUtil timer = new TimerUtil();
    private int ticks;
    private boolean sneaking;
    private EntityPlayer target;

    public AnchorAura() {
        super("AnchorAura", "Can be used for server versions above 1.16", Category.COMBAT, Keyboard.KEY_NONE);
    }

    @Override
    public void onDisable() {
        ticks = 0;
        target = null;
    }

    @SubscribeEvent
    public void onPacketSend(PacketEvent.Send event) {
        if (event.getPacket() instanceof CPacketEntityAction) {
            CPacketEntityAction packet = (CPacketEntityAction) event.getPacket();
            if (packet.getAction() == CPacketEntityAction.Action.START_SNEAKING && !sneaking) {
                sneaking = true;
                event.setCanceled(true);
            } else if (packet.getAction() == CPacketEntityAction.Action.STOP_SNEAKING && sneaking) {
                sneaking = false;
            }
        }
    }

    @Override
    public void onTick() {
        if (!timer.passedDs(delay.getValue())) return;
        timer.reset();
        if (getTarget() == null) {
            sendMessage("Can't find target");
            toggle();
            return;
        }

        target = getTarget();

        if (mc.player.getDistance(target) < findRange.getValue()) {
            BlockPos targetPos = BlockUtil.floorPos(target);

            BlockPos placePos = null;
            BlockPos pos = targetPos.add(new BlockPos(0, 2, 0));
            if (mc.world.getBlockState(pos).getBlock() == Blocks.AIR || ticks != 0) placePos = pos;
            if (placePos == null) return;

            int heldSlot = mc.player.inventory.currentItem;
            int anchorSlot = -1;
            int gsSlot = -1;
            int emptySlot = -1;
            for (int i = 0; i < 9; i++) {
                ItemStack stack = mc.player.inventory.getStackInSlot(i);

                if (anchorSlot == -1 && InventoryUtil.isRespawnAnchor(stack))
                    anchorSlot = i;

                if (gsSlot == -1 && stack.getItem() instanceof ItemBlock && ((ItemBlock) stack.getItem()).getBlock() instanceof BlockGlowstone)
                    gsSlot = i;

                if (emptySlot == -1 && i != gsSlot && i != anchorSlot && stack.isEmpty() || stack.getItem() instanceof ItemPickaxe || stack.getItem() instanceof ItemSword)
                    emptySlot = i;
            }

            if (anchorSlot == -1) {
                sendMessage("Can't find Respawn Anchor in hotbar!");
                toggle();
                return;
            }
            if (gsSlot == -1) {
                sendMessage("Can't find GlowStone in hotbar!");
                toggle();
                return;
            }

            if (spam.getValue()) {
                InventoryUtil.switchToSlot(anchorSlot, false);
                place(placePos, EnumFacing.UP, new Vec3d(.5, .5, .5));
                InventoryUtil.switchToSlot(gsSlot, false);
                place(placePos, EnumFacing.UP, new Vec3d(.5, 1, .5));
                InventoryUtil.switchToSlot(emptySlot, false);
                place(placePos, EnumFacing.UP, new Vec3d(.5, .5, .5));
                InventoryUtil.switchToSlot(heldSlot, false);
            } else {
                switch (ticks) {
                    case 0:
                        InventoryUtil.switchToSlot(anchorSlot, false);
                        place(placePos, EnumFacing.UP, new Vec3d(.5, .5, .5));
                        ticks++;
                        break;
                    case 1:
                        InventoryUtil.switchToSlot(gsSlot, false);
                        place(placePos, EnumFacing.UP, new Vec3d(.5, 1, .5));
                        ticks++;
                        break;
                    case 2:
                        InventoryUtil.switchToSlot(emptySlot, false);
                        place(placePos, EnumFacing.UP, new Vec3d(.5, .5, .5));
                        ticks = 0;
                        break;
                }
            }
        }
    }

    @Override
    public void onRender3D() {
        if (target == null) return;
        BlockPos targetPos = BlockUtil.floorPos(target);
        if (!spam.getValue() && render.getValue()) {
            switch (ticks) {
                case 0:
                case 2:
                    RenderUtil3D.drawBox(targetPos.add(0, 2, 0), fill.getIntValue(), line.getIntValue(), true, true, 1.0f);
                    break;
                case 1:
                    RenderUtil3D.drawBox(targetPos.add(0, 3, 0), fill.getIntValue(), line.getIntValue(), true, true, 1.0f);
                    break;
            }
        }
    }

    public EntityPlayer getTarget() {
        List<EntityPlayer> players = mc.world.playerEntities.stream().filter(e -> e != mc.player).filter(e -> !FriendUtil.isFriend(e)).filter(e -> !e.isDead && e.getHealth() > 0).sorted(Comparator.comparingDouble(mc.player::getDistance)).collect(Collectors.toList());
        if (players.isEmpty()) return null;
        return players.get(0);
    }

    public void place(BlockPos pos, EnumFacing facing, Vec3d hitVec) {
        if (rotate.getValue()) {
            float[] rotations = BlockUtil.getLegitRotations(pos, hitVec);
            mc.player.connection.sendPacket(new CPacketPlayer.Rotation(rotations[0], rotations[1], mc.player.onGround));
        }
        if (swing.getValue() && swingTiming.getValue().equals("Pre"))
            mc.player.swingArm(EnumHand.MAIN_HAND);
        mc.player.connection.sendPacket(new CPacketPlayerTryUseItemOnBlock(
                pos,
                facing, EnumHand.MAIN_HAND,
                (float) (hitVec.x - (double) pos.getX()),
                (float) (hitVec.y - (double) pos.getY()),
                (float) (hitVec.z - (double) pos.getZ()))
        );
        if (swing.getValue() && swingTiming.getValue().equals("Post"))
            mc.player.swingArm(EnumHand.MAIN_HAND);
    }
}
