package me.enokitoraisu.shimejiclient.module.impl.render;

import me.enokitoraisu.shimejiclient.module.Category;
import me.enokitoraisu.shimejiclient.module.Module;
import me.enokitoraisu.shimejiclient.utils.interfaces.TimedRenderer;
import me.enokitoraisu.shimejiclient.utils.renderer.timedrenderer.Line;
import me.enokitoraisu.shimejiclient.value.values.*;
import net.minecraft.client.renderer.BufferBuilder;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.MathHelper;
import org.lwjgl.input.Keyboard;
import org.lwjgl.opengl.GL11;

import java.awt.*;
import java.util.ArrayList;
import java.util.List;

@SuppressWarnings("unused")
public class BreadCrumbs extends Module {
    private final ModeValue mode = register(new ModeValue("Mode", "Line", "Line", "Quads"));
    private final IntegerValue length = register(new IntegerValue("Length", 500, 500, 2000));
    private final FloatValue width = register(new FloatValue("Width", 1F, .5F, 2F, v -> mode.getValue().equals("Line")));
    private final BooleanValue smooth = register(new BooleanValue("Smooth", true, v -> mode.getValue().equals("Line")));
    private final ColorValue color = register(new ColorValue("Color", new Color(0xFFFFFFFF)));
    private final List<Line> lines = new ArrayList<>();

    public BreadCrumbs() {
        super("BreadCrumbs", Category.RENDER, Keyboard.KEY_NONE);
    }

    public boolean isQuads() {
        return mode.getValue().equals("Quads");
    }

    @Override
    public void onRender3D() {
        float red = color.getValue().getRed() / 255F;
        float green = color.getValue().getGreen() / 255F;
        float blue = color.getValue().getBlue() / 255F;

        GlStateManager.pushMatrix();
        GlStateManager.enableBlend();
        GlStateManager.disableTexture2D();
        GlStateManager.disableDepth();
        GlStateManager.disableAlpha();
        GlStateManager.glLineWidth(width.getValue());
        if (isQuads())
            GlStateManager.disableCull();
        GL11.glShadeModel(GL11.GL_SMOOTH);
        Tessellator tessellator = Tessellator.getInstance();
        BufferBuilder bufferBuilder = tessellator.getBuffer();
        if (!isQuads() && smooth.getValue())
            GL11.glEnable(GL11.GL_LINE_SMOOTH);
        bufferBuilder.begin(isQuads() ? GL11.GL_QUAD_STRIP : GL11.GL_LINE_STRIP, DefaultVertexFormats.POSITION_COLOR);
        for (Line b : lines) {
            if (isQuads()) {
                AxisAlignedBB boundingBox = mc.player.getRenderBoundingBox();
                double height = boundingBox.maxY - boundingBox.minY;
                bufferBuilder.pos(b.x - mc.getRenderManager().viewerPosX, b.y - mc.getRenderManager().viewerPosY, b.z - mc.getRenderManager().viewerPosZ).color(red, green, blue, MathHelper.clamp(1.0F - b.getProgress(), 0.001F, 1.0F)).endVertex();
                bufferBuilder.pos(b.x - mc.getRenderManager().viewerPosX, b.y + height - mc.getRenderManager().viewerPosY, b.z - mc.getRenderManager().viewerPosZ).color(red, green, blue, MathHelper.clamp(1.0F - b.getProgress(), 0.001F, 1.0F)).endVertex();
            } else {
                bufferBuilder.pos(b.x - mc.getRenderManager().viewerPosX, b.y + 0.02F - mc.getRenderManager().viewerPosY, b.z - mc.getRenderManager().viewerPosZ).color(red, green, blue, MathHelper.clamp(1.0F - b.getProgress(), 0.001F, 1.0F)).endVertex();
            }
        }
        tessellator.draw();
        if (!isQuads() && smooth.getValue())
            GL11.glDisable(GL11.GL_LINE_SMOOTH);
        GL11.glShadeModel(GL11.GL_FLAT);
        if (isQuads())
            GlStateManager.enableCull();
        GlStateManager.enableAlpha();
        GlStateManager.enableTexture2D();
        GlStateManager.disableBlend();
        GlStateManager.enableDepth();
        GlStateManager.depthMask(true);
        GlStateManager.popMatrix();
        lines.removeIf(TimedRenderer::hasExpired);
        lines.add(new Line(
                mc.player.lastTickPosX + (mc.player.posX - mc.player.lastTickPosX) * mc.getRenderPartialTicks(),
                mc.player.lastTickPosY + (mc.player.posY - mc.player.lastTickPosY) * mc.getRenderPartialTicks(),
                mc.player.lastTickPosZ + (mc.player.posZ - mc.player.lastTickPosZ) * mc.getRenderPartialTicks(), length.getValue()));
    }
}
