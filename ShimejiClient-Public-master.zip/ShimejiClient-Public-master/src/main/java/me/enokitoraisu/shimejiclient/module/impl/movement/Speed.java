package me.enokitoraisu.shimejiclient.module.impl.movement;

import me.enokitoraisu.shimejiclient.module.Category;
import me.enokitoraisu.shimejiclient.module.Module;
import me.enokitoraisu.shimejiclient.utils.math.MathUtil;
import me.enokitoraisu.shimejiclient.value.values.FloatValue;
import me.enokitoraisu.shimejiclient.value.values.ModeValue;
import org.lwjgl.input.Keyboard;

@SuppressWarnings("unused")
public class Speed extends Module {
    public ModeValue mode = register(new ModeValue("Mode", "Vanilla", "Vanilla", "Strafe"));
    public FloatValue Speed = register(new FloatValue("Speed", 0.5f, 0.1f, 10.0f, v -> mode.getValue().equals("Vanilla")));

    public Speed() {
        super("Speed", Category.MOVEMENT, Keyboard.KEY_NONE);
    }

    @Override
    public void onTick() {
        setTags(mode.getValue());
        switch (mode.getValue()) {
            case "Vanilla":
                final double[] move = MathUtil.directionSpeed(Speed.getValue().doubleValue() / 5.0);
                if (mc.player.movementInput.moveStrafe != 0 || mc.player.movementInput.moveForward != 0) {
                    mc.player.motionX = move[0];
                    mc.player.motionZ = move[1];
                } else {
                    mc.player.motionX = 0;
                    mc.player.motionZ = 0;
                }
                break;
            case "Strafe":
                break;
        }
    }
}
