package me.enokitoraisu.shimejiclient.module.impl.misc;

import me.enokitoraisu.shimejiclient.event.PacketEvent;
import me.enokitoraisu.shimejiclient.module.Category;
import me.enokitoraisu.shimejiclient.module.Module;
import me.enokitoraisu.shimejiclient.value.values.BooleanValue;
import net.minecraft.network.play.client.CPacketConfirmTeleport;
import net.minecraft.network.play.client.CPacketPlayer;
import net.minecraft.network.play.client.CPacketVehicleMove;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import org.lwjgl.input.Keyboard;

public class PortalGodMode extends Module {
    public static PortalGodMode INSTANCE = new PortalGodMode();
    public final BooleanValue close = register(new BooleanValue("GuiClose", false));
    private final BooleanValue cancel = register(new BooleanValue("CancelPacket", false));

    public PortalGodMode() {
        super("PortalGodMode", Category.MISC, Keyboard.KEY_NONE);
        INSTANCE = this;
    }

    @SubscribeEvent
    public void onPacketSend(PacketEvent.Send event) {
        if (event.getPacket() instanceof CPacketConfirmTeleport)
            event.setCanceled(true);

        if (cancel.getValue() && (event.getPacket() instanceof CPacketPlayer
                || event.getPacket() instanceof CPacketPlayer.Position
                || event.getPacket() instanceof CPacketPlayer.Rotation
                || event.getPacket() instanceof CPacketPlayer.PositionRotation
                || event.getPacket() instanceof CPacketVehicleMove)) {
            event.setCanceled(true);
        }
    }
}
