package me.enokitoraisu.shimejiclient.module.impl.client;

import me.enokitoraisu.shimejiclient.ShimejiClient;
import me.enokitoraisu.shimejiclient.module.Category;
import me.enokitoraisu.shimejiclient.module.Module;
import me.enokitoraisu.shimejiclient.utils.game.DisplayUtil;
import me.enokitoraisu.shimejiclient.utils.math.TimerUtil;
import me.enokitoraisu.shimejiclient.utils.renderer.RenderUtil;
import me.enokitoraisu.shimejiclient.value.values.BooleanValue;
import me.enokitoraisu.shimejiclient.value.values.IntegerValue;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.util.ResourceLocation;
import org.apache.logging.log4j.LogManager;
import org.lwjgl.input.Keyboard;

@SuppressWarnings("unused")
public class AutoSave extends Module {
    private final IntegerValue min = register(new IntegerValue("Minutes", 10, 5, 60));
    private final BooleanValue hud = register(new BooleanValue("ShowHUD", false));
    private final TimerUtil timerUtil = new TimerUtil();

    private final ResourceLocation savingImg = new ResourceLocation("shimeji/image/save.png");

    private boolean saving = false;

    public AutoSave() {
        super("AutoSave", "Automatically saves settings", Category.CLIENT, Keyboard.KEY_NONE);
    }

    @Override
    public void onTick() {
        if (timerUtil.passedM(min.getValue())) {
            this.saving = true;
            new Thread(() -> {
                ShimejiClient.configManager.saveConfigs();
                LogManager.getLogger("ShimejiClient").info("[AutoSave] config saved");
                try {
                    Thread.sleep(3000);
                } catch (InterruptedException ignored) {
                }
                this.saving = false;
            }).start();
            timerUtil.reset();
        }
    }

    @Override
    public void onRender2D() {
        if (saving && hud.getValue()) {
            mc.getTextureManager().bindTexture(savingImg);
            GlStateManager.color(1, 1, 1, 1);
            RenderUtil.drawImage(DisplayUtil.getWidth() - 44, 8, 32, 32);
        }
    }
}
