package me.enokitoraisu.shimejiclient.module.impl.misc;

import com.mojang.authlib.GameProfile;
import me.enokitoraisu.shimejiclient.module.Category;
import me.enokitoraisu.shimejiclient.module.Module;
import me.enokitoraisu.shimejiclient.value.values.BooleanValue;
import net.minecraft.client.entity.EntityOtherPlayerMP;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Enchantments;
import net.minecraft.init.Items;
import net.minecraft.item.ItemStack;
import org.lwjgl.input.Keyboard;

import java.util.UUID;

@SuppressWarnings("unused")
public class FakePlayer extends Module {
    private final BooleanValue Armor = register(new BooleanValue("Armor", false));

    public FakePlayer() {
        super("FakePlayer", Category.MISC, Keyboard.KEY_NONE);
    }

    @Override
    public void onEnable() {
        if (fullNullCheck()) {
            GameProfile fakePlayerProfile = new GameProfile(UUID.fromString("26697334-7fd2-11ed-a1eb-0242ac120002"), "FakePlayer");
            EntityOtherPlayerMP fakePlayer = new EntityOtherPlayerMP(mc.world, fakePlayerProfile);
            fakePlayer.copyLocationAndAnglesFrom(mc.player);
            fakePlayer.rotationYawHead = mc.player.rotationYawHead;
            fakePlayer.renderYawOffset = mc.player.renderYawOffset;
            fakePlayer.rotationYaw = mc.player.rotationYaw;
            fakePlayer.rotationPitch = mc.player.rotationPitch;
            fakePlayer.posX = mc.player.posX;
            fakePlayer.posY = mc.player.posY;
            fakePlayer.posZ = mc.player.posZ;
            if (Armor.getValue()) addMaxArmor(fakePlayer);
            mc.world.addEntityToWorld(-100, fakePlayer);
        }
    }

    private void addMaxEnchantment(ItemStack itemStack, Enchantment enchantment) {
        itemStack.addEnchantment(enchantment, enchantment.getMaxLevel());
    }

    private void addMaxArmor(EntityPlayer player) {
        ItemStack helmet = new ItemStack(Items.DIAMOND_HELMET);
        addMaxEnchantment(helmet, Enchantments.BLAST_PROTECTION);
        addMaxEnchantment(helmet, Enchantments.FIRE_PROTECTION);
        addMaxEnchantment(helmet, Enchantments.PROJECTILE_PROTECTION);
        addMaxEnchantment(helmet, Enchantments.PROTECTION);
        addMaxEnchantment(helmet, Enchantments.UNBREAKING);
        addMaxEnchantment(helmet, Enchantments.RESPIRATION);
        addMaxEnchantment(helmet, Enchantments.AQUA_AFFINITY);
        addMaxEnchantment(helmet, Enchantments.MENDING);
        player.inventory.armorInventory.set(3, helmet);

        ItemStack chestPlate = new ItemStack(Items.DIAMOND_CHESTPLATE);
        addMaxEnchantment(chestPlate, Enchantments.BLAST_PROTECTION);
        addMaxEnchantment(chestPlate, Enchantments.FIRE_PROTECTION);
        addMaxEnchantment(chestPlate, Enchantments.PROJECTILE_PROTECTION);
        addMaxEnchantment(chestPlate, Enchantments.PROTECTION);
        addMaxEnchantment(chestPlate, Enchantments.UNBREAKING);
        addMaxEnchantment(chestPlate, Enchantments.MENDING);
        player.inventory.armorInventory.set(2, chestPlate);

        ItemStack leggings = new ItemStack(Items.DIAMOND_LEGGINGS);
        addMaxEnchantment(leggings, Enchantments.BLAST_PROTECTION);
        addMaxEnchantment(leggings, Enchantments.FIRE_PROTECTION);
        addMaxEnchantment(leggings, Enchantments.PROJECTILE_PROTECTION);
        addMaxEnchantment(leggings, Enchantments.PROTECTION);
        addMaxEnchantment(leggings, Enchantments.UNBREAKING);
        addMaxEnchantment(leggings, Enchantments.MENDING);
        player.inventory.armorInventory.set(1, leggings);

        ItemStack boots = new ItemStack(Items.DIAMOND_BOOTS);
        addMaxEnchantment(boots, Enchantments.BLAST_PROTECTION);
        addMaxEnchantment(boots, Enchantments.FIRE_PROTECTION);
        addMaxEnchantment(boots, Enchantments.PROJECTILE_PROTECTION);
        addMaxEnchantment(boots, Enchantments.PROTECTION);
        addMaxEnchantment(boots, Enchantments.FEATHER_FALLING);
        addMaxEnchantment(boots, Enchantments.DEPTH_STRIDER);
        addMaxEnchantment(boots, Enchantments.UNBREAKING);
        addMaxEnchantment(boots, Enchantments.MENDING);
        player.inventory.armorInventory.set(0, boots);
    }

    @Override
    public void onDisable() {
        if (mc.world != null) mc.world.removeEntityFromWorld(-100);
    }
}
