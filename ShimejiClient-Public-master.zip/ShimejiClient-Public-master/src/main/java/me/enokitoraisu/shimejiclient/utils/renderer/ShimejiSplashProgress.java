package me.enokitoraisu.shimejiclient.utils.renderer;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.resources.*;
import net.minecraft.crash.CrashReport;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.fml.common.*;
import net.minecraftforge.fml.common.asm.FMLSanityChecker;
import org.apache.commons.io.IOUtils;
import org.lwjgl.BufferUtils;
import org.lwjgl.LWJGLException;
import org.lwjgl.opengl.Display;
import org.lwjgl.opengl.Drawable;
import org.lwjgl.opengl.SharedDrawable;
import org.lwjgl.util.glu.GLU;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import javax.imageio.ImageIO;
import javax.imageio.ImageReader;
import javax.imageio.stream.ImageInputStream;
import java.awt.image.BufferedImage;
import java.io.*;
import java.nio.IntBuffer;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Iterator;
import java.util.Properties;
import java.util.concurrent.Semaphore;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

import static org.lwjgl.opengl.GL11.*;
import static org.lwjgl.opengl.GL12.GL_BGRA;
import static org.lwjgl.opengl.GL12.GL_UNSIGNED_INT_8_8_8_8_REV;

public class ShimejiSplashProgress {
    static final Semaphore mutex = new Semaphore(1);
    //private static final BetterFontRenderer font = BetterFontRenderer.create(new Font("default", Font.BOLD, 20));
    private static SplashFontRenderer fontRenderer;
    private static final Lock lock = new ReentrantLock(true);
    private static final IResourcePack mcPack = Minecraft.getMinecraft().defaultResourcePack;
    private static final IResourcePack fmlPack = createResourcePack(FMLSanityChecker.fmlLocation);
    private static final int TIMING_FRAME_COUNT = 200;
    private static final int TIMING_FRAME_THRESHOLD = TIMING_FRAME_COUNT * 5 * 1000000;
    private static final IntBuffer buf = BufferUtils.createIntBuffer(4 * 1024 * 1024);
    static boolean isDisplayVSyncForced = false;
    private static Drawable drawable;
    private static volatile boolean pause = false;
    private static volatile boolean done = false;
    private static Thread thread;
    private static volatile Throwable threadError;
    private static IResourcePack miscPack;
    private static float animW = 0;
    private static Texture fontTexture;
    private static Texture logoTexture;
    private static Properties config;
    private static int max_texture_size = -1;

    private static String getString(String name, String def) {
        String value = config.getProperty(name, def);
        config.setProperty(name, value);
        return value;
    }

    public static void start() {
        File configFile = new File(Minecraft.getMinecraft().gameDir, "config/splash.properties");

        File parent = configFile.getParentFile();
        if (!parent.exists())
            parent.mkdirs();

        config = new Properties();
        Path path = configFile.toPath();
        try (Reader r = new InputStreamReader(Files.newInputStream(path), StandardCharsets.UTF_8)) {
            config.load(r);
        } catch (IOException e) {
            FMLLog.log.info("Could not load splash.properties, will create a default one");
        }

        final ResourceLocation fontLoc = new ResourceLocation(getString("fontTexture", "textures/font/ascii.png"));

        File miscPackFile = new File(Minecraft.getMinecraft().gameDir, getString("resourcePackPath", "resources"));

        try (Writer w = new OutputStreamWriter(Files.newOutputStream(path), StandardCharsets.UTF_8)) {
            config.store(w, "Splash screen properties");
        } catch (IOException e) {
            FMLLog.log.error("Could not save the splash.properties file", e);
        }

        miscPack = createResourcePack(miscPackFile);

        //if(!enabled) return;
        // getting debug info out of the way, while we still can
        FMLCommonHandler.instance().registerCrashCallable(new ICrashCallable() {
            @Override
            public String call() {
                return "' Vendor: '" + glGetString(GL_VENDOR) +
                        "' Version: '" + glGetString(GL_VERSION) +
                        "' Renderer: '" + glGetString(GL_RENDERER) +
                        "'";
            }

            @Override
            public String getLabel() {
                return "GL info";
            }
        });
        CrashReport report = CrashReport.makeCrashReport(new Throwable(), "Loading screen debug info");
        StringBuilder systemDetailsBuilder = new StringBuilder();
        report.getCategory().appendToStringBuilder(systemDetailsBuilder);
        FMLLog.log.info(systemDetailsBuilder.toString());

        try {
            drawable = new SharedDrawable(Display.getDrawable());
            Display.getDrawable().releaseContext();
            drawable.makeCurrent();
        } catch (LWJGLException e) {
            FMLLog.log.error("Error starting SplashProgress:", e);
            disableSplash(e);
        }

        getMaxTextureSize();
        thread = new Thread(new Runnable() {
            private long updateTiming;
            private long framecount;

            @Override
            public void run() {
                setGL();
                logoTexture = new Texture(new ResourceLocation("image/logo_shadow.png"), null, false);
                fontTexture = new Texture(fontLoc, null);
                glEnable(GL_TEXTURE_2D);
                fontRenderer = new SplashFontRenderer();
                glDisable(GL_TEXTURE_2D);
                while (!done) {
                    framecount++;
                    ProgressManager.ProgressBar first = null;
                    ProgressManager.ProgressBar penult = null;
                    ProgressManager.ProgressBar last = null;
                    Iterator<ProgressManager.ProgressBar> i = ProgressManager.barIterator();
                    while (i.hasNext()) {
                        if (first == null) first = i.next();
                        else {
                            penult = last;
                            last = i.next();
                        }
                    }

                    glClear(GL_COLOR_BUFFER_BIT);

                    int width = Display.getWidth();
                    int height = Display.getHeight();
                    glViewport(0, 0, width, height);
                    glMatrixMode(GL_PROJECTION);
                    glLoadIdentity();
                    glOrtho(320 - width / 2f, 320 + width / 2f, 240 + height / 2f, 240 - height / 2f, -1, 1);
                    glMatrixMode(GL_MODELVIEW);
                    glLoadIdentity();

                    setColor3ub(0xFFFFFF);
                    glEnable(GL_TEXTURE_2D);
                    GlStateManager.disableAlpha();
                    GlStateManager.enableBlend();
                    logoTexture.bind();
                    glBegin(GL_QUADS);
                    logoTexture.texCoord(0, 0, 0);
                    glVertex2f(320 - 500 / 1.3f, 240 - 193 / 1.3f);
                    logoTexture.texCoord(0, 0, 1);
                    glVertex2f(320 - 500 / 1.3f, 240 + 193 / 1.3f);
                    logoTexture.texCoord(0, 1, 1);
                    glVertex2f(320 + 500 / 1.3f, 240 + 193 / 1.3f);
                    logoTexture.texCoord(0, 1, 0);
                    glVertex2f(320 + 500 / 1.3f, 240 - 193 / 1.3f);
                    glEnd();
                    GlStateManager.enableAlpha();
                    glDisable(GL_TEXTURE_2D);

                    // bars
                    if (first != null) {
                        glPushMatrix();
                        glTranslatef(320 - width / 2f, 240 - height / 2f, 0);
                        drawProgressBar(first);
                        glPopMatrix();
                    }

                    mutex.acquireUninterruptibly();
                    long updateStart = System.nanoTime();
                    Display.update();

                    long dur = System.nanoTime() - updateStart;
                    if (framecount < TIMING_FRAME_COUNT) {
                        updateTiming += dur;
                    }
                    mutex.release();
                    if (pause) {
                        clearGL();
                        setGL();
                    }

                    if (framecount >= TIMING_FRAME_COUNT && updateTiming > TIMING_FRAME_THRESHOLD) {
                        if (!isDisplayVSyncForced) {
                            isDisplayVSyncForced = true;
                            FMLLog.log.info("Using alternative sync timing : {} frames of Display.update took {} nanos", TIMING_FRAME_COUNT, updateTiming);
                        }
                        try {
                            Thread.sleep(16);
                        } catch (InterruptedException ignored) {
                        }
                    } else {
                        if (framecount == TIMING_FRAME_COUNT) {
                            FMLLog.log.info("Using sync timing. {} frames of Display.update took {} nanos", TIMING_FRAME_COUNT, updateTiming);
                        }
                        Display.sync(100);
                    }
                }
                clearGL();
            }

            private void setColor3ub(int color) {
                glColor3ub((byte) ((color >> 16) & 0xFF), (byte) ((color >> 8) & 0xFF), (byte) (color & 0xFF));
            }

            private void setColor4ub(int color) {
                glColor4ub((byte) ((color >> 24) & 0xFF), (byte) ((color >> 16) & 0xFF), (byte) ((color >> 8) & 0xFF), (byte) (color & 0xFF));
            }

            private void drawBox(float width, float height) {
                glBegin(GL_QUADS);
                glVertex2f(0, 0);
                glVertex2f(0, height);
                glVertex2f(width, height);
                glVertex2f(width, 0);
                glEnd();
            }

            private void drawProgressBar(ProgressManager.ProgressBar b) {
                glPushMatrix();
                glTranslatef(0, Display.getHeight() - 60, 0);
                setColor3ub(0x282828);
                drawBox(Display.getWidth(), 60);
                setColor3ub(0x946CD4);
                animW = animate((Display.getWidth()) * (b.getStep() + 1f) / (b.getSteps() + 1f), animW, 0.2F);
                drawBox(animW, 60);
                glPopMatrix();
                glPushMatrix();
                glScalef(2, 2, 1);
                glEnable(GL_TEXTURE_2D);
                String text = String.format("\u00A7i%s - %s %s/%s", b.getTitle(), b.getMessage(), b.getStep(), b.getSteps());
                //setColor3ub(0xFFFFFF);
                glTranslatef(Display.getWidth() / 4f - fontRenderer.getStringWidth(text) / 2f, Display.getHeight() / 2f - (60 / 2f - fontRenderer.FONT_HEIGHT / 2f), 0);
                fontRenderer.drawString(text, 0, 0, -1, true);
                glDisable(GL_TEXTURE_2D);
                glPopMatrix();
            }

            private void setGL() {
                int bg = 0x1E1E1E;

                lock.lock();
                try {
                    Display.getDrawable().makeCurrent();
                } catch (LWJGLException e) {
                    FMLLog.log.error("Error setting GL context:", e);
                    throw new RuntimeException(e);
                }
                glClearColor((float) ((bg >> 16) & 0xFF) / 0xFF, (float) ((bg >> 8) & 0xFF) / 0xFF, (float) (bg & 0xFF) / 0xFF, 1);
                glDisable(GL_LIGHTING);
                glDisable(GL_DEPTH_TEST);
                glEnable(GL_BLEND);
                glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
            }

            private void clearGL() {
                Minecraft mc = Minecraft.getMinecraft();
                mc.displayWidth = Display.getWidth();
                mc.displayHeight = Display.getHeight();
                mc.resize(mc.displayWidth, mc.displayHeight);
                glClearColor(1, 1, 1, 1);
                glEnable(GL_DEPTH_TEST);
                glDepthFunc(GL_LEQUAL);
                glEnable(GL_ALPHA_TEST);
                glAlphaFunc(GL_GREATER, .1f);
                try {
                    Display.getDrawable().releaseContext();
                } catch (LWJGLException e) {
                    FMLLog.log.error("Error releasing GL context:", e);
                    throw new RuntimeException(e);
                } finally {
                    lock.unlock();
                }
            }
        });
        thread.setUncaughtExceptionHandler((t, e) -> {
            FMLLog.log.error("Splash thread Exception", e);
            threadError = e;
        });
        thread.start();
        checkThreadState();
    }

    public static int getMaxTextureSize() {
        if (max_texture_size != -1) return max_texture_size;
        for (int i = 0x4000; i > 0; i >>= 1) {
            GlStateManager.glTexImage2D(GL_PROXY_TEXTURE_2D, 0, GL_RGBA, i, i, 0, GL_RGBA, GL_UNSIGNED_BYTE, null);
            if (GlStateManager.glGetTexLevelParameteri(GL_PROXY_TEXTURE_2D, 0, GL_TEXTURE_WIDTH) != 0) {
                max_texture_size = i;
                return i;
            }
        }
        return -1;
    }

    private static void checkThreadState() {
        if (thread.getState() == null || thread.getState() == Thread.State.TERMINATED || threadError != null) {
            throw new IllegalStateException("Splash thread", threadError);
        }
    }

    /**
     * Call before you need to explicitly modify GL context state during loading.
     * Resource loading doesn't usually require this call.
     * Call {@link #resume()} when you're done.
     *
     * @deprecated not a stable API, will break, don't use this yet
     */
    @Deprecated
    public static void pause() {
        checkThreadState();
        pause = true;
        lock.lock();
        try {
            drawable.releaseContext();
            Display.getDrawable().makeCurrent();
        } catch (LWJGLException e) {
            FMLLog.log.error("Error setting GL context:", e);
            throw new RuntimeException(e);
        }
    }

    /**
     * @deprecated not a stable API, will break, don't use this yet
     */
    @Deprecated
    public static void resume() {
        checkThreadState();
        pause = false;
        try {
            Display.getDrawable().releaseContext();
            drawable.makeCurrent();
        } catch (LWJGLException e) {
            FMLLog.log.error("Error releasing GL context:", e);
            throw new RuntimeException(e);
        }
        lock.unlock();
    }

    public static void finish() {
        try {
            checkThreadState();
            done = true;
            thread.join();
            glFlush();
            drawable.releaseContext();
            Display.getDrawable().makeCurrent();
            fontTexture.delete();
        } catch (Exception e) {
            FMLLog.log.error("Error finishing SplashProgress:", e);
            disableSplash(e);
        }
    }

    private static void disableSplash(Exception e) {
        if (disableSplash()) {
            throw new EnhancedRuntimeException(e) {
                @Override
                protected void printStackTrace(WrappedPrintStream stream) {
                    stream.println("SplashProgress has detected a error loading Minecraft.");
                    stream.println("This can sometimes be caused by bad video drivers.");
                    stream.println("We have automatically disabled the new Splash Screen in config/splash.properties.");
                    stream.println("Try reloading minecraft before reporting any errors.");
                }
            };
        } else {
            throw new EnhancedRuntimeException(e) {
                @Override
                protected void printStackTrace(WrappedPrintStream stream) {
                    stream.println("SplashProgress has detected a error loading Minecraft.");
                    stream.println("This can sometimes be caused by bad video drivers.");
                    stream.println("Please try disabling the new Splash Screen in config/splash.properties.");
                    stream.println("After doing so, try reloading minecraft before reporting any errors.");
                }
            };
        }
    }

    private static boolean disableSplash() {
        File configFile = new File(Minecraft.getMinecraft().gameDir, "config/splash.properties");
        File parent = configFile.getParentFile();
        if (!parent.exists()) parent.mkdirs();

        config.setProperty("enabled", "false");

        try (Writer w = new OutputStreamWriter(Files.newOutputStream(configFile.toPath()), StandardCharsets.UTF_8)) {
            config.store(w, "Splash screen properties");
        } catch (IOException e) {
            FMLLog.log.error("Could not save the splash.properties file", e);
            return false;
        }
        return true;
    }

    private static IResourcePack createResourcePack(File file) {
        if (file.isDirectory()) {
            return new FolderResourcePack(file);
        } else {
            return new FileResourcePack(file);
        }
    }

    public static void checkGLError(String where) {
        int err = glGetError();
        if (err != 0) {
            throw new IllegalStateException(where + ": " + GLU.gluErrorString(err));
        }
    }

    private static InputStream open(ResourceLocation loc, @Nullable ResourceLocation fallback, boolean allowResourcePack) throws IOException {
        if (!allowResourcePack)
            return mcPack.getInputStream(loc);

        if (miscPack.resourceExists(loc)) {
            return miscPack.getInputStream(loc);
        } else if (fmlPack.resourceExists(loc)) {
            return fmlPack.getInputStream(loc);
        } else if (!mcPack.resourceExists(loc) && fallback != null) {
            return open(fallback, null, true);
        }

        return mcPack.getInputStream(loc);
    }

    public static float animate(float target, float current, float speed) {
        boolean larger = target >= current;

        if (speed < 0.0) {
            speed = 0.0f;
        } else if (speed > 1.0) {
            speed = 1.0f;
        }

        float dif = Math.max(target, current) - Math.min(target, current);
        float factor = dif * speed;

        if (factor < 0.1) {
            factor = 0.1f;
        }

        if (larger) {
            current += factor;
        } else {
            current -= factor;
        }

        return current;
    }

    @SuppressWarnings("unused")
    private static class Texture {
        private final ResourceLocation location;
        private final int name;
        private final int width;
        private final int height;
        private final int frames;
        private final int size;

        public Texture(ResourceLocation location, @Nullable ResourceLocation fallback) {
            this(location, fallback, true);
        }

        public Texture(ResourceLocation location, @Nullable ResourceLocation fallback, boolean allowRP) {
            InputStream s = null;
            try {
                this.location = location;
                s = open(location, fallback, allowRP);
                ImageInputStream stream = ImageIO.createImageInputStream(s);
                Iterator<ImageReader> readers = ImageIO.getImageReaders(stream);
                if (!readers.hasNext()) throw new IOException("No suitable reader found for image" + location);
                ImageReader reader = readers.next();
                reader.setInput(stream);
                int frames = reader.getNumImages(true);
                BufferedImage[] images = new BufferedImage[frames];
                for (int i = 0; i < frames; i++) {
                    images[i] = reader.read(i);
                }
                reader.dispose();
                width = images[0].getWidth();
                int height = images[0].getHeight();
                // Animation strip
                if (height > width && height % width == 0) {
                    frames = height / width;
                    BufferedImage original = images[0];
                    height = width;
                    images = new BufferedImage[frames];
                    for (int i = 0; i < frames; i++) {
                        images[i] = original.getSubimage(0, i * height, width, height);
                    }
                }
                this.frames = frames;
                this.height = height;
                int size = 1;
                while ((size / width) * (size / height) < frames) size *= 2;
                this.size = size;
                glEnable(GL_TEXTURE_2D);
                synchronized (ShimejiSplashProgress.class) {
                    name = glGenTextures();
                    glBindTexture(GL_TEXTURE_2D, name);
                }
                glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
                glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
                glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, size, size, 0, GL_BGRA, GL_UNSIGNED_INT_8_8_8_8_REV, (IntBuffer) null);
                checkGLError("Texture creation");
                for (int i = 0; i * (size / width) < frames; i++) {
                    for (int j = 0; i * (size / width) + j < frames && j < size / width; j++) {
                        buf.clear();
                        BufferedImage image = images[i * (size / width) + j];
                        for (int k = 0; k < height; k++) {
                            for (int l = 0; l < width; l++) {
                                buf.put(image.getRGB(l, k));
                            }
                        }
                        buf.position(0).limit(width * height);
                        glTexSubImage2D(GL_TEXTURE_2D, 0, j * width, i * height, width, height, GL_BGRA, GL_UNSIGNED_INT_8_8_8_8_REV, buf);
                        checkGLError("Texture uploading");
                    }
                }
                glBindTexture(GL_TEXTURE_2D, 0);
                glDisable(GL_TEXTURE_2D);
            } catch (IOException e) {
                FMLLog.log.error("Error reading texture from file: {}", location, e);
                throw new RuntimeException(e);
            } finally {
                IOUtils.closeQuietly(s);
            }
        }

        public ResourceLocation getLocation() {
            return location;
        }

        public int getName() {
            return name;
        }

        public int getWidth() {
            return width;
        }

        public int getHeight() {
            return height;
        }

        public int getFrames() {
            return frames;
        }

        public int getSize() {
            return size;
        }

        public void bind() {
            glBindTexture(GL_TEXTURE_2D, name);
        }

        public void delete() {
            glDeleteTextures(name);
        }

        public float getU(int frame, float u) {
            return width * (frame % ((float) size / width) + u) / size;
        }

        public float getV(int frame, float v) {
            return height * (frame / ((float) size / width) + v) / size;
        }

        public void texCoord(int frame, float u, float v) {
            glTexCoord2f(getU(frame, u), getV(frame, v));
        }
    }

    @SuppressWarnings("all")
    private static class SplashFontRenderer extends FontRenderer {
        public SplashFontRenderer() {
            super(Minecraft.getMinecraft().gameSettings, fontTexture.getLocation(), null, false);
            super.onResourceManagerReload(null);
        }

        @Override
        protected void bindTexture(@Nonnull ResourceLocation location) {
            if (location != locationFontTexture) throw new IllegalArgumentException();
            fontTexture.bind();
        }

        @Nonnull
        @Override
        protected IResource getResource(@Nonnull ResourceLocation location) throws IOException {
            DefaultResourcePack pack = Minecraft.getMinecraft().defaultResourcePack;
            return new SimpleResource(pack.getPackName(), location, pack.getInputStream(location), null, null);
        }
    }
}