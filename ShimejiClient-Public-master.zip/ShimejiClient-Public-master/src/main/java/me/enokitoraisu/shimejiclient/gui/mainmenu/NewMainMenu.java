package me.enokitoraisu.shimejiclient.gui.mainmenu;

import me.enokitoraisu.shimejiclient.ShimejiClient;
import me.enokitoraisu.shimejiclient.module.impl.client.MMainMenu;
import me.enokitoraisu.shimejiclient.utils.renderer.font.FontUtil;
import net.minecraft.client.gui.GuiMultiplayer;
import net.minecraft.client.gui.GuiOptions;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.GuiWorldSelection;
import net.minecraftforge.fml.client.GuiModList;
import org.lwjgl.opengl.GL11;

import java.awt.*;

import static me.enokitoraisu.shimejiclient.utils.renderer.RenderUtil.drawCircle;
import static me.enokitoraisu.shimejiclient.utils.renderer.RenderUtil.drawRoundedRect;

public class NewMainMenu extends GuiScreen {
    private final String[] CenterButton = {
            "SinglePlayer",
            "MultiPlayer",
            "ModList"
    };

    private final String[] RightUpButton = {
            "Exit",
            "Setting",
            "LightMode"
    };

    public void drawScreen(int mouseX, int mouseY, float partialTicks) {
        boolean light = MMainMenu.INSTANCE.lightModeSetting.getValue();

        drawRect(0, 0, width, height, new Color(light ? 0xFFE5E5E5 : 0xFF171717).getRGB());
        FontUtil.albula40.drawCenteredString(ShimejiClient.ModName, width / 2f, height / 2f - FontUtil.albula40.getHeight() - 20 * 3, light ? 0 : -1);
        int offset = 0;
        for (String button : CenterButton) {
            int x = width / 2;
            int y = (height / 2 - 20) + offset;
            boolean bounding = mouseX >= x - 50 && mouseY >= y && mouseX < x + 50 && mouseY < y + FontUtil.albula20.getHeight() + 10;
            drawRoundedRect(x - 50, y, 100, FontUtil.albula20.getHeight() + 10, 10.0f, light ? (bounding ? 0xFFC0C0C0 : 0xFFFFFFFF) : (bounding ? 0xFF3F3F3F : 0xFF000000));
            GL11.glColor3f(1.0f, 1.0f, 1.0f);
            FontUtil.albula20.drawString(button, x - FontUtil.albula20.getStringWidth(button) / 2f, (y - 2) + FontUtil.albula20.getHeight() / 2f, light ? 0 : -1);
            offset += 30;
        }

        boolean circle_hover = mouseX >= width - 40 && mouseY >= height - 40 && mouseX < width && mouseY < height;
        drawCircle(width, height, 40.0f, light ? (circle_hover ? 0xFFC0C0C0 : 0xFFFFFFFF) : (circle_hover ? 0xFF3F3F3F : 0xFF000000));
        FontUtil.icon30.drawCenteredStringWithShadow("->", width - 20, height - 20, light ? 0 : -1);
        int offset2 = 2;
        for (String button : RightUpButton) {
            int circle_size = 13;
            int x = width - (offset2 + circle_size);
            int y = 2 + circle_size;

            boolean bounding = mouseX >= x - circle_size && mouseY >= y - circle_size && mouseX < x + circle_size && mouseY < y + circle_size;

            drawCircle(x, y, circle_size, light ? (bounding ? 0xffC0C0C0 : 0xffffffff) : (bounding ? 0xFF3F3F3F : 0xFF000000));
            switch (button) {
                case "Exit":
                    FontUtil.icon30.drawCenteredString("x", x, y - FontUtil.icon30.getHeight() / 2f + 2, light ? 0xFF000000 : 0xFFFFFFFF);
                    break;
                case "Setting":
                    FontUtil.icon30.drawCenteredString("E", x, y - FontUtil.icon30.getHeight() / 2f + 2, light ? 0xFF000000 : 0xFFFFFFFF);
                    break;
                case "LightMode":
                    FontUtil.icon30.drawCenteredString("c", x, y - FontUtil.icon30.getHeight() / 2f + 2, light ? 0xFF000000 : 0xFFFFFFFF);
                    break;
            }
            offset2 += circle_size * 2 + 2;
        }
    }

    @Override
    public void mouseClicked(int mouseX, int mouseY, int button) {
        int offset = 0;
        for (String buttons : CenterButton) {
            int x = width / 2;
            int y = (height / 2 - 20) + offset;
            if (mouseX >= x - 50 && mouseY >= y && mouseX < x + 50 && mouseY < y + FontUtil.albula20.getHeight() + 10 && button == 0) {
                switch (buttons) {
                    case "SinglePlayer":
                        mc.displayGuiScreen(new GuiWorldSelection(this));
                        break;
                    case "MultiPlayer":
                        mc.displayGuiScreen(new GuiMultiplayer(this));
                        break;
                    case "ModList":
                        mc.displayGuiScreen(new GuiModList(this));
                        break;
                }
            }
            offset += 30;
        }

        int offset2 = 2;
        for (String buttons : RightUpButton) {
            int circle_size = 13;
            int x = width - (offset2 + circle_size);
            int y = 2 + circle_size;

            if (mouseX >= x - circle_size && mouseY >= y - circle_size && mouseX < x + circle_size && mouseY < y + circle_size && button == 0) {
                switch (buttons) {
                    case "Exit":
                        mc.shutdown();
                        break;
                    case "Setting":
                        mc.displayGuiScreen(new GuiOptions(this, mc.gameSettings));
                        break;
                    case "LightMode":
                        MMainMenu.INSTANCE.lightModeSetting.setValue(!MMainMenu.INSTANCE.lightModeSetting.getValue());
                        break;
                }
            }
            offset2 += circle_size * 2 + 2;
        }
        if (mouseX >= width - 40 && mouseY >= height - 40 && mouseX < width && mouseY < height && button == 0) {
            MMainMenu.INSTANCE.styleSetting.setValue("Minecraft");
            mc.displayGuiScreen(new MainMenu());
        }
    }
}
