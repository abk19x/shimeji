package me.enokitoraisu.shimejiclient.module.impl.misc;

import me.enokitoraisu.shimejiclient.mixin.AccessorMinecraft;
import me.enokitoraisu.shimejiclient.mixin.AccessorTimer;
import me.enokitoraisu.shimejiclient.module.Category;
import me.enokitoraisu.shimejiclient.module.Module;
import me.enokitoraisu.shimejiclient.value.values.FloatValue;
import org.lwjgl.input.Keyboard;

@SuppressWarnings("unused")
public class Timer extends Module {
    public FloatValue delay = register(new FloatValue("Delay", 2.0F, 0.1F, 10.0F));

    public Timer() {
        super("Timer", Category.MISC, Keyboard.KEY_NONE);
    }

    @Override
    public void onDisable() {
        ((AccessorTimer) ((AccessorMinecraft) mc).timer()).tickLength(50.0f);
    }

    @Override
    public void onTick() {
        ((AccessorTimer) ((AccessorMinecraft) mc).timer()).tickLength(50.0f / delay.getValue());
    }
}
