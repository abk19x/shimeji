package me.enokitoraisu.shimejiclient.command.impl;

import me.enokitoraisu.shimejiclient.command.Command;
import me.enokitoraisu.shimejiclient.utils.entity.FriendUtil;

@SuppressWarnings("unused")
public class Friend extends Command {
    public Friend() {
        super("Friend", "Manage friends.");
    }

    @Override
    public void onCommand() {
        try {
            String arg = arg(1);
            switch (arg) {
                case "add": {
                    String username = arg(2);
                    for (String name : FriendUtil.friends) {
                        if (username.equals(name)) {
                            sendMessage(String.format("%s has already been added to friend", username));
                            return;
                        }
                    }
                    FriendUtil.friends.add(username);
                    sendMessage(String.format("Added player to friend %s", username));
                    break;
                }
                case "del":
                case "remove": {
                    String username = arg(2);
                    boolean already = false;
                    for (String name : FriendUtil.friends) {
                        if (username.equals(name)) {
                            already = true;
                            break;
                        }
                    }
                    if (already) {
                        FriendUtil.friends.remove(username);
                        sendMessage(String.format("Removed player to friend %s", username));
                    } else {
                        sendMessage(String.format("%s has not been added to friend", username));
                    }
                    break;
                }
                case "list":
                    sendMessage("FriendList");
                    FriendUtil.friends.forEach(Command::sendMessage);
                    break;
            }
        } catch (Exception e) {
            sendMessage("Usage: >Friend <add : remove> <PlayerName>, >Friend list");
        }
    }
}
