package me.enokitoraisu.shimejiclient.module.impl.movement;

import me.enokitoraisu.shimejiclient.mixin.AccessorKeyBinding;
import me.enokitoraisu.shimejiclient.module.Category;
import me.enokitoraisu.shimejiclient.module.Module;
import org.lwjgl.input.Keyboard;

@SuppressWarnings("unused")
public class AutoWalk extends Module {

    public AutoWalk() {
        super("AutoWalk", Category.MOVEMENT, Keyboard.KEY_NONE);
    }

    @Override
    public void onTick() {
        ((AccessorKeyBinding) mc.gameSettings.keyBindForward).pressed(true);
    }

    public void onDisable() {
        ((AccessorKeyBinding) mc.gameSettings.keyBindForward).pressed(false);
    }
}
