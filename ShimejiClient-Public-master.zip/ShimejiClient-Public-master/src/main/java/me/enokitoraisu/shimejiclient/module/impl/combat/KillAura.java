package me.enokitoraisu.shimejiclient.module.impl.combat;

import me.enokitoraisu.shimejiclient.module.Category;
import me.enokitoraisu.shimejiclient.module.Module;
import me.enokitoraisu.shimejiclient.utils.entity.DamageUtil;
import me.enokitoraisu.shimejiclient.utils.entity.FriendUtil;
import me.enokitoraisu.shimejiclient.utils.math.TimerUtil;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.EnumHand;
import org.lwjgl.input.Keyboard;

import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

@SuppressWarnings("unused")
public class KillAura extends Module {
    public TimerUtil timerUtil = new TimerUtil();

    public KillAura() {
        super("KillAura", "MAJINO GOMI", Category.COMBAT, Keyboard.KEY_NONE);
    }

    @Override
    public void onTick() {
        List<Entity> targets = mc.world.loadedEntityList.stream().filter(EntityLivingBase.class::isInstance).filter(entity -> {
            if (entity instanceof EntityPlayer) {
                return !FriendUtil.isFriend((EntityPlayer) entity);
            } else {
                return true;
            }
        }).collect(Collectors.toList());

        targets = targets.stream().filter(entity -> entity.getDistance(mc.player) < 4.0 && entity != mc.player).collect(Collectors.toList());

        targets.sort(Comparator.comparingDouble(mc.player::getDistance));

        if (!targets.isEmpty()) {
            EntityLivingBase target = (EntityLivingBase) targets.get(0);

            if (target.isDead && target.getHealth() < 0) return;
            mc.player.rotationYawHead = this.getRotation(target)[0];
            mc.player.renderYawOffset = this.getRotation(target)[0];

            if (timerUtil.passedMs(DamageUtil.getCoolDownByWeapon(mc.player))) {
                mc.playerController.attackEntity(mc.player, target);
                mc.player.swingArm(EnumHand.MAIN_HAND);
                timerUtil.reset();
            }
        }
    }

    public float[] getRotation(Entity e) {
        double deltaX = e.posX + (e.posX - e.lastTickPosX) - mc.player.posX,
                deltaY = e.posY - 3.5f + e.getEyeHeight() - mc.player.posY + mc.player.getEyeHeight(),
                deltaZ = e.posZ + (e.posZ - e.lastTickPosZ) - mc.player.posZ,
                distance = Math.sqrt(Math.pow(deltaX, 2) + Math.pow(deltaZ, 2));

        float yaw = (float) Math.toDegrees(-Math.atan(deltaX / deltaZ)),
                pitch = (float) -Math.toDegrees(Math.atan(deltaY / distance));

        double toDegrees = Math.toDegrees(Math.atan(deltaZ / deltaX));
        if (deltaX < 0 && deltaZ < 0) {
            yaw = (float) (90 + toDegrees);
        } else if (deltaX > 0 && deltaZ < 0) {
            yaw = (float) (-90 + toDegrees);
        }

        return new float[]{yaw, pitch};
    }
}
