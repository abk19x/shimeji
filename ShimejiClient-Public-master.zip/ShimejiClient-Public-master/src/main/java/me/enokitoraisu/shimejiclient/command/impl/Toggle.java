package me.enokitoraisu.shimejiclient.command.impl;

import com.mojang.realmsclient.gui.ChatFormatting;
import me.enokitoraisu.shimejiclient.ShimejiClient;
import me.enokitoraisu.shimejiclient.command.Command;
import me.enokitoraisu.shimejiclient.module.Module;

@SuppressWarnings("unused")
public class Toggle extends Command {
    public Toggle() {
        super("Toggle", "Toggles a module on or off.");
    }

    @Override
    public void onCommand() {
        try {
            for (Module m : ShimejiClient.moduleManager.modules) {
                if (m.name.equalsIgnoreCase(arg(1))) {
                    m.toggle();
                    sendMessage(String.format("%sToggled %s", ChatFormatting.GREEN, m.name));
                    return;
                }
            }
            sendMessage("No Module Name");
        } catch (Exception ex) {
            sendMessage("Usage: >Toggle <Module>");
        }
    }
}
