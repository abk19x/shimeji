package me.enokitoraisu.shimejiclient.module.impl.player;

import me.enokitoraisu.shimejiclient.module.Category;
import me.enokitoraisu.shimejiclient.module.Module;
import me.enokitoraisu.shimejiclient.utils.renderer.RenderUtil3D;
import me.enokitoraisu.shimejiclient.value.values.BooleanValue;
import net.minecraft.init.Blocks;
import net.minecraft.item.ItemBlock;
import net.minecraft.network.play.client.CPacketPlayerTryUseItemOnBlock;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.RayTraceResult;
import org.lwjgl.input.Keyboard;
import org.lwjgl.input.Mouse;

@SuppressWarnings("unused")
public class AirPlace extends Module {
    private final BooleanValue packet = register(new BooleanValue("PacketPlace", false));

    public AirPlace() {
        super("AirPlace", Category.PLAYER, Keyboard.KEY_NONE);
    }

    @Override
    public void onTick() {
        if (mc.objectMouseOver != null && mc.player.inventory.getStackInSlot(mc.player.inventory.currentItem).getItem() instanceof ItemBlock && mc.objectMouseOver.typeOfHit == RayTraceResult.Type.MISS && mc.world.getBlockState(mc.objectMouseOver.getBlockPos()).getBlock() == Blocks.AIR) {
            if (Mouse.isButtonDown(1)) {
                RayTraceResult trace = mc.objectMouseOver;

                if (packet.getValue())
                    mc.player.connection.sendPacket(new CPacketPlayerTryUseItemOnBlock(
                            trace.getBlockPos(),
                            trace.sideHit, EnumHand.MAIN_HAND,
                            (float) (trace.hitVec.x - (double) trace.getBlockPos().getX()),
                            (float) (trace.hitVec.y - (double) trace.getBlockPos().getY()),
                            (float) (trace.hitVec.z - (double) trace.getBlockPos().getZ()))
                    );
                else
                    mc.playerController.processRightClickBlock(mc.player, mc.world, trace.getBlockPos(), trace.sideHit, trace.hitVec, EnumHand.MAIN_HAND);
            }
        }
    }

    @Override
    public void onRender3D() {
        if (mc.objectMouseOver != null && mc.objectMouseOver.typeOfHit == RayTraceResult.Type.MISS && mc.world.getBlockState(mc.objectMouseOver.getBlockPos()).getBlock() == Blocks.AIR) {
            RenderUtil3D.drawBox(mc.objectMouseOver.getBlockPos(), 0x00000000, 0xFF000000, false, true, 1.0f);
        }
    }
}
