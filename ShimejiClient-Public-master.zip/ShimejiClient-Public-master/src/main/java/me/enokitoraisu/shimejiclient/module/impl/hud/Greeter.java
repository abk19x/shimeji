package me.enokitoraisu.shimejiclient.module.impl.hud;

import me.enokitoraisu.shimejiclient.module.Category;
import me.enokitoraisu.shimejiclient.module.Module;
import me.enokitoraisu.shimejiclient.utils.math.ColorUtil;
import me.enokitoraisu.shimejiclient.utils.math.MathUtil;
import me.enokitoraisu.shimejiclient.utils.renderer.font.FontUtil;
import me.enokitoraisu.shimejiclient.utils.renderer.font.MinecraftFontRenderer;
import me.enokitoraisu.shimejiclient.value.values.BooleanValue;
import me.enokitoraisu.shimejiclient.value.values.ColorValue;
import me.enokitoraisu.shimejiclient.value.values.FloatValue;
import me.enokitoraisu.shimejiclient.value.values.IntegerValue;
import net.minecraft.client.gui.ScaledResolution;
import org.lwjgl.input.Keyboard;

import java.awt.*;

@SuppressWarnings("unused")
public class Greeter extends Module {
    public static ScaledResolution resolution = new ScaledResolution(mc);
    public BooleanValue font = register(new BooleanValue("CustomFont", false));
    public ColorValue color = register(new ColorValue("Color", new Color(179, 220, 239, 255)));
    public FloatValue speed = register(new FloatValue("Speed", 0.0F, 0.0F, 5.0F));
    public IntegerValue yOffset = register(new IntegerValue("YOffset", 0, 0, resolution.getScaledHeight()));
    private float offset = 0.0F;

    public Greeter() {
        super("Greeter", Category.HUD, Keyboard.KEY_NONE);
    }

    @Override
    public void onRender2D() {
        MinecraftFontRenderer fontRenderer = FontUtil.sfui20;
        ScaledResolution resolution = new ScaledResolution(mc);
        yOffset.setMax(resolution.getScaledHeight());
        String Username = mc.getSession().getUsername();

        if (!mc.gameSettings.showDebugInfo) {
            String Msg = MathUtil.getTimeOfDay() + Username;
            if (font.getValue())
                fontRenderer.drawStringWithShadow(Msg, (int) ((-fontRenderer.getStringWidth(Msg)) + offset), yOffset.getValue(), ColorUtil.toRGBA(color.getValue()));
            else
                mc.fontRenderer.drawStringWithShadow(Msg, (int) ((-mc.fontRenderer.getStringWidth(Msg)) + offset), yOffset.getValue(), ColorUtil.toRGBA(color.getValue()));
            offset += 0.1F + (speed.getValue() / 2);
            if (offset > (resolution.getScaledWidth() + (font.getValue() ? fontRenderer.getStringWidth(Msg) : mc.fontRenderer.getStringWidth(Msg)))) {
                offset = 0;
            }
        }
    }
}
