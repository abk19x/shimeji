package me.enokitoraisu.shimejiclient.utils.renderer;

import me.enokitoraisu.shimejiclient.mixin.AccessorShaderGroup;
import me.enokitoraisu.shimejiclient.module.impl.render.MotionBlur;
import me.enokitoraisu.shimejiclient.utils.interfaces.Util;
import me.spotify.gson.JsonSyntaxException;
import net.minecraft.client.shader.ShaderGroup;
import net.minecraft.client.shader.ShaderUniform;
import net.minecraft.util.ResourceLocation;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.IOException;

public class MotionBlurUtil implements Util {

    public static final MotionBlurUtil instance = new MotionBlurUtil();

    private static final ResourceLocation location = new ResourceLocation("minecraft:shaders/post/motion_blur.json");
    private static final Logger logger = LogManager.getLogger();

    private ShaderGroup shader;
    private float shaderBlur;

    public float getBlurFactor() {
        return (float) MotionBlur.INSTANCE.amount.getValue() / 10;
    }

    public ShaderGroup getShader() {
        if (shader == null) {
            shaderBlur = Float.NaN;

            try {
                shader = new ShaderGroup(mc.getTextureManager(), mc.getResourceManager(), mc.getFramebuffer(), location);
                shader.createBindFramebuffers(mc.displayWidth, mc.displayHeight);
            } catch (JsonSyntaxException | IOException error) {
                logger.error("Could not load motion blur shader", error);
                return null;
            }
        }

        if (shaderBlur != getBlurFactor()) {
            ((AccessorShaderGroup) shader).getListShaders().forEach((shader) -> {
                ShaderUniform blendFactorUniform = shader.getShaderManager().getShaderUniform("BlurFactor");

                if (blendFactorUniform != null) {
                    blendFactorUniform.set(getBlurFactor());
                }
            });

            shaderBlur = getBlurFactor();
        }

        return shader;
    }

}