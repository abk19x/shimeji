package me.enokitoraisu.shimejiclient.value.values;

import me.enokitoraisu.shimejiclient.value.ValueBase;

import java.awt.*;
import java.util.function.Predicate;

public class ColorValue extends ValueBase<Color> {
    private final boolean enableAlpha;

    public ColorValue(String name, Color value) {
        this(name, value, true, v -> true);
    }

    public ColorValue(String name, Color value, boolean enableAlpha) {
        this(name, value, enableAlpha, v -> true);
    }

    public ColorValue(String name, Color value, Predicate<Color> visibility) {
        this(name, value, true, visibility);
    }

    public ColorValue(String name, Color value, boolean enableAlpha, Predicate<Color> visibility) {
        super(name, value, visibility);
        this.enableAlpha = enableAlpha;
    }

    public boolean isEnableAlpha() {
        return this.enableAlpha;
    }

    public int getIntValue() {
        return value.hashCode();
    }

    public void setIntValue(int value) {
        setValue(new Color(value, enableAlpha));
    }
}
