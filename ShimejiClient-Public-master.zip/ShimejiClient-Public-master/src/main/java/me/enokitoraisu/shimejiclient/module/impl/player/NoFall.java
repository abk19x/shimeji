package me.enokitoraisu.shimejiclient.module.impl.player;

import me.enokitoraisu.shimejiclient.event.PacketEvent;
import me.enokitoraisu.shimejiclient.mixin.AccessorCPacketPlayer;
import me.enokitoraisu.shimejiclient.module.Category;
import me.enokitoraisu.shimejiclient.module.Module;
import me.enokitoraisu.shimejiclient.value.values.ModeValue;
import net.minecraft.network.play.client.CPacketPlayer;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import org.lwjgl.input.Keyboard;

@SuppressWarnings("unused")
public class NoFall extends Module {
    public ModeValue mode = register(new ModeValue("Mode", "Packet", "Packet", "Hypixel"));

    public NoFall() {
        super("NoFall", Category.PLAYER, Keyboard.KEY_NONE);
    }

    @Override
    public void onTick() {
        setTags(mode.getValue());
        if (mode.getValue().equals("Hypixel")) {
            if (mc.player.fallDistance > 0.0f && mc.player.posY % 0.0625 != 0.0 || mc.player.posY % 0.015256 != 0.0) {
                mc.player.fallDistance = 2.0f;
                mc.player.connection.sendPacket(new CPacketPlayer(true));
            }
        }
    }

    @SubscribeEvent
    public void onPacket(PacketEvent.Send event) {
        if (mode.getValue().equals("Packet")) {
            if (event.getPacket() instanceof CPacketPlayer) {
                ((AccessorCPacketPlayer) event.getPacket()).onGround(false);
            }
        }
    }
}
