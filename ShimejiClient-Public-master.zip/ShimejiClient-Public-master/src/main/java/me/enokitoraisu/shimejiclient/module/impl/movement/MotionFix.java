package me.enokitoraisu.shimejiclient.module.impl.movement;

import me.enokitoraisu.shimejiclient.module.Category;
import me.enokitoraisu.shimejiclient.module.Module;
import org.lwjgl.input.Keyboard;

@SuppressWarnings("unused")
public class MotionFix extends Module {
    public MotionFix() {
        super("MotionFix", Category.MOVEMENT, Keyboard.KEY_NONE);
    }

    @Override
    public void onTick() {
        if (mc.player.movementInput.moveForward == 0 && mc.player.movementInput.moveStrafe == 0) {
            mc.player.motionX = 0;
            mc.player.motionZ = 0;
        }
    }
}
