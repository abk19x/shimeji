package me.enokitoraisu.shimejiclient;

import club.minnced.discord.rpc.DiscordEventHandlers;
import club.minnced.discord.rpc.DiscordRPC;
import club.minnced.discord.rpc.DiscordRichPresence;
import org.apache.logging.log4j.LogManager;

public class ShimejiRPC {
    public static void start(String applicationId) {
        try {
            DiscordRPC instance = DiscordRPC.INSTANCE;
            DiscordEventHandlers handlers = new DiscordEventHandlers();
            instance.Discord_Initialize(applicationId, handlers, true, "");
            DiscordRichPresence presence = new DiscordRichPresence();
            presence.startTimestamp = System.currentTimeMillis() / 1000;
            presence.details = ShimejiClient.Message;
            presence.largeImageKey = "logo";
            presence.largeImageText = ShimejiClient.ModName + " " + ShimejiClient.ModVersion;
            instance.Discord_UpdatePresence(presence);
            new Thread(() -> {
                while (!Thread.currentThread().isInterrupted()) {
                    instance.Discord_RunCallbacks();
                    try {
                        Thread.sleep(2000);
                    } catch (InterruptedException ignored) {
                    }
                }
            }, "RPC-Callback-Handler").start();
        } catch (Exception e) {
            LogManager.getLogger("DiscordRPC").error("DiscordRPC Start Thread Error", e);
        }
    }

    public static void stop() {
        try {
            DiscordRPC instance = DiscordRPC.INSTANCE;
            instance.Discord_ClearPresence();
            instance.Discord_Shutdown();
        } catch (Exception e) {
            LogManager.getLogger("DiscordRPC").error("DiscordRPC Stop Thread Error", e);
        }
    }
}
