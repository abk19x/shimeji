package me.enokitoraisu.shimejiclient.module.impl.hud;

import me.enokitoraisu.shimejiclient.module.Category;
import me.enokitoraisu.shimejiclient.module.HudModule;
import me.enokitoraisu.shimejiclient.utils.math.ColorConverter;
import me.enokitoraisu.shimejiclient.utils.renderer.RenderUtil;
import me.enokitoraisu.shimejiclient.value.values.IntegerValue;
import me.enokitoraisu.shimejiclient.value.values.ModeValue;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.resources.I18n;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.potion.Potion;
import net.minecraft.potion.PotionEffect;
import org.lwjgl.input.Keyboard;

import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;

@SuppressWarnings("unused")
public class PotionHud extends HudModule {
    public static final ConcurrentHashMap<Potion, Effect> effects = new ConcurrentHashMap<>();
    private final IntegerValue width = register(new IntegerValue("Width", 100, 100, 200));
    private final ModeValue hAlign = register(new ModeValue("H-Align", "Left", "Left", "Right"));
    private final ModeValue vAlign = register(new ModeValue("V-Align", "Top", "Top", "Bottom"));

    public PotionHud() {
        super("PotionHud", Category.HUD, Keyboard.KEY_NONE, 100, 100, 100, 100);
    }

    @Override
    public boolean drawScreen() {
        ScaledResolution scale = new ScaledResolution(mc);
        AtomicInteger i = new AtomicInteger();
        effects.forEach((potion, effect) -> {
            float value = (float) effect.getPotionEffect().getDuration() / (float) effect.getMaxDuration();
            int rectHeight = mc.fontRenderer.FONT_HEIGHT + 4;
            String text = getRenderText(effect.getPotionEffect());
            RenderUtil.drawRect(getX() + (hAlign.getValue().equals("Right") ? width.getValue() - width.getValue() * value : 0), getY() + rectHeight * i.get(), width.getValue() * value, rectHeight, new ColorConverter(effect.getPotionEffect().getPotion().getLiquidColor()).setAlpha(127));
            RenderUtil.drawOutLineRect(getX(), getY() + rectHeight * i.get(), width.getValue(), rectHeight, 1, new ColorConverter(effect.getPotionEffect().getPotion().getLiquidColor()).setAlpha(255));
            mc.fontRenderer.drawStringWithShadow(text, getX() + (hAlign.getValue().equals("Right") ? width.getValue() - mc.fontRenderer.getStringWidth(text) - 3 : 3), getY() + (rectHeight / 2f - mc.fontRenderer.FONT_HEIGHT / 2f) + rectHeight * i.get(), -1);
            i.getAndIncrement();
        });

        return true;
    }

    @Override
    public void drawChatScreen(int mouseX, int mouseY) {
        RenderUtil.drawOutLineRect(getX(), getY(), getWidth(), getHeight(), 1.0F, -1);
    }

    @Override
    public int getWidth() {
        return width.getValue();
    }

    @Override
    public int getHeight() {
        return Math.max(effects.size(), 1) * (mc.fontRenderer.FONT_HEIGHT + 4);
    }

    public String getRenderText(PotionEffect effect) {
        String amplifier = effect.getAmplifier() == 0 ? "" : (effect.getAmplifier() + 1) + " ";
        int second = effect.getDuration() / 20;
        int minute = second / 60;
        second = second % 60;
        String time = String.format("%d:%s", minute, second <= 9 ? "0" + second : second);
        return I18n.format(effect.getPotion().getName()) + " " + amplifier + "\u00A77" + time + "\u00A7r";
    }

    public static class Effect {
        private final EntityLivingBase entity;
        private int maxDuration;
        private PotionEffect potionEffect;

        public Effect(PotionEffect potionEffect, EntityLivingBase entity) {
            this.maxDuration = potionEffect.getDuration();
            this.potionEffect = potionEffect;
            this.entity = entity;
        }

        public int getMaxDuration() {
            return maxDuration;
        }

        public void setMaxDuration(int maxDuration) {
            this.maxDuration = maxDuration;
        }

        public PotionEffect getPotionEffect() {
            return potionEffect;
        }

        public void setPotionEffect(PotionEffect potionEffect) {
            this.potionEffect = potionEffect;
        }

        public EntityLivingBase getEntity() {
            return entity;
        }
    }
}
