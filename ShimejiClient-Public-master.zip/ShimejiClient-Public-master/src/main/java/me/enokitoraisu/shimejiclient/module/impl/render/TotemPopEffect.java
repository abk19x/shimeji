package me.enokitoraisu.shimejiclient.module.impl.render;

import me.enokitoraisu.shimejiclient.event.PacketEvent;
import me.enokitoraisu.shimejiclient.module.Category;
import me.enokitoraisu.shimejiclient.module.Module;
import me.enokitoraisu.shimejiclient.utils.entity.PacketUtil;
import me.enokitoraisu.shimejiclient.utils.interfaces.TimedRenderer;
import me.enokitoraisu.shimejiclient.utils.renderer.timedrenderer.PopEffect;
import me.enokitoraisu.shimejiclient.value.values.BooleanValue;
import me.enokitoraisu.shimejiclient.value.values.ColorValue;
import me.enokitoraisu.shimejiclient.value.values.IntegerValue;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.network.play.server.SPacketEntityStatus;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import org.lwjgl.input.Keyboard;

import java.awt.*;
import java.util.concurrent.CopyOnWriteArrayList;

public class TotemPopEffect extends Module {
    private final IntegerValue fadeoutMs = register(new IntegerValue("FadeoutMillis", 500, 100, 2000));
    private final ColorValue playerColor = register(new ColorValue("PlayerColor", new Color(0xFFFF0000)));
    private final BooleanValue reverse = register(new BooleanValue("Reverse", false));
    private final CopyOnWriteArrayList<PopEffect> popEffects = new CopyOnWriteArrayList<>();

    public TotemPopEffect() {
        super("TotemPopEffect", Category.RENDER, Keyboard.KEY_NONE);
    }

    @SubscribeEvent
    public void onPacketReceived(PacketEvent.Receive event) {
        if (event.getPacket() instanceof SPacketEntityStatus) {
            SPacketEntityStatus entityStatus = (SPacketEntityStatus) event.getPacket();

            if (!fullNullCheck() || entityStatus.getOpCode() != PacketUtil.TOTEM_USE) return;
            mc.addScheduledTask(() -> {
                Entity entity = PacketUtil.getEntityStatusByEntity(entityStatus);
                if (entity instanceof EntityPlayer && entity != mc.player)
                    popEffects.add(new PopEffect((EntityPlayer) entity, fadeoutMs.getValue(), System.currentTimeMillis()));
            });
        }
    }

    @Override
    public void onRender3D() {
        popEffects.removeIf(TimedRenderer::hasExpired);
        popEffects.forEach(popEffect -> popEffect.render(playerColor.getValue(), reverse.getValue()));
    }
}
