package me.enokitoraisu.shimejiclient.module.impl.misc;

import me.enokitoraisu.shimejiclient.event.BlockEvent;
import me.enokitoraisu.shimejiclient.module.Category;
import me.enokitoraisu.shimejiclient.module.Module;
import me.enokitoraisu.shimejiclient.value.values.BooleanValue;
import net.minecraft.network.play.client.CPacketPlayerDigging;
import net.minecraft.util.EnumFacing;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import org.lwjgl.input.Keyboard;

@SuppressWarnings("unused")
public class AntiGhostBlock extends Module {
    public BooleanValue placeValue = register(new BooleanValue("Place", true));
    public BooleanValue breakValue = register(new BooleanValue("Break", true));

    public AntiGhostBlock() {
        super("AntiGhostBlock", Category.MISC, Keyboard.KEY_NONE);
    }

    @SubscribeEvent
    public void onDestroyBlockPost(BlockEvent.Break e) {
        if (breakValue.getValue())
            mc.player.connection.sendPacket(new CPacketPlayerDigging(CPacketPlayerDigging.Action.ABORT_DESTROY_BLOCK, e.getPos(), EnumFacing.UP));
    }

    @SubscribeEvent
    public void onPlaceBlockPost(BlockEvent.Place e) {
        if (placeValue.getValue())
            mc.player.connection.sendPacket(new CPacketPlayerDigging(CPacketPlayerDigging.Action.ABORT_DESTROY_BLOCK, e.getPos(), EnumFacing.UP));
    }
}
