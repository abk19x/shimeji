package me.enokitoraisu.shimejiclient.module.impl.player;

import me.enokitoraisu.shimejiclient.ShimejiClient;
import me.enokitoraisu.shimejiclient.module.Category;
import me.enokitoraisu.shimejiclient.module.Module;
import me.enokitoraisu.shimejiclient.utils.renderer.RenderUtil;
import me.enokitoraisu.shimejiclient.value.values.IntegerValue;
import net.minecraft.client.gui.GuiScreen;
import org.lwjgl.input.Keyboard;

import java.io.IOException;

@SuppressWarnings("unused")
public class PositionLook extends Module {
    public IntegerValue x = register(new IntegerValue("x", 0, Integer.MIN_VALUE, Integer.MAX_VALUE, v -> false));
    public IntegerValue y = register(new IntegerValue("y", 256, 0, 255, v -> false));
    public IntegerValue z = register(new IntegerValue("z", 0, Integer.MIN_VALUE, Integer.MAX_VALUE, v -> false));
    public Integer lastX = null;
    public Integer lastY = null;
    public Integer lastZ = null;

    public PositionLook() {
        super("PositionLook", Category.PLAYER, Keyboard.KEY_NONE);
    }

    @Override
    public void onEnable() {
        if (lastX == null || lastY == null || lastZ == null) {

            mc.displayGuiScreen(new GuiScreen() {
                @Override
                public void drawScreen(int mouseX, int mouseY, float partialTicks) {
                    drawDefaultBackground();
                    mc.fontRenderer.drawStringWithShadow("1. open chat", 5, 5, -1);
                    mc.fontRenderer.drawStringWithShadow("2. type \"" + ShimejiClient.CmdPrefix + "set positionlook (x, y, z) (integer)\" in the chat", 5, 6 + mc.fontRenderer.FONT_HEIGHT, -1);
                    mc.fontRenderer.drawStringWithShadow("3. Press Enter to set the value", 5, 7 + mc.fontRenderer.FONT_HEIGHT * 2, -1);
                    mc.fontRenderer.drawStringWithShadow("4. Toggle PositionLook again", 5, 8 + mc.fontRenderer.FONT_HEIGHT * 3, -1);
                    mc.fontRenderer.drawStringWithShadow("5. The viewpoint will look at the specified coordinates", 5, 9 + mc.fontRenderer.FONT_HEIGHT * 4, -1);

                    RenderUtil.drawRect(width - 105, height - 25, 100, 20, 0x80000000);
                    mc.fontRenderer.drawStringWithShadow("close", (width - 105) + (50 - mc.fontRenderer.getStringWidth("close") / 2f), (height - 25) + (10F - mc.fontRenderer.FONT_HEIGHT / 2f), -1);

                    super.drawScreen(mouseX, mouseY, partialTicks);
                }

                @Override
                public void mouseClicked(int mouseX, int mouseY, int mouseButton) {
                    if (mouseX > width - 105 && mouseY > height - 25 && mouseX < width - 5 && mouseY < height - 5 && mouseButton == 0)
                        mc.displayGuiScreen(null);

                    try {
                        super.mouseClicked(mouseX, mouseY, mouseButton);
                    } catch (IOException ignored) {
                    }
                }
            });
        }
    }

    @Override
    public void onTick() {
    }
}
