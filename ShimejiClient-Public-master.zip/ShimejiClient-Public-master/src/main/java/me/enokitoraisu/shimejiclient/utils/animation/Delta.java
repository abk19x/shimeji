package me.enokitoraisu.shimejiclient.utils.animation;

import org.lwjgl.Sys;

public class Delta {
    public static int DeltaTime;
    private static long lastTime = (Sys.getTime() * 1000) / Sys.getTimerResolution();

    public static void updateDeltaTime() {
        long currentTime = (Sys.getTime() * 1000) / Sys.getTimerResolution();
        int deltaTime = (int) (currentTime - lastTime);
        lastTime = currentTime;
        DeltaTime = deltaTime;
    }
}
