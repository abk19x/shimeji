package me.enokitoraisu.shimejiclient.module.impl.player;

import me.enokitoraisu.shimejiclient.event.KeyInputEvent;
import me.enokitoraisu.shimejiclient.event.PacketEvent;
import me.enokitoraisu.shimejiclient.module.Category;
import me.enokitoraisu.shimejiclient.module.Module;
import me.enokitoraisu.shimejiclient.module.impl.hud.NewNotifications;
import me.enokitoraisu.shimejiclient.utils.renderer.RenderUtil3D;
import me.enokitoraisu.shimejiclient.value.values.BooleanValue;
import me.enokitoraisu.shimejiclient.value.values.ColorValue;
import me.enokitoraisu.shimejiclient.value.values.FloatValue;
import me.enokitoraisu.shimejiclient.value.values.KeyValue;
import net.minecraft.init.Items;
import net.minecraft.network.play.client.CPacketPlayer;
import net.minecraft.network.play.server.SPacketPlayerPosLook;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraftforge.fml.common.eventhandler.Event;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.network.FMLNetworkEvent;
import org.lwjgl.input.Keyboard;

import java.awt.*;
import java.util.Objects;

@SuppressWarnings("unused")
public class ChorusControl extends Module {
    private final KeyValue acceptKey = register(new KeyValue("AcceptKey", Keyboard.KEY_0));
    private final BooleanValue renderOutline = register(new BooleanValue("OutLine", true));
    private final FloatValue outlineWidth = register(new FloatValue("OutLineWidth", 1f, 1f, 10f));
    private final BooleanValue renderBox = register(new BooleanValue("Box", true));
    private final ColorValue currentPosColor = register(new ColorValue("CurrentPos", new Color(0x7FFF0000)));
    private final ColorValue chorusPosColor = register(new ColorValue("ChorusPos", new Color(0x7F00FFFF)));
    private Vec3d chorusPos = null;
    private Vec3d currentPos = null;
    private SPacketPlayerPosLook chorusPacket = null;
    private boolean isEatingChorus = false;
    private int chorusTicks = 0;

    public ChorusControl() {
        super("ChorusControl", Category.PLAYER, Keyboard.KEY_NONE);
    }

    public void reset() {
        chorusPacket = null;
        chorusPos = null;
        currentPos = null;
    }

    @Override
    public void onDisable() {
        if (chorusPacket != null) {
            chorusPacket.processPacket(Objects.requireNonNull(mc.getConnection()));
            reset();
        }
    }

    @Override
    public void onRender3D() {
        if (chorusPos != null) {
            RenderUtil3D.drawBox(new BlockPos(chorusPos.x, chorusPos.y, chorusPos.z), currentPosColor.getValue().getRGB(), currentPosColor.getValue().getRGB(), renderBox.getValue(), renderOutline.getValue(), outlineWidth.getValue());
        }
        if (currentPos != null) {
            RenderUtil3D.drawBox(new BlockPos(currentPos.x, currentPos.y, currentPos.z), chorusPosColor.getValue().getRGB(), chorusPosColor.getValue().getRGB(), renderBox.getValue(), renderOutline.getValue(), outlineWidth.getValue());
        }
    }

    @Override
    public void onUpdate() {
        if (mc.player.getActiveItemStack().getItem() == Items.CHORUS_FRUIT) {
            isEatingChorus = true;
        } else if (isEatingChorus) {
            chorusTicks++;
            if (chorusTicks > 5) {
                isEatingChorus = false;
                chorusTicks = 0;
            }
        }
    }

    @SubscribeEvent
    public void onEvent(Event event) {
        if (event instanceof FMLNetworkEvent.ClientDisconnectionFromServerEvent || event instanceof FMLNetworkEvent.ClientConnectedToServerEvent) {
            reset();
        }

        if (event instanceof KeyInputEvent) {
            KeyInputEvent keyInputEvent = (KeyInputEvent) event;
            if (keyInputEvent.getKey() == acceptKey.getValue() && chorusPacket != null) {
                mc.player.connection.handlePlayerPosLook(chorusPacket);
                //chorusPacket.processPacket(Objects.requireNonNull(mc.getConnection()));
                sendNotify(String.format("%s Teleported!!", this.name), NewNotifications.Type.INFO);
                reset();
            }
        }

        if (event instanceof PacketEvent.Receive) {
            PacketEvent.Receive receive = (PacketEvent.Receive) event;

            if (receive.getPacket() instanceof SPacketPlayerPosLook) {
                if (isEatingChorus || chorusPos != null) {
                    chorusPacket = (SPacketPlayerPosLook) receive.getPacket();
                    chorusPos = new Vec3d(chorusPacket.getX(), chorusPacket.getY(), chorusPacket.getZ());
                    if (currentPos == null) {
                        currentPos = mc.player.getPositionVector();
                    }
                    receive.setCanceled(true);
                }
            }
        }

        if (event instanceof PacketEvent.Send) {
            PacketEvent.Send send = (PacketEvent.Send) event;

            if (chorusPacket != null && send.getPacket() instanceof CPacketPlayer) {
                event.setCanceled(true);
            }
        }
    }
}