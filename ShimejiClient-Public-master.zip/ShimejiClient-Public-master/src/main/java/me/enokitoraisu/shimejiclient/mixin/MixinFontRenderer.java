package me.enokitoraisu.shimejiclient.mixin;

import me.enokitoraisu.shimejiclient.event.TextEvent;
import net.minecraft.client.gui.FontRenderer;
import net.minecraftforge.common.MinecraftForge;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

@Mixin(FontRenderer.class)
public class MixinFontRenderer {
    @ModifyVariable(method = "renderString(Ljava/lang/String;FFIZ)I", at = @At(value = "HEAD"), ordinal = 0, argsOnly = true)
    private String renderString(String string) {
        TextEvent textEvent = new TextEvent(string);
        MinecraftForge.EVENT_BUS.post(textEvent);
        return textEvent.getText();
    }

    @ModifyVariable(method = "getStringWidth(Ljava/lang/String;)I", at = @At(value = "HEAD"), ordinal = 0, argsOnly = true)
    private String getStringWidth(String string) {
        TextEvent textEvent = new TextEvent(string);
        MinecraftForge.EVENT_BUS.post(textEvent);
        return textEvent.getText();
    }
}
