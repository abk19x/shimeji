package me.enokitoraisu.shimejiclient.mixin;

import me.enokitoraisu.shimejiclient.event.FlagGetEvent;
import me.enokitoraisu.shimejiclient.event.TurnEvent;
import net.minecraft.entity.Entity;
import net.minecraft.network.datasync.DataParameter;
import net.minecraft.network.datasync.EntityDataManager;
import net.minecraftforge.common.MinecraftForge;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(Entity.class)
public class MixinEntity {
    @Shadow protected EntityDataManager dataManager;
    @Shadow @Final protected static DataParameter<Byte> FLAGS;

    @Inject(method = "turn(FF)V", at = @At(value = "HEAD"), cancellable = true)
    public void turn(float yaw, float pitch, CallbackInfo ci) {
        TurnEvent turnEvent = new TurnEvent(yaw, pitch);
        MinecraftForge.EVENT_BUS.post(turnEvent);
        if (turnEvent.isCanceled()) {
            ci.cancel();
        }
    }

    @Inject(method = "getFlag", at = @At(value = "HEAD"), cancellable = true)
    public void getFlag(int flag, CallbackInfoReturnable<Boolean> cir) {
        FlagGetEvent flagGetEvent = new FlagGetEvent(Entity.class.cast(this), flag, (this.dataManager.get(FLAGS) & 1 << flag) != 0);
        MinecraftForge.EVENT_BUS.post(flagGetEvent);
        cir.setReturnValue(flagGetEvent.getReturnValue());
    }
}
