package me.enokitoraisu.shimejiclient.gui.shimeji.componet.componets;


import me.enokitoraisu.shimejiclient.gui.GuiSetting;
import me.enokitoraisu.shimejiclient.gui.shimeji.componet.Component;
import me.enokitoraisu.shimejiclient.utils.math.MathUtil;
import me.enokitoraisu.shimejiclient.utils.renderer.RenderUtil;
import me.enokitoraisu.shimejiclient.utils.renderer.font.FontUtil;
import me.enokitoraisu.shimejiclient.value.values.FloatValue;

public class FloatButton extends Component {
    private final FloatValue floatValue;
    private final int places;
    private float value;
    private boolean changing;

    public FloatButton(FloatValue floatValue, int x, int width, int height) {
        this.floatValue = floatValue;
        this.x = x;
        this.width = width;
        this.height = height;
        this.changing = false;
        this.places = MathUtil.decimalPlaces(floatValue.getStep());
        this.value = (this.floatValue.getValue() - this.floatValue.getMin()) / (this.floatValue.getMax() - this.floatValue.getMin());
    }

    @Override
    public void drawScreen(int mouseX, int mouseY, int offsetY) {
        this.visible = this.floatValue.getVisibility();
        if (this.visible) {
            this.y = offsetY;
            RenderUtil.drawRect(this.x, offsetY, this.width, this.height, 0xCB191919);

            if (bounding(mouseX, mouseY))
                RenderUtil.drawRect(x, offsetY, width, height, 0x40000000);

            RenderUtil.drawDoubleRectWH(x + 1.5f, offsetY + 1.5f, width - 3, height - 3, 0x80191919);
            float renderValue = (floatValue.getValue() - floatValue.getMin()) / (floatValue.getMax() - floatValue.getMin());
            RenderUtil.drawRect(this.x + 2, offsetY + 2, (this.width - 4) * renderValue, height - 4, GuiSetting.getAccent());
            FontUtil.sfui18.drawStringWithShadow(String.format("%s : %s", floatValue.getName(), floatValue.getValue()), x + 5, offsetY + (height / 2f - FontUtil.sfui18.getHeight() / 2f), -1);

            if (this.x - 10 < mouseX && this.x + this.width + 10 > mouseX && this.changing) {
                this.value = (mouseX - (this.x + 2f)) / (this.width - 4);
                if (this.value > 1.0f) this.value = 1.0f;
                if (this.value < 0.0f) this.value = 0.0f;
                float rounded = (float) MathUtil.round(Math.round((this.value * (this.floatValue.getMax() - this.floatValue.getMin()) + this.floatValue.getMin()) / this.floatValue.getStep()) * this.floatValue.getStep(), places);
                this.floatValue.setValue(rounded);
            }
        }
    }

    @Override
    public void mouseClicked(int mouseX, int mouseY, int mouseButton) {
        if (this.visible && this.bounding(mouseX, mouseY) && mouseButton == 0) this.changing = true;
    }

    @Override
    public void mouseReleased(int mouseX, int mouseY, int state) {
        this.changing = false;
    }
}

