package me.enokitoraisu.shimejiclient.module.impl.hud;

import me.enokitoraisu.shimejiclient.ShimejiClient;
import me.enokitoraisu.shimejiclient.module.Category;
import me.enokitoraisu.shimejiclient.module.Module;
import me.enokitoraisu.shimejiclient.module.impl.misc.ShimejiName;
import me.enokitoraisu.shimejiclient.utils.animation.Easing;
import me.enokitoraisu.shimejiclient.utils.game.DisplayUtil;
import me.enokitoraisu.shimejiclient.utils.math.ColorUtil;
import me.enokitoraisu.shimejiclient.utils.renderer.RenderUtil;
import me.enokitoraisu.shimejiclient.utils.renderer.font.FontUtil;
import me.enokitoraisu.shimejiclient.value.ValueBase;
import me.enokitoraisu.shimejiclient.value.values.*;
import net.minecraft.client.gui.GuiScreen;
import org.lwjgl.input.Keyboard;

import java.awt.*;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

@SuppressWarnings("unused")
public class MArrayList extends Module {
    public ModeValue style = register(new ModeValue("Style", "Shimeji", "Shimeji", "Minecraft"));

    public IntegerValue easingspeed = register(new IntegerValue("EasingSpeed", 300, 100, 1000, this::isMinecraft));

    public ModeValue rainbow = register(new ModeValue("Rainbow", "Hue", "Hue", "Brightness", "None"));
    public IntegerValue opacity = register(new IntegerValue("Opacity", 75, 0, 255, this::isShimeji));
    public BooleanValue line = register(new BooleanValue("Line", true, this::isShimeji));
    public ModeValue lineMode = register(new ModeValue("LineMode", "LEFT", v -> line.getValue() && this.isShimeji(), "LEFT", "RIGHT", "BOTH"));

    public ColorValue color = register(new ColorValue("Color", new Color(179, 220, 239, 255), v -> rainbow.getValue().equals("None")));

    public IntegerValue h = register(new IntegerValue("Hue", 0, 0, 100, v -> rainbow.getValue().equals("Brightness")));
    public FloatValue s = register(new FloatValue("Saturation", 0.5f, 0.1f, 1.0f, v -> rainbow.getValue().equals("Hue") || rainbow.getValue().equals("Brightness")));
    public FloatValue b = register(new FloatValue("Brightness", 1.0f, 0.1f, 1.0f, v -> rainbow.getValue().equals("Hue")));
    public FloatValue speed = register(new FloatValue("Speed", 5.0f, 0.1f, 10.0f, v -> rainbow.getValue().equals("Hue") || rainbow.getValue().equals("Brightness")));

    public MArrayList() {
        super("ArrayList", Category.HUD, Keyboard.KEY_NONE);
    }

    public boolean isMinecraft(Object o) {
        return style.getValue().equals("Minecraft");
    }

    public boolean isMinecraft() {
        return style.getValue().equals("Minecraft");
    }

    public boolean isShimeji(Object o) {
        return style.getValue().equals("Shimeji");
    }

    public boolean isShimeji() {
        return style.getValue().equals("Shimeji");
    }

    @Override
    public void onRender2D() {
        int y = 0;

        if (isShimeji()) {
            List<Module> modules = ShimejiClient.moduleManager.getModuleList().stream().sorted(Comparator.comparingDouble(Module::ArrayLength).thenComparing(Module::getName)).collect(Collectors.toList());
            Collections.reverse(modules);

            for (Module m : modules) {
                if (m.drawn && m.toggled) {
                    String text = m.name + (!Objects.equals(m.tags, "") ? " \u00A77[\u00A7f" + m.tags + "\u00A77]\u00A7r" : "");
                    int color = rainbow.getValue().equals("Hue") ? ColorUtil.getRainbow(speed.getValue() + 1, s.getValue(), b.getValue(), (5L * y) * 2) : rainbow.getValue().equals("Brightness") ? ColorUtil.getBrightness(h.getValue() / 100F, s.getValue(), 0.2F, 1.0F, speed.getValue() + 1, (5L * y) * 2) : ColorUtil.toRGBA(this.color.getValue());
                    int width = (int) (DisplayUtil.getScaledResolution().getScaledWidth() - FontUtil.sfui20.getStringWidth(text));

                    GuiScreen.drawRect(width - 5, y - 1, DisplayUtil.getScaledResolution().getScaledWidth(), y + FontUtil.sfui20.getHeight() + 3, ColorUtil.toRGBA(0, 0, 0, opacity.getValue()));

                    if (line.getValue() && (lineMode.getValue().equals("RIGHT") || lineMode.getValue().equals("BOTH")))
                        RenderUtil.drawDoubleRect(DisplayUtil.getScaledResolution().getScaledWidth() - 1, y - 1, DisplayUtil.getScaledResolution().getScaledWidth(), y + FontUtil.sfui20.getHeight() + 3, color);
                    if (line.getValue() && (lineMode.getValue().equals("LEFT") || lineMode.getValue().equals("BOTH")))
                        RenderUtil.drawDoubleRect(width - 5, y - 1, width - 6, y + FontUtil.sfui20.getHeight() + 3, color);

                    FontUtil.sfui20.drawStringWithShadow(text, width - 2.5, y + 1.5, color);

                    y += FontUtil.sfui20.getHeight() + 4;
                }
            }
        } else if (isMinecraft()) {
            List<Module> modules = ShimejiClient.moduleManager.getModuleList().stream().sorted(Comparator.comparingDouble(this::getLength).thenComparing(Module::getName)).collect(Collectors.toList());
            Collections.reverse(modules);
            int mY = 1;
            for (Module module : modules) {
                module.slide.setEase(module.slide.isReversed() ? Easing.SINE_IN : Easing.SINE_OUT).setMin(0).setMax(100).setSpeed(easingspeed.getValue()).setReversed(!(module.toggled && module.drawn)).update();

                int color = rainbow.getValue().equals("Hue") ? ColorUtil.getRainbow(speed.getValue() + 1, s.getValue(), b.getValue(), (5L * mY) * 2) : rainbow.getValue().equals("Brightness") ? ColorUtil.getBrightness(h.getValue() / 100F, s.getValue(), 0.2F, 1.0F, speed.getValue(), (5L * mY) * 2) : ColorUtil.toRGBA(this.color.getValue());

                if ((module.toggled && module.drawn) || module.slide.getValue() > 0) {
                    mc.fontRenderer.drawStringWithShadow(getDisplayText(module), DisplayUtil.getWidth() - ((getLength(module) + 1) * (module.slide.getValue() / 100)), mY, color);

                    mY += mc.fontRenderer.FONT_HEIGHT + 1;
                }
            }
        }
    }

    private int getLength(Module m) {
        if (m instanceof SpotifyStatus || m instanceof ShimejiName)
            return mc.fontRenderer.getStringWidth(m.getName());

        for (ValueBase<?> value : m.settings) {
            if (value instanceof ModeValue) {
                ModeValue modeValue = (ModeValue) value;
                if (!value.getName().toLowerCase().contains("page"))
                    return mc.fontRenderer.getStringWidth(String.format("%s \u00A77[\u00A7f%s\u00A77]\u00A7r", m.getName(), modeValue.getValue()));
            } else if (value instanceof StringValue) {
                StringValue stringValue = (StringValue) value;
                return mc.fontRenderer.getStringWidth(String.format("%s \u00A77[\u00A7f%s\u00A77]\u00A7r", m.getName(), stringValue.getValue()));
            }
        }
        return mc.fontRenderer.getStringWidth(m.getName());
    }

    private String getDisplayText(Module m) {
        if (m instanceof SpotifyStatus || m instanceof ShimejiName) return m.getName();

        for (ValueBase<?> value : m.settings) {
            if (value instanceof ModeValue) {
                ModeValue modeValue = (ModeValue) value;
                if (!value.getName().toLowerCase().contains("page"))
                    return String.format("%s \u00A77[\u00A7f%s\u00A77]\u00A7r", m.getName(), modeValue.getValue());
            } else if (value instanceof StringValue) {
                StringValue stringValue = (StringValue) value;
                return String.format("%s \u00A77[\u00A7f%s\u00A77]\u00A7r", m.getName(), stringValue.getValue());
            }
        }
        return m.getName();
    }
}
