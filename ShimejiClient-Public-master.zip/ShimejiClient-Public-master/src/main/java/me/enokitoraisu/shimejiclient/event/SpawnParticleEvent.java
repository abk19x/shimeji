package me.enokitoraisu.shimejiclient.event;

import net.minecraft.util.EnumParticleTypes;
import net.minecraft.util.math.Vec3d;

public class SpawnParticleEvent extends EventManager {
    private final EnumParticleTypes particleType;
    private final Vec3d vec3d;
    private final double xSpeed;
    private final double ySpeed;
    private final double zSpeed;
    private final int[] parameters;

    public SpawnParticleEvent(EnumParticleTypes particleType, Vec3d vec3d, double xSpeed, double ySpeed, double zSpeed, int[] parameters) {
        this.particleType = particleType;
        this.vec3d = vec3d;
        this.xSpeed = xSpeed;
        this.ySpeed = ySpeed;
        this.zSpeed = zSpeed;
        this.parameters = parameters;
    }

    public EnumParticleTypes getParticleType() {
        return particleType;
    }

    public Vec3d getVec3d() {
        return vec3d;
    }

    public double getXSpeed() {
        return xSpeed;
    }

    public double getYSpeed() {
        return ySpeed;
    }

    public double getZSpeed() {
        return zSpeed;
    }

    public int[] getParameters() {
        return parameters;
    }
}
