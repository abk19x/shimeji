package me.enokitoraisu.shimejiclient.module.impl.movement;

import me.enokitoraisu.shimejiclient.module.Category;
import me.enokitoraisu.shimejiclient.module.Module;
import org.lwjgl.input.Keyboard;

@SuppressWarnings("unused")
public class AirJump extends Module {
    public AirJump() {
        super("AirJump", Category.MOVEMENT, Keyboard.KEY_NONE);
    }

    public void onTick() {
        if (mc.gameSettings.keyBindJump.isPressed()) {
            mc.player.jump();
        }
    }
}
