package me.enokitoraisu.shimejiclient.module.impl.player;

import me.enokitoraisu.shimejiclient.event.PacketEvent;
import me.enokitoraisu.shimejiclient.module.Category;
import me.enokitoraisu.shimejiclient.module.Module;
import me.enokitoraisu.shimejiclient.module.impl.hud.NewNotifications;
import me.enokitoraisu.shimejiclient.value.values.BooleanValue;
import me.enokitoraisu.shimejiclient.value.values.StringValue;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.network.play.client.CPacketChatMessage;
import net.minecraft.network.play.server.SPacketSpawnPlayer;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import org.lwjgl.input.Keyboard;

public class Announcer extends Module {
    private final BooleanValue spawn = register(new BooleanValue("SpawnPlayer", false));
    private final BooleanValue send = register(new BooleanValue("SendMessage", false, v -> spawn.getValue()));
    private final StringValue message = register(new StringValue("Message", "/tell %s uwu", v -> spawn.getValue()));

    public Announcer() {
        super("Announcer", Category.PLAYER, Keyboard.KEY_NONE);
    }

    @SubscribeEvent
    public void onPacketReceived(PacketEvent.Receive event) {
        if (event.getPacket() instanceof SPacketSpawnPlayer && spawn.getValue()) {
            SPacketSpawnPlayer packet = (SPacketSpawnPlayer) event.getPacket();
            if (mc.world.getEntityByID(packet.getEntityID()) == null) return;
            Entity entity = mc.world.getEntityByID(packet.getEntityID());

            if (entity instanceof EntityPlayer) {
                NewNotifications.INSTANCE.add(String.format("%s has Spawned", entity.getName()), NewNotifications.Type.INFO);
                if (send.getValue())
                    mc.player.connection.sendPacket(new CPacketChatMessage(message.getValue().replaceFirst("%s", entity.getName())));
            }
        }
    }
}
