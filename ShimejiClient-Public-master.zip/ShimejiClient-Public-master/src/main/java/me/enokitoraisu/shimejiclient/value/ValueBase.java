package me.enokitoraisu.shimejiclient.value;

import java.util.function.Predicate;

public class ValueBase<T> {
    private final String name;
    private final Predicate<T> visibility;
    protected T value;

    public ValueBase(String name, T value, Predicate<T> visibility) {
        this.name = name;
        this.value = value;
        this.visibility = visibility;
    }

    public T getValue() {
        return value;
    }

    public void setValue(T value) {
        this.value = value;
    }

    public String getName() {
        return name;
    }

    public boolean getVisibility() {
        if (this.visibility == null) {
            return true;
        }
        return this.visibility.test(this.getValue());
    }
}
