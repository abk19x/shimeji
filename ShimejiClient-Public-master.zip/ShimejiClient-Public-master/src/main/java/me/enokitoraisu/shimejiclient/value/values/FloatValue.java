package me.enokitoraisu.shimejiclient.value.values;

import me.enokitoraisu.shimejiclient.value.ValueBase;
import net.minecraft.util.math.MathHelper;

import java.util.function.Predicate;

public class FloatValue extends ValueBase<Float> {
    private final float step;
    private float min;
    private float max;

    public FloatValue(String name, float value, float min, float max, float step, Predicate<Float> visibility) {
        super(name, value, visibility);
        this.min = min;
        this.max = max;
        this.step = step;
    }

    public FloatValue(String name, float value, float min, float max, float step) {
        this(name, value, min, max, step, v -> true);
    }

    public FloatValue(String name, float value, float min, float max) {
        this(name, value, min, max, 0.1F, v -> true);
    }

    public FloatValue(String name, float value, float min, float max, Predicate<Float> visibility) {
        this(name, value, min, max, 0.1F, visibility);
    }

    @Override
    public void setValue(Float value) {
        this.value = MathHelper.clamp(value, min, max);
    }

    public float getMin() {
        return min;
    }

    public void setMin(float min) {
        this.min = min;
    }

    public float getMax() {
        return max;
    }

    public void setMax(float max) {
        this.max = max;
    }

    public float getStep() {
        return step;
    }
}
