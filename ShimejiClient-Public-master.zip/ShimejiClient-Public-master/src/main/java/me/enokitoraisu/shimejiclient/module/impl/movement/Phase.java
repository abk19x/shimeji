package me.enokitoraisu.shimejiclient.module.impl.movement;

import me.enokitoraisu.shimejiclient.event.MoveEvent;
import me.enokitoraisu.shimejiclient.event.PacketEvent;
import me.enokitoraisu.shimejiclient.module.Category;
import me.enokitoraisu.shimejiclient.module.Module;
import me.enokitoraisu.shimejiclient.utils.entity.EntityUtil;
import me.enokitoraisu.shimejiclient.value.values.BooleanValue;
import me.enokitoraisu.shimejiclient.value.values.FloatValue;
import me.enokitoraisu.shimejiclient.value.values.IntegerValue;
import me.enokitoraisu.shimejiclient.value.values.ModeValue;
import net.minecraft.entity.MoverType;
import net.minecraft.network.play.client.CPacketPlayer;
import net.minecraft.network.play.server.SPacketPlayerPosLook;
import net.minecraft.util.text.TextComponentString;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import org.lwjgl.input.Keyboard;

@SuppressWarnings("unused")
public class Phase extends Module {
    public ModeValue mode = register(new ModeValue("Mode", "Clip", "Clip", "Sand"));
    public IntegerValue skipTick = register(new IntegerValue("SkipTicks", 1, 1, 10, v -> mode.getValue().equals("Clip")));
    public BooleanValue debug = register(new BooleanValue("Debug", false));
    public FloatValue offset = register(new FloatValue("Offset", 0.1F, 0.01F, 0.1F, 0.01F, v -> mode.getValue().equals("Sand")));
    private int ticks = 0;

    public Phase() {
        super("Phase", Category.MOVEMENT, Keyboard.KEY_NONE);
    }

    @Override
    public void onTick() {
        switch (mode.getValue()) {
            case "Clip":
                float yaw = mc.player.rotationYaw;
                float pitch = mc.player.rotationPitch;

                if (ticks == 0) {
                    setPosition(mc.player.posX, mc.player.posY - 0.01, mc.player.posZ, mc.player.onGround);
                    ticks++;
                } else if (ticks >= skipTick.getValue()) {
                    mc.player.connection.sendPacket(new CPacketPlayer.Rotation(0, 0, mc.player.onGround));
                    mc.player.connection.sendPacket(new CPacketPlayer.Rotation(yaw, pitch, mc.player.onGround));
                } else {
                    ticks++;
                }
                break;
            case "Sand":
                if (EntityUtil.isPlayerMoving()) {
                    float yaw1 = mc.player.rotationYaw;
                    float forward = mc.player.movementInput.moveForward, strafe = mc.player.movementInput.moveStrafe;
                    mc.player.motionX = 0;
                    mc.player.motionZ = 0;

                    double dx = -Math.sin(Math.toRadians(yaw1)) * forward + Math.cos(Math.toRadians(yaw1)) * strafe;
                    double dz = Math.cos(Math.toRadians(yaw1)) * forward + Math.sin(Math.toRadians(yaw1)) * strafe;
                    double mag = Math.sqrt(dx * dx + dz * dz);
                    dx = dx / mag * offset.getValue();
                    dz = dz / mag * offset.getValue();
                    setPosition(mc.player.posX + dx, mc.player.posY, mc.player.posZ + dz, mc.player.onGround);
                }
                break;
        }
    }

    @Override
    public void onDisable() {
        ticks = 0;
    }

    @SubscribeEvent
    public void onPacketReceived(PacketEvent.Receive event) {
        if (mode.getValue().equals("Clip") && ticks >= skipTick.getValue()) {
            if (event.getPacket() instanceof SPacketPlayerPosLook) {
                SPacketPlayerPosLook packet = (SPacketPlayerPosLook) event.getPacket();
                if (packet.getX() % 1.0 == 0 && packet.getZ() % 1.0 == 0) {
                    toggle();
                    if (debug.getValue())
                        mc.player.sendMessage(new TextComponentString("True"));
                } else {
                    if (debug.getValue())
                        mc.player.sendMessage(new TextComponentString("False " + (packet.getX() % 1.0) + " " + (packet.getZ() % 1.0)));
                }
            }
        }
    }

    @SubscribeEvent
    public void onMove(MoveEvent event) {
        if (mode.getValue().equals("Sand") && event.getType() == MoverType.SELF && EntityUtil.isPlayerMoving()) {
            event.setCanceled(true);
        }
    }

    public void setPosition(double x, double y, double z, boolean onGround) {
        mc.player.setPosition(x, y, z);
        mc.player.connection.sendPacket(new CPacketPlayer.PositionRotation(x, y, z, mc.player.rotationYaw, mc.player.rotationPitch, onGround));
    }

    /*
    public float[] getRotation(BlockPos pos, Vec3d vec) {
        double diffX = pos.getX() + vec.x - mc.player.posX;
        double diffY = pos.getY() + vec.y - (mc.player.posY + mc.player.getEyeHeight());
        double diffZ = pos.getZ() + vec.z - mc.player.posZ;
        double dist = Math.sqrt(diffX * diffX + diffZ * diffZ);
        float yaw = (float) (Math.atan2(diffZ, diffX) * 180.0 / Math.PI) - 90.0f;
        float pitch = (float) -(Math.atan2(diffY, dist) * 180.0 / Math.PI);
        return new float[]{yaw, pitch};
    }
     */
}
