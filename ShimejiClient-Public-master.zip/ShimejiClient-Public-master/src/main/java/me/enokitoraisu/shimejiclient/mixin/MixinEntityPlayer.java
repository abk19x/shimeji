package me.enokitoraisu.shimejiclient.mixin;

import me.enokitoraisu.shimejiclient.event.JumpEvent;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraftforge.common.MinecraftForge;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(EntityPlayer.class)
public class MixinEntityPlayer {
    @Inject(method = "jump()V", at = @At(value = "HEAD"), cancellable = true)
    public void jump(CallbackInfo ci) {
        JumpEvent jumpEvent = new JumpEvent();
        MinecraftForge.EVENT_BUS.post(jumpEvent);
        if (jumpEvent.isCanceled()) {
            ci.cancel();
        }
    }
}
