package me.enokitoraisu.shimejiclient.utils.game.nbs;

import net.minecraft.init.SoundEvents;
import net.minecraft.util.SoundEvent;

public enum Instrument {
    HARP(0),
    BASS(1),
    DRUM(2),
    SNARE(3),
    CLICK(4),
    GUITAR(5),
    FLUTE(6),
    BELL(7),
    CHIME(8),
    XYLOPHONE(9);

    private final int ID;

    Instrument(int ID) {
        this.ID = ID;
    }

    /**
     * Determines the instrument from its NBS file ID.
     *
     * @param ID The instrument ID (0-9).
     * @return The corresponding instrument.
     */
    public static Instrument fromID(int ID) throws IllegalArgumentException {
        switch (ID) {
            case 0:
                return HARP;
            case 1:
                return BASS;
            case 2:
                return DRUM;
            case 3:
                return SNARE;
            case 4:
                return CLICK;
            case 5:
                return GUITAR;
            case 6:
                return FLUTE;
            case 7:
                return BELL;
            case 8:
                return CHIME;
            case 9:
                return XYLOPHONE;
            default:
                return null;
        }
    }

    public static SoundEvent getSound(int ID) throws IllegalArgumentException {
        switch (ID) {
            case 0:
                return SoundEvents.BLOCK_NOTE_HARP;
            case 1:
                return SoundEvents.BLOCK_NOTE_BASS;
            case 2:
                return SoundEvents.BLOCK_NOTE_BASEDRUM;
            case 3:
                return SoundEvents.BLOCK_NOTE_SNARE;
            case 4:
                return SoundEvents.BLOCK_NOTE_HAT;
            case 5:
                return SoundEvents.BLOCK_NOTE_GUITAR;
            case 6:
                return SoundEvents.BLOCK_NOTE_FLUTE;
            case 7:
                return SoundEvents.BLOCK_NOTE_BELL;
            case 8:
                return SoundEvents.BLOCK_NOTE_CHIME;
            case 9:
                return SoundEvents.BLOCK_NOTE_XYLOPHONE;
            default:
                return null;
        }
    }

    /**
     * Returns an ID of the instrument to be written in NBS files.
     *
     * @return The ID.
     */
    public int getID() {
        return ID;
    }
}