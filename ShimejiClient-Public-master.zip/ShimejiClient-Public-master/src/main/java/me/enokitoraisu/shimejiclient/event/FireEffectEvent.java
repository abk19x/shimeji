package me.enokitoraisu.shimejiclient.event;

public class FireEffectEvent extends EventManager {
}
