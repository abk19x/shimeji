package me.enokitoraisu.shimejiclient.utils.other;

import java.util.List;

public class ArrayUtil {
    public static String toString(List<String> list) {
        if (list == null || list.isEmpty())
            return "";
        StringBuilder text = new StringBuilder();
        for (int i = 0; i < list.size(); i++) {
            text.append(list.get(i));
            if (i != list.size() - 1)
                text.append(", ");
        }
        return text.toString();
    }

    public static String toString(String[] list) {
        if (list == null || list.length == 0)
            return "";
        StringBuilder text = new StringBuilder();
        for (int i = 0; i < list.length; i++) {
            text.append(list[i]);
            if (i != list.length - 1)
                text.append(", ");
        }
        return text.toString();
    }
}
