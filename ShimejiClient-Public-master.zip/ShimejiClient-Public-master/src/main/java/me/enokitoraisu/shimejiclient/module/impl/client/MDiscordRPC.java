package me.enokitoraisu.shimejiclient.module.impl.client;

import me.enokitoraisu.shimejiclient.ShimejiRPC;
import me.enokitoraisu.shimejiclient.module.Category;
import me.enokitoraisu.shimejiclient.module.Module;
import org.lwjgl.input.Keyboard;

@SuppressWarnings("unused")
public class MDiscordRPC extends Module {
    public MDiscordRPC() {
        super("DiscordRPC", Category.CLIENT, Keyboard.KEY_NONE);
    }

    public void onEnable() {
        try {
            ShimejiRPC.start("968889449717071932");
        } catch (NoClassDefFoundError e) {
            e.printStackTrace();
        }
    }

    public void onDisable() {
        try {
            ShimejiRPC.stop();
        } catch (NoClassDefFoundError e) {
            e.printStackTrace();
        }
    }
}
