package me.enokitoraisu.shimejiclient.utils.other;

import java.nio.charset.Charset;
import java.util.Base64;

public class Base64Util {
    public static String getEncode(String string) {
        return Base64.getEncoder().encodeToString(string.getBytes());
    }

    public static String getDecode(String string) {
        return new String(Base64.getDecoder().decode(string));
    }

    public static String getEncode(String string, Charset charset) {
        return Base64.getEncoder().encodeToString(string.getBytes(charset));
    }

    public static String getDecode(String string, Charset charset) {
        return new String(Base64.getDecoder().decode(string), charset);
    }
}
