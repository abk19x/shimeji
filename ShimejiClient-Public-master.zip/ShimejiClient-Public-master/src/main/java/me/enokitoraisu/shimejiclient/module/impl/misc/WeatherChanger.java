package me.enokitoraisu.shimejiclient.module.impl.misc;

import me.enokitoraisu.shimejiclient.event.PacketEvent;
import me.enokitoraisu.shimejiclient.module.Category;
import me.enokitoraisu.shimejiclient.module.Module;
import me.enokitoraisu.shimejiclient.value.values.ModeValue;
import net.minecraft.network.play.server.SPacketChangeGameState;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import org.lwjgl.input.Keyboard;

@SuppressWarnings("unused")
public class WeatherChanger extends Module {
    public ModeValue Type = register(new ModeValue("Type", "Clear", "Clear", "Rain", "Thunder"));
    private float lastRainStrength = 0.0F;

    public WeatherChanger() {
        super("WeatherChanger", "Change client side weather.", Category.MISC, Keyboard.KEY_NONE);
    }

    @Override
    public void onEnable() {
        if (fullNullCheck())
            this.lastRainStrength = mc.world.rainingStrength;
    }

    @Override
    public void onUpdate() {
        if (fullNullCheck()) {
            switch ((Type.getValue())) {
                case "Clear":
                    mc.world.setRainStrength(0);
                    mc.world.setThunderStrength(0);
                    break;
                case "Rain":
                    mc.world.setThunderStrength(0);
                    mc.world.setRainStrength(1);
                    break;
                case "Thunder":
                    mc.world.setRainStrength(1);
                    mc.world.setThunderStrength(1);
                    break;
                default:
                    throw new IllegalStateException("Unexpected value: " + (Type.getValue()));
            }
        }
    }

    @Override
    public void onDisable() {
        mc.world.setRainStrength(this.lastRainStrength);
    }

    @SubscribeEvent
    public void onPacketReceived(PacketEvent.Receive event) {
        if (event.getPacket() instanceof SPacketChangeGameState) {
            SPacketChangeGameState packet = (SPacketChangeGameState) event.getPacket();
            switch (packet.getGameState()) {
                case 1:
                    this.lastRainStrength = 0.0F;
                    break;
                case 2:
                    this.lastRainStrength = 1.0F;
                    break;
            }
        }
    }
}