package me.enokitoraisu.shimejiclient.command.impl;

import me.enokitoraisu.shimejiclient.command.Command;
import me.enokitoraisu.shimejiclient.module.impl.misc.ChatIgnore;

@SuppressWarnings("unused")
public class Ignore extends Command {
    public Ignore() {
        super("Ignore", "Add a player to mute the chat from the client side.");
    }

    @Override
    public void onCommand() {
        try {
            String arg = arg(1);
            if ("add".equals(arg)) {
                String username = arg(2);
                for (String ignore : ChatIgnore.INSTANCE.ignore_user) {
                    if (username.equals(ignore)) {
                        sendMessage(String.format("%s has already been added to mute", username));
                        return;
                    }
                }
                ChatIgnore.INSTANCE.ignore_user.add(username);
                sendMessage(String.format("Added player to mute %s", username));
            } else if ("del".equals(arg)) {
                String username = arg(2);
                boolean already = false;
                for (String ignore : ChatIgnore.INSTANCE.ignore_user) {
                    if (username.equals(ignore)) {
                        already = true;
                        break;
                    }
                }
                if (already) {
                    ChatIgnore.INSTANCE.ignore_user.remove(username);
                    sendMessage(String.format("Removed player to mute %s", username));
                } else {
                    sendMessage(String.format("%s has not been added to mute", username));
                }
            } else if ("list".equals(arg)) {
                sendMessage("IgnoreList");
                ChatIgnore.INSTANCE.ignore_user.forEach(Command::sendMessage);
            }
        } catch (Exception e) {
            sendMessage("Usage: >Ignore <add : remove> <PlayerName>, >Ignore list");
        }
    }
}
