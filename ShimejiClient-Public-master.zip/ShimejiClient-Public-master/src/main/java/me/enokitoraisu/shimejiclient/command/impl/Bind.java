package me.enokitoraisu.shimejiclient.command.impl;

import com.mojang.realmsclient.gui.ChatFormatting;
import me.enokitoraisu.shimejiclient.ShimejiClient;
import me.enokitoraisu.shimejiclient.command.Command;
import me.enokitoraisu.shimejiclient.module.Module;
import org.lwjgl.input.Keyboard;

public class Bind extends Command {
    public Bind() {
        super("Bind", "Attach bind to modules.");
    }

    @Override
    public void onCommand() {
        try {
            for (Module m : ShimejiClient.moduleManager.modules) {
                if (m.name.equalsIgnoreCase(arg(1))) {
                    m.keyboard = Keyboard.getKeyIndex(arg(2).toUpperCase());
                    sendMessage(ChatFormatting.GREEN + m.name + " Bind to " + Keyboard.getKeyName(m.keyboard));
                    return;
                }
            }
            sendMessage("No Module Name");
        } catch (Exception ex) {
            sendMessage("Usage >Bind <Module> <Key>");
        }
    }
}
