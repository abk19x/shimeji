package me.enokitoraisu.shimejiclient.module.impl.client;

import me.enokitoraisu.shimejiclient.gui.mainmenu.MainMenu;
import me.enokitoraisu.shimejiclient.gui.mainmenu.NewMainMenu;
import me.enokitoraisu.shimejiclient.module.Category;
import me.enokitoraisu.shimejiclient.module.Module;
import me.enokitoraisu.shimejiclient.value.values.BooleanValue;
import me.enokitoraisu.shimejiclient.value.values.ModeValue;
import net.minecraft.client.gui.GuiMainMenu;
import net.minecraftforge.client.event.GuiOpenEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import org.lwjgl.input.Keyboard;

@SuppressWarnings("unused")
public class MMainMenu extends Module {
    public static MMainMenu INSTANCE = new MMainMenu();
    public ModeValue styleSetting = register(new ModeValue("Style", "Minecraft", "Minecraft", "Apple"));
    public BooleanValue lightModeSetting = register(new BooleanValue("LightMode", false));

    public MMainMenu() {
        super("MainMenu", Category.CLIENT, Keyboard.KEY_NONE);
        INSTANCE = this;
    }

    @SubscribeEvent
    public void onRenderMainMenu(GuiOpenEvent event) {
        if (event.getGui() instanceof GuiMainMenu) {
            switch (styleSetting.getValue()) {
                case "Apple":
                    event.setGui(new NewMainMenu());
                    break;
                case "Minecraft":
                    event.setGui(new MainMenu());
                    break;
            }
        }
    }
}
