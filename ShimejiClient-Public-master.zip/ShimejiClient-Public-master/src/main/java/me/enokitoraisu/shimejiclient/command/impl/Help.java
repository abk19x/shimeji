package me.enokitoraisu.shimejiclient.command.impl;

import me.enokitoraisu.shimejiclient.ShimejiClient;
import me.enokitoraisu.shimejiclient.command.Command;

@SuppressWarnings("unused")
public class Help extends Command {
    public Help() {
        super("Help", "This command.");
    }

    @Override
    public void onCommand() {
        try {
            sendMessage("Command list: ");
            for (Command c : ShimejiClient.commandManager.commands) {
                sendMessage(String.format("%s: %s", c.name, c.description));
            }
        } catch (Exception ex) {
            sendMessage("Error");
        }
    }
}
