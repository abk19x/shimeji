package me.enokitoraisu.shimejiclient.module.impl.misc;

import me.enokitoraisu.shimejiclient.module.Category;
import me.enokitoraisu.shimejiclient.module.Module;
import me.enokitoraisu.shimejiclient.module.impl.hud.NewNotifications;
import me.enokitoraisu.shimejiclient.utils.math.ColorConverter;
import me.enokitoraisu.shimejiclient.utils.math.ColorUtil;
import me.enokitoraisu.shimejiclient.utils.math.TimerUtil;
import me.enokitoraisu.shimejiclient.utils.other.Queue;
import me.enokitoraisu.shimejiclient.utils.renderer.RenderUtil3D;
import me.enokitoraisu.shimejiclient.value.values.IntegerValue;
import net.minecraft.block.*;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.network.play.client.CPacketPlayerDigging;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import org.lwjgl.input.Keyboard;

import java.util.ArrayList;
import java.util.List;

@SuppressWarnings("unused")
public class AntiAntiXray extends Module {
    private final Queue<BlockPos> toScan = new Queue<>();
    private final TimerUtil timerUtil = new TimerUtil();

    private final IntegerValue range = register(new IntegerValue("Range", 5, 3, 10));
    private final IntegerValue skipDistance = register(new IntegerValue("SkipDistance", 2, 0, 6));
    private final IntegerValue blocksPerTick = register(new IntegerValue("BlocksPerTick", 1, 1, 20));
    private final IntegerValue delay = register(new IntegerValue("Delay", 10, 0, 1000));
    private final List<BlockPos> renders = new ArrayList<>();

    public AntiAntiXray() {
        super("AntiAntiXray", Category.MISC, Keyboard.KEY_NONE);
    }

    private boolean isBlockValid(Block block) {
        return (block instanceof BlockOre || block instanceof BlockRedstoneOre || block instanceof BlockTNT || block instanceof BlockObsidian);
    }

    @Override
    public void onEnable() {
        toScan.getQueue().clear();
        BlockPos ppos = new BlockPos(Math.floor(mc.player.posX), Math.floor(mc.player.posY), Math.floor(mc.player.posZ));
        Vec3d lastPos = Vec3d.ZERO;
        int rangeMid = range.getValue() / 2;
        for (int y = rangeMid; y > -rangeMid; y--) {
            for (int x = -rangeMid; x < rangeMid; x++) {
                for (int z = -rangeMid; z < rangeMid; z++) {
                    BlockPos current = ppos.add(x, y, z);
                    IBlockState bs = mc.world.getBlockState(current);
                    Vec3d currentPos = new Vec3d(current.getX(), current.getY(), current.getZ());
                    if (bs.getMaterial() != Material.AIR && lastPos.distanceTo(currentPos) >= skipDistance.getValue()) {
                        if (isBlockValid(bs.getBlock())) {
                            toScan.add(current);
                            lastPos = currentPos;
                        }
                    }
                }
            }
        }
    }

    @Override
    public void onTick() {
        if (toScan.getQueue().isEmpty()) {
            sendNotify("Done scanning ores!", NewNotifications.Type.INFO);
            toggle();
        } else {
            if (timerUtil.passedMs(delay.getValue())) {
                renders.clear();
                for (int i = 0; i < blocksPerTick.getValue(); i++) {
                    if (toScan.getQueue().isEmpty()) {
                        break;
                    }
                    BlockPos current = toScan.poll();
                    renders.add(current);

                    mc.player.connection.sendPacket(new CPacketPlayerDigging(CPacketPlayerDigging.Action.ABORT_DESTROY_BLOCK, current, EnumFacing.DOWN));
                    timerUtil.reset();
                }
            }
        }
    }

    @Override
    public void onRender3D() {
        if (!renders.isEmpty()) {
            for (BlockPos pos : renders) {
                int box = ColorUtil.getRainbow(3f, 1f, 1f, 1L);
                int outline = ColorUtil.getRainbow(3f, 1f, 1f, 1L);
                ColorConverter converterBox = new ColorConverter(box);
                converterBox.setAlpha(191);
                RenderUtil3D.drawBox(pos, converterBox.getColor(), outline, true, true, 1f);
            }
        }
    }
}
