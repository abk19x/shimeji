package me.enokitoraisu.shimejiclient.module.impl.misc;

import me.enokitoraisu.shimejiclient.event.ClickBlockEvent;
import me.enokitoraisu.shimejiclient.module.Category;
import me.enokitoraisu.shimejiclient.module.Module;
import me.enokitoraisu.shimejiclient.utils.math.Easings;
import me.enokitoraisu.shimejiclient.utils.math.TimerUtil;
import me.enokitoraisu.shimejiclient.utils.renderer.RenderUtil3D;
import me.enokitoraisu.shimejiclient.value.values.BooleanValue;
import me.enokitoraisu.shimejiclient.value.values.IntegerValue;
import me.enokitoraisu.shimejiclient.value.values.ModeValue;
import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.init.Blocks;
import net.minecraft.network.play.client.CPacketPlayerDigging;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.math.BlockPos;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import org.lwjgl.input.Keyboard;

@SuppressWarnings("unused")
public class SpeedMine extends Module {
    private final TimerUtil timerUtil = new TimerUtil();
    private final TimerUtil clickTimer = new TimerUtil();
    private final Block[] blacklist = new Block[]{
            Blocks.COMMAND_BLOCK,
            Blocks.REPEATING_COMMAND_BLOCK,
            Blocks.CHAIN_COMMAND_BLOCK,
            Blocks.PORTAL,
            Blocks.END_PORTAL_FRAME,
            Blocks.END_PORTAL,
            Blocks.BEDROCK
    };
    private final IntegerValue clickDelay = register(new IntegerValue("ClickDelay", 10, 1, 50));
    private final BooleanValue renderText = register(new BooleanValue("RenderText", false));
    private final ModeValue renderMode = register(new ModeValue("RenderMode", "Zoom", "Zoom", "Height"));
    private BlockPos breakingPos;
    private EnumFacing breakingFacing;
    private boolean air = true;

    public SpeedMine() {
        super("SpeedMine", Category.MISC, Keyboard.KEY_NONE);
    }

    @SubscribeEvent
    public void clickBlock(ClickBlockEvent event) {
        if (clickTimer.passedDms(clickDelay.getValue()) && air) {
            air = false;
            boolean breakable = true;
            for (Block block : blacklist) {
                if (mc.world.getBlockState(event.getPos()).getBlock() == block) {
                    breakable = false;
                    break;
                }
            }
            if (breakable) {
                this.breakingPos = event.getPos();
                this.breakingFacing = event.getFacing();
                this.timerUtil.reset();
                mc.player.connection.sendPacket(new CPacketPlayerDigging(CPacketPlayerDigging.Action.START_DESTROY_BLOCK, this.breakingPos, this.breakingFacing));
                mc.player.connection.sendPacket(new CPacketPlayerDigging(CPacketPlayerDigging.Action.STOP_DESTROY_BLOCK, this.breakingPos, this.breakingFacing));
            }
            clickTimer.reset();
        }
        event.setCanceled(true);
    }

    @Override
    public void onDisable() {
        this.breakingPos = null;
        this.breakingFacing = null;
        this.air = true;
    }

    @Override
    public void onRender3D() {
        if (this.breakingPos == null || this.air) return;
        if (mc.world.getBlockState(breakingPos).getMaterial() == Material.AIR) this.air = true;
        float speedFactor = (timerUtil.getPassedTimeMs() / 1000f) * ((digSpeed(breakingPos) / hardness(breakingPos)));
        switch (renderMode.getValue()) {
            case "Zoom":
                RenderUtil3D.drawCenterScaledBox(this.breakingPos, (float) Easings.circOut(Math.min(speedFactor, 1.0f)), new int[]{0x40FFFFFF, 0xFFFFFFFF});
                break;
            case "Height":
                RenderUtil3D.drawHeightScaledBox(this.breakingPos, (float) Easings.circOut(Math.min(speedFactor, 1.0f)), new int[]{0x40FFFFFF, 0xFFFFFFFF});
                break;
        }

        if (renderText.getValue())
            RenderUtil3D.drawString3D(this.breakingPos, String.format("%.0f%%", Math.min(speedFactor, 1.0f) * 100), mc.fontRenderer, true, -1);
    }

    public float digSpeed(BlockPos pos) {
        return mc.player.getDigSpeed(mc.world.getBlockState(pos), pos);
    }

    public float hardness(BlockPos pos) {
        return mc.world.getBlockState(pos).getBlockHardness(mc.world, pos);
    }
}
