package me.enokitoraisu.shimejiclient.gui.shimeji.componet;

import me.enokitoraisu.shimejiclient.utils.interfaces.Util;

public class Component implements Util {
    public int x;
    public int y;
    public int width;
    public int height;
    public boolean visible;

    public void drawScreen(int mouseX, int mouseY, int offsetY) {}
    public void mouseClicked(int mouseX, int mouseY, int mouseButton) {}
    public void mouseReleased(int mouseX, int mouseY, int state) {}
    public void mouseClickMove(int mouseX, int mouseY, int clickedMouseButton) {}
    public void keyTyped(char typedChar, int keyCode) {}

    public boolean bounding(int mouseX, int mouseY) {
        return this.x <= mouseX && this.x + this.width > mouseX && this.y <= mouseY && this.y + this.height > mouseY;
    }

    public boolean bounding(int mouseX, int mouseY, int x, int y, int width, int height) {
        return x <= mouseX && x + width > mouseX && y <= mouseY && y + height > mouseY;
    }

    public boolean isVisible() {
        return visible;
    }
}

