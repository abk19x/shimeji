package me.enokitoraisu.shimejiclient.event;

import net.minecraft.util.EnumHandSide;

public class SideItemRendererEvent extends EventManager {
    private final EnumHandSide hand;
    private final float p_187459_2_;

    public SideItemRendererEvent(EnumHandSide hand, float p_187459_2_) {
        this.hand = hand;
        this.p_187459_2_ = p_187459_2_;
    }

    public EnumHandSide getHand() {
        return hand;
    }

    public float getP_187459_2_() {
        return p_187459_2_;
    }
}
