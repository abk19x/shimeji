package me.enokitoraisu.shimejiclient.command.impl;

import me.enokitoraisu.shimejiclient.ShimejiClient;
import me.enokitoraisu.shimejiclient.command.Command;
import me.enokitoraisu.shimejiclient.module.Module;
import me.enokitoraisu.shimejiclient.module.impl.player.PositionLook;
import me.enokitoraisu.shimejiclient.value.ValueBase;
import me.enokitoraisu.shimejiclient.value.values.StringValue;

import java.util.Objects;

public class Set extends Command {
    public Set() {
        super("Set", "Change the value of a string.");
    }

    @Override
    public void onCommand() {
        try {
            for (Module m : ShimejiClient.moduleManager.modules) {
                if (m.name.equalsIgnoreCase(arg(1))) {
                    if (m instanceof PositionLook) {
                        PositionLook positionLook = (PositionLook) m;
                        try {
                            if (Objects.equals(arg(2).toLowerCase(), "x")) {
                                int arg = Integer.parseInt(arg(3));
                                if (arg > positionLook.x.getMax() && arg < positionLook.x.getMin())
                                    return;
                                positionLook.x.setValue(arg);
                            } else if (Objects.equals(arg(2).toLowerCase(), "y")) {
                                int arg = Integer.parseInt(arg(3));
                                if (arg > positionLook.y.getMax() && arg < positionLook.y.getMin())
                                    return;
                                positionLook.y.setValue(arg);
                            } else if (Objects.equals(arg(2).toLowerCase(), "z")) {
                                int arg = Integer.parseInt(arg(3));
                                if (arg > positionLook.z.getMax() && arg < positionLook.z.getMin())
                                    return;
                                positionLook.z.setValue(arg);
                            }
                        } catch (NumberFormatException e) {
                            sendMessage("Please change the value to an integer and try again");
                        } catch (ArrayIndexOutOfBoundsException e) {
                            sendMessage("Usage: >Set PositionLook (x, y, z) (integer)");
                        }

                        return;
                    }

                    for (ValueBase<?> setting : m.settings) {
                        if (setting instanceof StringValue && setting.getName().equalsIgnoreCase(arg(2))) {
                            ((StringValue) setting).setValue(arg(3));
                            sendMessage(m.getName() + " setting " + setting.getName() + " value set to " + arg(3));
                        }
                    }

                    return;
                }
            }
        } catch (Exception ignored) {
            sendMessage("Usage: >Set <ModuleName> <ValueName> <Value>");
        }
    }
}
