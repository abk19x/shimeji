package me.enokitoraisu.shimejiclient.utils.chat;

import me.enokitoraisu.shimejiclient.utils.interfaces.Util;
import net.minecraft.client.gui.GuiNewChat;
import net.minecraft.util.text.ITextComponent;

import java.util.function.Consumer;

public class ChatUtil implements Util {
    public static void sendComponent(ITextComponent c, int id) {
        applyIfPresent(g -> g.printChatMessageWithOptionalDeletion(c, id));
    }

    public static void applyIfPresent(Consumer<GuiNewChat> consumer) {
        GuiNewChat chat = getChatGui();
        if (chat != null) {
            consumer.accept(chat);
        }
    }

    public static GuiNewChat getChatGui() {
        if (mc.ingameGUI != null) {
            return mc.ingameGUI.getChatGUI();
        }
        return null;
    }
}
