package me.enokitoraisu.shimejiclient.module.impl.misc;

import me.enokitoraisu.shimejiclient.ShimejiClient;
import me.enokitoraisu.shimejiclient.event.PacketEvent;
import me.enokitoraisu.shimejiclient.mixin.AccessorCPacketChatMessage;
import me.enokitoraisu.shimejiclient.module.Category;
import me.enokitoraisu.shimejiclient.module.Module;
import me.enokitoraisu.shimejiclient.value.values.BooleanValue;
import net.minecraft.network.play.client.CPacketChatMessage;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import org.lwjgl.input.Keyboard;

import java.util.Random;

@SuppressWarnings("unused")
public class ChatAppend extends Module {
    private final BooleanValue shrug = register(new BooleanValue("Shrug", false));
    private final BooleanValue random = register(new BooleanValue("Random", false));
    @SuppressWarnings("all")
    private final String normalSize = "\uA731\u029C\u026A\u1D0D\u1D07\u1D0A\u026A \u1D04\u029F\u026A\u1D07\u0274\u1D1B";
    @SuppressWarnings("all")
    private final String smallSize = "\u1506\u1D34\u1D35\u1D39\u1D31\u1D36\u1D35 \u1D9C\u1D38\u1D35\u1D31\u1D3A\u1D40";

    public ChatAppend() {
        super("ChatAppend", Category.MISC, Keyboard.KEY_NONE);
    }

    @SuppressWarnings("all")
    @SubscribeEvent
    public void onChat(PacketEvent.Send event) {
        if (event.packet instanceof CPacketChatMessage) {
            String msg = ((CPacketChatMessage) event.getPacket()).getMessage();
            if (!msg.startsWith("/") || msg.startsWith(ShimejiClient.CmdPrefix)) {
                if (shrug.getValue() && msg.contains(":shrug:"))
                    msg = msg.replace(":shrug:", "\u00AF\\_(\u30C4)_/\u00AF");
                msg += " | " + (random.getValue() ? toRandom(normalSize, smallSize) : normalSize);
                if (msg.length() >= 256) msg = msg.substring(0, 256);
                ((AccessorCPacketChatMessage) event.getPacket()).setMessage(msg);
            }
        }
    }

    public String toRandom(String s1, String s2) {
        if (s1.length() != s2.length()) return s1;
        StringBuilder str = new StringBuilder();
        for (int i = 0; i < s1.length(); i++) {
            Random random = new Random();

            if (random.nextBoolean()) {
                str.append(s1.toCharArray()[i]);
            } else {
                str.append(s2.toCharArray()[i]);
            }
        }

        return str.toString();
    }
}
