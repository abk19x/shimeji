package me.enokitoraisu.shimejiclient.event;

public class JumpEvent extends EventManager {
}
