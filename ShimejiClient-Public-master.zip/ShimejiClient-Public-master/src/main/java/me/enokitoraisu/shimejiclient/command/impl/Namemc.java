package me.enokitoraisu.shimejiclient.command.impl;

import me.enokitoraisu.shimejiclient.command.Command;

import java.net.URI;

@SuppressWarnings("unused")
public class Namemc extends Command {
    public Namemc() {
        super("Namemc", "View Namemc in your browser.");
    }

    @Override
    public void onCommand() {
        try {
            String url_open = "https://ja.namemc.com/profile/" + arg(1);
            openWebLink(new URI(url_open));
            sendMessage("\u00A7aOpened Browser");
        } catch (Exception ex) {
            sendMessage("Username Not specified");
        }
    }

    private void openWebLink(URI url) {
        try {
            Class<?> desktop = Class.forName("java.awt.Desktop");
            Object object = desktop.getMethod("getDesktop").invoke(null);
            desktop.getMethod("browse", URI.class).invoke(object, url);
        } catch (Exception ignored) {
        }
    }
}