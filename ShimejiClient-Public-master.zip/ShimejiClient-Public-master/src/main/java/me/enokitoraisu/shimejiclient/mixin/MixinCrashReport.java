package me.enokitoraisu.shimejiclient.mixin;

import me.enokitoraisu.shimejiclient.ShimejiClient;
import net.minecraft.crash.CrashReport;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(CrashReport.class)
public class MixinCrashReport {
    @Inject(method = "makeCrashReport(Ljava/lang/Throwable;Ljava/lang/String;)Lnet/minecraft/crash/CrashReport;", at = @At(value = "HEAD"))
    private static void makeCrashReport(Throwable causeIn, String descriptionIn, CallbackInfoReturnable<CrashReport> cir) {
        if (ShimejiClient.configManager != null && ShimejiClient.moduleManager != null)
            ShimejiClient.configManager.saveConfigs();
    }
}
