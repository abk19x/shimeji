package me.enokitoraisu.shimejiclient.module.impl.player;

import me.enokitoraisu.shimejiclient.module.Category;
import me.enokitoraisu.shimejiclient.module.Module;
import me.enokitoraisu.shimejiclient.utils.entity.BlockUtil;
import me.enokitoraisu.shimejiclient.utils.math.TimerUtil;
import me.enokitoraisu.shimejiclient.utils.renderer.RenderUtil3D;
import me.enokitoraisu.shimejiclient.value.values.BooleanValue;
import me.enokitoraisu.shimejiclient.value.values.IntegerValue;
import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemSkull;
import net.minecraft.item.ItemStack;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import org.lwjgl.input.Keyboard;

@SuppressWarnings("unused")
public class FloorBuilder extends Module {
    public TimerUtil timer = new TimerUtil();
    public BlockPos render_pos;

    public IntegerValue range = register(new IntegerValue("Range", 3, 0, 6));
    public BooleanValue rotation = register(new BooleanValue("Rotate", true));
    public BooleanValue packet = register(new BooleanValue("PacketPlace", true));
    public IntegerValue delay = register(new IntegerValue("Delay", 10, 0, 50));

    public FloorBuilder() {
        super("FloorBuilder", Category.PLAYER, Keyboard.KEY_NONE);
    }

    @Override
    public void onTick() {
        if (!checkHeldItem()) return;

        Vec3d vec3d = mc.player.getPositionVector();
        BlockPos originPos = new BlockPos(vec3d.x, vec3d.y - 1, vec3d.z);
        int posX = originPos.getX();
        int posZ = originPos.getZ();

        for (int x = posX - range.getValue(); x <= posX + range.getValue(); x++) {
            for (int z = posZ - range.getValue(); z <= posZ + range.getValue(); z++) {
                if (mc.world.getBlockState(new BlockPos(x, originPos.getY(), z)).getMaterial().isReplaceable()) {
                    BlockPos floorPos = new BlockPos(x, originPos.getY(), z);
                    if (timer.passedMs(delay.getValue())) {
                        BlockUtil.placeBlock(floorPos, EnumHand.MAIN_HAND, rotation.getValue(), packet.getValue(), mc.player.isSneaking());
                        this.render_pos = floorPos;
                        timer.reset();
                    }
                }
            }
        }
    }

    private boolean checkHeldItem() {
        ItemStack stack = mc.player.inventory.getCurrentItem();
        return !stack.isEmpty() && (stack.getItem() instanceof ItemBlock || stack.getItem() instanceof ItemSkull);
    }

    public void onRender3D() {
        if (render_pos != null) {
            RenderUtil3D.drawBox(render_pos, 0x4dffffff, 0xffffffff, true, true, 1.0f);
        }
    }
}
