package me.enokitoraisu.shimejiclient.gui.shimeji.componet.componets;

import me.enokitoraisu.shimejiclient.gui.GuiSetting;
import me.enokitoraisu.shimejiclient.gui.shimeji.Panel;
import me.enokitoraisu.shimejiclient.gui.shimeji.componet.Component;
import me.enokitoraisu.shimejiclient.module.Module;
import me.enokitoraisu.shimejiclient.utils.animation.Animate;
import me.enokitoraisu.shimejiclient.utils.animation.Easing;
import me.enokitoraisu.shimejiclient.utils.renderer.RenderUtil;
import me.enokitoraisu.shimejiclient.utils.renderer.font.FontUtil;
import me.enokitoraisu.shimejiclient.value.ValueBase;
import me.enokitoraisu.shimejiclient.value.values.*;

import java.util.ArrayList;
import java.util.List;

public class ModuleButton extends Component {
    public final List<Component> components = new ArrayList<>();
    private final Module module;
    private final Animate animate = new Animate();
    private boolean isOpening = false;
    private int lastMouseX;
    private int lastMouseY;

    public ModuleButton(Module module, int x, int width, int height) {
        this.module = module;
        this.x = x;
        this.width = width;
        this.height = height;
        module.settings.forEach(this::registerComponents);
        this.components.add(new DrawnButton(module, this, x, width, height));
        this.components.add(new KeyBindButton(module, x, width, height));
    }

    public void drawScreen(int mouseX, int mouseY, int offsetY) {
        this.y = offsetY;

        RenderUtil.drawRect(this.x, offsetY, this.width, this.height, 0xCB191919);
        animate.setEase(Easing.LINEAR).setMin(0).setMax(100).setSpeed(500).setReversed(!this.module.toggled).update();
        RenderUtil.drawRectCircle(x, offsetY, width, this.height, lastMouseX, lastMouseY, animate.getValue() / animate.getMax(), GuiSetting.getAccent());
        if (this.bounding(mouseX, mouseY))
            RenderUtil.drawRect(this.x, offsetY, this.width, this.height, 0x40000000);
        FontUtil.sfui18.drawStringWithShadow(this.module.name, this.x + 3, offsetY + (this.height - FontUtil.sfui18.getHeight()) / 2f, -1);
        if (components.size() > 2)
            FontUtil.sfui18.drawStringWithShadow(isOpening ? "-" : "+", this.x + this.width - FontUtil.sfui18.getStringWidth(isOpening ? "-" : "+") - 3, offsetY + (this.height - FontUtil.sfui18.getHeight()) / 2f, -1);

        if (this.isOpening) {
            this.components.forEach(component -> {
                component.drawScreen(mouseX, mouseY, Panel.offset += this.height);
                if (!component.visible) Panel.offset -= this.height;
            });

            RenderUtil.drawOutLineRect(x + .5f, offsetY, width - 1, (Panel.offset + height) - offsetY - .5f, .5f, this.module.toggled ? GuiSetting.getAccent() : 0xFF191919);
            if (this.bounding(mouseX, mouseY))
                RenderUtil.drawOutLineRect(x + .5f, offsetY, width - 1, (Panel.offset + height) - offsetY - .5f, .5f, 0x40000000);
        }
    }

    public void registerComponents(ValueBase<?> setting) {
        if (setting instanceof BooleanValue)
            this.components.add(new BooleanButton((BooleanValue) setting, this.x, this.width, this.height));
        if (setting instanceof IntegerValue)
            this.components.add(new IntegerButton((IntegerValue) setting, this.x, this.width, this.height));
        if (setting instanceof StringValue)
            this.components.add(new StringButton((StringValue) setting, this.x, this.width, this.height));
        if (setting instanceof FloatValue)
            this.components.add(new FloatButton((FloatValue) setting, this.x, this.width, this.height));
        if (setting instanceof ColorValue)
            this.components.add(new HSBButton((ColorValue) setting, this.x, this.width, this.height));
        if (setting instanceof ModeValue)
            this.components.add(new DropDownButton<>((ModeValue) setting, this.x, this.width, this.height));
        if (setting instanceof EnumValue)
            this.components.add(new DropDownButton<>((EnumValue<? extends Enum<?>>) setting, this.x, this.width, this.height));
        if (setting instanceof KeyValue)
            this.components.add(new KeyButton((KeyValue) setting, this.x, this.width, this.height));
    }

    public void changeX(int x) {
        this.x = x;
        this.components.forEach(component -> component.x = x);
    }

    @Override
    public void mouseClicked(int mouseX, int mouseY, int mouseButton) {
        if (this.isOpening) this.components.forEach(component -> component.mouseClicked(mouseX, mouseY, mouseButton));
        if (this.bounding(mouseX, mouseY) && mouseButton == 0) {
            this.lastMouseX = mouseX;
            this.lastMouseY = mouseY;
            this.module.toggle();
        }
        if (this.bounding(mouseX, mouseY) && mouseButton == 1) this.isOpening = !this.isOpening;
    }

    @Override
    public void mouseReleased(int mouseX, int mouseY, int state) {
        if (this.isOpening) this.components.forEach(component -> component.mouseReleased(mouseX, mouseY, state));
    }

    @Override
    public void mouseClickMove(int mouseX, int mouseY, int clickedMouseButton) {
        if (this.isOpening)
            this.components.forEach(component -> component.mouseClickMove(mouseX, mouseY, clickedMouseButton));
    }

    @Override
    public void keyTyped(char typedChar, int keyCode) {
        if (this.isOpening) this.components.forEach(component -> component.keyTyped(typedChar, keyCode));
    }
}