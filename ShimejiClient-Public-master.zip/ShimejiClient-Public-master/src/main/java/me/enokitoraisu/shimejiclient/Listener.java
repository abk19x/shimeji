package me.enokitoraisu.shimejiclient;

import me.enokitoraisu.shimejiclient.command.Command;
import me.enokitoraisu.shimejiclient.event.KeyInputEvent;
import me.enokitoraisu.shimejiclient.module.Module;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiChat;
import net.minecraftforge.client.event.ClientChatEvent;
import net.minecraftforge.client.event.RenderGameOverlayEvent;
import net.minecraftforge.client.event.RenderWorldLastEvent;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.eventhandler.Event;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.InputEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import org.lwjgl.input.Keyboard;

public class Listener {
    @SubscribeEvent
    public void runEvent(Event event) {
        if (event instanceof RenderWorldLastEvent)
            ShimejiClient.moduleManager.modules.stream().filter(Module::isToggled).forEach(Module::onRender3D);

        if (event instanceof TickEvent.PlayerTickEvent) {
            TickEvent.PlayerTickEvent tickEvent = (TickEvent.PlayerTickEvent) event;
            if (tickEvent.phase == TickEvent.Phase.START && tickEvent.player == Minecraft.getMinecraft().player)
                ShimejiClient.moduleManager.modules.stream().filter(Module::isToggled).forEach(Module::onTick);
        }

        if (event instanceof RenderGameOverlayEvent.Text) {
            for (Module module : ShimejiClient.moduleManager.modules) {
                if (module.isToggled())
                    module.onRender2D();
            }
        }

        if (event instanceof InputEvent.KeyInputEvent) {
            if (Minecraft.getMinecraft().player != null && Minecraft.getMinecraft().world != null) {
                if (Keyboard.isCreated() && Keyboard.getEventKeyState()) {
                    int eventKey = Keyboard.getEventKey();
                    if (eventKey != Keyboard.KEY_NONE && eventKey != Keyboard.KEY_F3) {
                        ShimejiClient.moduleManager.modules.stream().filter(m -> m.keyboard != Keyboard.KEY_NONE).filter(m -> m.keyboard == eventKey).forEach(Module::toggle);
                        MinecraftForge.EVENT_BUS.post(new KeyInputEvent(eventKey));

                        char eventCharacter = Keyboard.getEventCharacter();
                        if (ShimejiClient.CmdPrefix.charAt(0) == eventCharacter)
                            Minecraft.getMinecraft().displayGuiScreen(new GuiChat(ShimejiClient.CmdPrefix));
                    }
                }
            }
        }

        if (event instanceof ClientChatEvent) {
            ClientChatEvent clientChatEvent = (ClientChatEvent) event;
            String content = clientChatEvent.getMessage();
            if (content.startsWith(ShimejiClient.CmdPrefix)) {
                Minecraft.getMinecraft().ingameGUI.getChatGUI().addToSentMessages(content);
                clientChatEvent.setCanceled(true);
                for (Command c : ShimejiClient.commandManager.commands)
                    if (c.name.equalsIgnoreCase(content.split(" ")[0].replace(ShimejiClient.CmdPrefix, ""))) {
                        Command.commandInput = content;
                        c.onCommand();
                        return;
                    }
                Command.sendMessage(String.format("%s No such command", content));
            }
        }
    }
}
