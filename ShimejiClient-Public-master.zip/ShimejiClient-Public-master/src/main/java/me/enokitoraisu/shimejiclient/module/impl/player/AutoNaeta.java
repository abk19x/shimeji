package me.enokitoraisu.shimejiclient.module.impl.player;

import me.enokitoraisu.shimejiclient.module.Category;
import me.enokitoraisu.shimejiclient.module.Module;
import me.enokitoraisu.shimejiclient.module.impl.hud.NewNotifications;
import me.enokitoraisu.shimejiclient.value.values.BooleanValue;
import me.enokitoraisu.shimejiclient.value.values.FloatValue;
import net.minecraft.util.text.TextComponentString;
import org.lwjgl.input.Keyboard;

@SuppressWarnings("unused")
public class AutoNaeta extends Module {
    public BooleanValue suffix = register(new BooleanValue("Suffix", false));
    public BooleanValue instant = register(new BooleanValue("InstantLeave", false));
    public FloatValue times = register(new FloatValue("SleepTime", 1000.0F, 0.0F, 5000.0F));

    public AutoNaeta() {
        super("AutoNaeta", Category.PLAYER, Keyboard.KEY_NONE);
    }

    @Override
    public void onEnable() {
        if (!mc.isSingleplayer()) {
            new Thread(this::leave).start();
        } else {
            sendNotify("Not available in SinglePlay", NewNotifications.Type.WARN);
        }
        this.toggle();
    }

    private void leave() {
        mc.player.sendChatMessage("\u840E\u3048\u305F" + (suffix.getValue() ? "(send by AutoNaeta)" : ""));
        if (!instant.getValue()) try {
            Thread.sleep(times.getValue().longValue());
        } catch (Exception ignored) {
        }
        if (fullNullCheck())
            mc.player.connection.getNetworkManager().closeChannel(new TextComponentString("\u840E\u3048\u843D\u3061"));
    }
}
