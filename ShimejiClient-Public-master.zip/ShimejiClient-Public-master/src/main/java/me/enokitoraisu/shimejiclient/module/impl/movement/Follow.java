package me.enokitoraisu.shimejiclient.module.impl.movement;

import me.enokitoraisu.shimejiclient.module.Category;
import me.enokitoraisu.shimejiclient.module.Module;
import me.enokitoraisu.shimejiclient.utils.entity.EntityUtil;
import me.enokitoraisu.shimejiclient.utils.entity.FriendUtil;
import me.enokitoraisu.shimejiclient.value.values.ModeValue;
import net.minecraft.entity.player.EntityPlayer;
import org.lwjgl.input.Keyboard;

import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

@SuppressWarnings("unused")
public class Follow extends Module {
    private final ModeValue mode = register(new ModeValue("Mode", "Motion", "Motion", "SetPosition", "SetPosUpdate"));

    public Follow() {
        super("Follow", Category.MOVEMENT, Keyboard.KEY_NONE);
    }

    private EntityPlayer target() {
        if (mc.world.playerEntities.isEmpty()) return null;
        if (mc.world.playerEntities.get(0) == null) return null;
        List<EntityPlayer> players = mc.world.playerEntities.stream().filter(player -> !mc.player.equals(player)).filter(player -> !FriendUtil.isFriend(player)).sorted(Comparator.comparingDouble(mc.player::getDistance)).collect(Collectors.toList());
        if (players.isEmpty()) return null;
        return players.get(0);
    }

    @Override
    public void onTick() {
        EntityPlayer target = target();
        if (target != null) {
            switch (mode.getValue()) {
                case "Motion":
                    EntityUtil.motion(target.posX, target.posY, target.posZ);
                    break;
                case "SetPosition":
                    mc.player.setPosition(target.posX, target.posY, target.posZ);
                    break;
                case "SetPosUpdate":
                    mc.player.setPositionAndUpdate(target.posX, target.posY, target.posZ);
                    break;
            }
        }
    }
}