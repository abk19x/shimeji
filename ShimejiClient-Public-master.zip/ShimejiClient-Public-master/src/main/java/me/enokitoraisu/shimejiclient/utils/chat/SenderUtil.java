package me.enokitoraisu.shimejiclient.utils.chat;

import me.enokitoraisu.shimejiclient.utils.interfaces.Util;
import net.minecraft.util.text.ITextComponent;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class SenderUtil implements Util {
    private static final Map<Integer, Map<String, Integer>> message_ids = new ConcurrentHashMap<>();
    private static final SkippingCounter counter = new SkippingCounter(1337, i -> i != -1);

    public void sendDeleteComponent(ITextComponent component, int senderID, String key) {
        Integer id = message_ids.computeIfAbsent(senderID, v -> new ConcurrentHashMap<>()).computeIfAbsent(key, v -> counter.next());

        ChatUtil.sendComponent(component, id);
    }
}
