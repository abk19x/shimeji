package me.enokitoraisu.shimejiclient.value.values;

import me.enokitoraisu.shimejiclient.value.ValueBase;

import java.util.Arrays;
import java.util.function.Predicate;

public class EnumValue<T extends Enum<T> & IEnumValue> extends ValueBase<T> {
    private final T[] enumConstants;

    public EnumValue(String name, T value) {
        this(name, value, v -> true);
    }

    public EnumValue(String name, T value, Predicate<T> visibility) {
        super(name, value, visibility);
        this.enumConstants = value.getDeclaringClass().getEnumConstants();
    }

    public T[] getEnumConstants() {
        return enumConstants;
    }

    public void incrementValue() {
        int currentIndex = Arrays.asList(enumConstants).indexOf(getValue());
        int nextIndex = (currentIndex + 1) % enumConstants.length;
        setValue(enumConstants[nextIndex]);
    }

    public void decrementValue() {
        int currentIndex = Arrays.asList(enumConstants).indexOf(getValue());
        int previousIndex = (currentIndex - 1 + enumConstants.length) % enumConstants.length;
        setValue(enumConstants[previousIndex]);
    }
}