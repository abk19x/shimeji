package me.enokitoraisu.shimejiclient.manager;

import me.spotify.gson.JsonElement;
import me.spotify.gson.JsonParser;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.HashMap;
import java.util.UUID;

public class ListManager {
    public HashMap<UUID, Nick> nicknames = new HashMap<>();

    public static String getUserName(UUID uuid) {
        try {
            URL url = new URL(String.format("https://sessionserver.mojang.com/session/minecraft/profile/%s", uuid.toString().replace("-", "")));
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();

            connection.setRequestMethod("GET");

            BufferedReader in = new BufferedReader(new InputStreamReader(connection.getInputStream()));
            String inputLine;
            StringBuilder content = new StringBuilder();
            while ((inputLine = in.readLine()) != null) {
                content.append(inputLine);
            }
            in.close();

            JsonElement jsonElement = JsonParser.parseString(content.toString());

            // オブジェクトの処理を行う
            JsonElement name = jsonElement.getAsJsonObject().get("name");

            connection.disconnect();
            if (name == null)
                return null;
            else
                return name.getAsString();
        } catch (IOException e) {
            return null;
        }
    }

    public void reloadUUIDs() {
        nicknames.forEach((uuid, nick) -> {
            nick.setUsername(getUserName(uuid));
        });
    }

    public static class Nick {
        public String username;
        public String nickname;

        public Nick(String username, String nickname) {
            this.username = username;
            this.nickname = nickname;
        }

        public void setNickname(String nickname) {
            this.nickname = nickname;
        }

        public void setUsername(String username) {
            this.username = username;
        }
    }
}
