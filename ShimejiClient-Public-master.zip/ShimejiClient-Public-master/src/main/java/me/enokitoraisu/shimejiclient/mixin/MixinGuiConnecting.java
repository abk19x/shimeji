package me.enokitoraisu.shimejiclient.mixin;

import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.multiplayer.GuiConnecting;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(GuiConnecting.class)
public class MixinGuiConnecting extends GuiScreen {
    @Inject(method = "drawScreen(IIF)V", at = @At(value = "RETURN"))
    private void drawScreen(int mouseX, int mouseY, float partialTicks, CallbackInfo ci) {
        String ConnectMessage = "Connecting... [" + mc.getCurrentServerData().serverIP + "]";
        mc.fontRenderer.drawStringWithShadow(
                ConnectMessage,
                width / 2f - mc.fontRenderer.getStringWidth(ConnectMessage) / 2f,
                height / 2f - mc.fontRenderer.FONT_HEIGHT * 2,
                -1
        );
    }
}
