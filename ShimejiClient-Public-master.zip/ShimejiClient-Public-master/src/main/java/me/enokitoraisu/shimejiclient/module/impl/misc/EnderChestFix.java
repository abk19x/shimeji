package me.enokitoraisu.shimejiclient.module.impl.misc;

import me.enokitoraisu.shimejiclient.module.Category;
import me.enokitoraisu.shimejiclient.module.Module;
import me.enokitoraisu.shimejiclient.value.values.BooleanValue;
import org.lwjgl.input.Keyboard;

public class EnderChestFix extends Module {
    public static EnderChestFix INSTANCE = new EnderChestFix();
    public final BooleanValue xFixer = register(new BooleanValue("X-Fixer", true));
    public final BooleanValue yFixer = register(new BooleanValue("Y-Fixer", true));
    public final BooleanValue zFixer = register(new BooleanValue("Z-Fixer", true));

    public EnderChestFix() {
        super("EnderChestFix", Category.MISC, Keyboard.KEY_NONE);
        INSTANCE = this;
    }
}
