package me.enokitoraisu.shimejiclient.utils.interfaces;

public interface TimedRenderer extends Util {
    /**
     * Returns the time when this render was created, in milliseconds since the epoch.
     */
    long getCreationTime();

    /**
     * Returns the maximum age of this render, in milliseconds.
     */
    long getMaxAge();

    /**
     * Renders this object.
     */
    default void render() {
    }

    /**
     * Returns the progress of this render, as a value between 0 and 1.
     * A value of 0 indicates that the render has just been created, and a value of 1 indicates that
     * the render is about to expire.
     */
    default float getProgress() {
        long currentTime = System.currentTimeMillis();
        long age = currentTime - getCreationTime();
        return (float) Math.min(1.0, (double) age / getMaxAge());
    }

    /**
     * Returns true if this render has expired and should be removed.
     */
    default boolean hasExpired() {
        long currentTime = System.currentTimeMillis();
        long age = currentTime - getCreationTime();
        return age >= getMaxAge();
    }
}