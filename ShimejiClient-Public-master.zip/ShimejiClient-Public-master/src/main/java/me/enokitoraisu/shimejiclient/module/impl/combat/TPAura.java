package me.enokitoraisu.shimejiclient.module.impl.combat;

import me.enokitoraisu.shimejiclient.module.Category;
import me.enokitoraisu.shimejiclient.module.Module;
import me.enokitoraisu.shimejiclient.utils.entity.DamageUtil;
import me.enokitoraisu.shimejiclient.utils.entity.EntityUtil;
import me.enokitoraisu.shimejiclient.utils.entity.FriendUtil;
import me.enokitoraisu.shimejiclient.utils.math.TimerUtil;
import me.enokitoraisu.shimejiclient.value.values.BooleanValue;
import me.enokitoraisu.shimejiclient.value.values.IntegerValue;
import me.enokitoraisu.shimejiclient.value.values.ModeValue;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemSword;
import net.minecraft.network.play.client.CPacketAnimation;
import net.minecraft.network.play.client.CPacketPlayer;
import net.minecraft.util.EnumHand;
import org.lwjgl.input.Keyboard;

import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

@SuppressWarnings("unused")
public class TPAura extends Module {
    private static EntityLivingBase target;
    private final TimerUtil timerUtil = new TimerUtil();

    private final IntegerValue max_range = register(new IntegerValue("Max Range", 20, 0, 100));
    private final BooleanValue only = register(new BooleanValue("OnlyPlayer", true));
    private final BooleanValue swordOnly = register(new BooleanValue("Sword Only", false));
    private final BooleanValue motion = register(new BooleanValue("Motion", false));
    private final ModeValue type = register(new ModeValue("TPType", "Semi", v -> !motion.getValue(), "Full", "Semi"));
    private final BooleanValue onGround = register(new BooleanValue("onGround", false));
    private final ModeValue swing = register(new ModeValue("Swing", "Full", "Full", "Packet", "None"));

    public TPAura() {
        super("TPAura", "GOMI#2", Category.COMBAT, Keyboard.KEY_NONE);
    }

    @Override
    public void onTick() {
        if (swordOnly.getValue() && !(mc.player.inventory.getStackInSlot(mc.player.inventory.currentItem).getItem() instanceof ItemSword))
            return;

        List<Entity> targets;
        if (only.getValue()) {
            targets = mc.world.loadedEntityList.stream().filter(EntityPlayer.class::isInstance).collect(Collectors.toList());
        } else {
            targets = mc.world.loadedEntityList.stream().filter(EntityLivingBase.class::isInstance).collect(Collectors.toList());
        }

        targets = targets.stream().filter(entity -> {
            if (entity instanceof EntityPlayer) {
                return !FriendUtil.isFriend((EntityPlayer) entity);
            } else {
                return true;
            }
        }).collect(Collectors.toList());

        targets = targets.stream().filter(entity -> mc.player.getDistance(entity) < (this.max_range.getValue() * 2) && entity != mc.player).collect(Collectors.toList());
        targets = targets.stream().filter(entity -> !entity.isDead && ((EntityLivingBase) entity).getHealth() > 0).collect(Collectors.toList());
        targets.sort(Comparator.comparingDouble(mc.player::getDistance));

        if (!targets.isEmpty()) {
            target = (EntityLivingBase) targets.get(0);

            if (timerUtil.passedMs(DamageUtil.getCoolDownByWeapon(mc.player))) {
                move(target, () -> {
                    mc.playerController.attackEntity(mc.player, target);
                    switch (swing.getValue()) {
                        case "Full":
                            mc.player.swingArm(EnumHand.MAIN_HAND);
                            break;
                        case "Packet":
                            mc.player.connection.sendPacket(new CPacketAnimation(EnumHand.MAIN_HAND));
                            break;
                        default:
                            break;
                    }
                });
                timerUtil.reset();
            }
        }
    }

    public void move(EntityLivingBase target, Runnable attack) {
        Position pos = new Position(mc.player.posX, mc.player.posY, mc.player.posZ);
        if (motion.getValue()) {
            EntityUtil.motion(target.posX, target.posY, target.posZ);
        } else {
            switch (type.getValue()) {
                case "Full":
                    mc.player.setPositionAndUpdate(target.posX, target.posY, target.posZ);
                    break;
                case "Semi":
                    mc.player.connection.sendPacket(new CPacketPlayer.Position(target.posX, target.posY, target.posZ, this.onGround.getValue()));
                    break;
            }
        }

        attack.run();

        if (motion.getValue()) {
            EntityUtil.motion(pos.getX(), pos.getY(), pos.getZ());
        } else {
            switch (type.getValue()) {
                case "Full":
                    mc.player.setPositionAndUpdate(pos.getX(), pos.getY(), pos.getZ());
                    break;
                case "Semi":
                    mc.player.connection.sendPacket(new CPacketPlayer.Position(pos.getX(), pos.getY(), pos.getZ(), this.onGround.getValue()));
                    break;
            }
        }
    }

    public static class Position {
        private double x;
        private double y;
        private double z;

        public Position(double x, double y, double z) {
            this.x = x;
            this.y = y;
            this.z = z;
        }

        public double getX() {
            return x;
        }

        public void setX(double x) {
            this.x = x;
        }

        public double getY() {
            return y;
        }

        public void setY(double y) {
            this.y = y;
        }

        public double getZ() {
            return z;
        }

        public void setZ(double z) {
            this.z = z;
        }
    }
}
