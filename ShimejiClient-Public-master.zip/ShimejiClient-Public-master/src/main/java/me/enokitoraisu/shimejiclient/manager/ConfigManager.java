package me.enokitoraisu.shimejiclient.manager;

import me.enokitoraisu.shimejiclient.ShimejiClient;
import me.enokitoraisu.shimejiclient.module.Category;
import me.enokitoraisu.shimejiclient.module.Module;
import me.enokitoraisu.shimejiclient.module.impl.misc.ChatIgnore;
import me.enokitoraisu.shimejiclient.utils.entity.FriendUtil;
import me.enokitoraisu.shimejiclient.value.ValueBase;
import me.enokitoraisu.shimejiclient.value.values.*;
import me.spotify.gson.Gson;
import me.spotify.gson.reflect.TypeToken;
import me.spotify.gson.stream.JsonReader;
import me.spotify.gson.stream.JsonWriter;
import org.apache.logging.log4j.LogManager;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.*;

public class ConfigManager {
    private final String title;
    private final IgnoreConfig ignores;
    private final FriendConfig friends;
    private final NickNameConfig nickName;

    public ConfigManager(String title) {
        this.title = title;
        this.ignores = new IgnoreConfig(title);
        this.friends = new FriendConfig(title);
        this.nickName = new NickNameConfig(title);
    }

    public void saveConfigs() {
        String folder = title + "/";
        File dir = new File(folder);
        if (!dir.exists())
            dir.mkdirs();
        for (Category category : Category.values()) {
            File categoryDir = new File(folder + category.name().toLowerCase());
            if (!categoryDir.exists())
                categoryDir.mkdirs();
        }
        for (Module module : ShimejiClient.moduleManager.modules) {
            try {
                Gson gson = new Gson();
                Config config = new Config();
                config.toggled = module.toggled;
                config.drawn = module.drawn;
                config.keyboard = module.keyboard;
                config.settings = new HashMap<>();
                for (ValueBase<?> setting : module.settings) {
                    if (setting instanceof ModeValue)
                        config.settings.put(setting.getName(), new Setting("Mode", setting.getValue()));
                    else if (setting instanceof ColorValue)
                        config.settings.put(setting.getName(), new Setting("Color", ((ColorValue) setting).getIntValue()));
                    else if (setting instanceof KeyValue)
                        config.settings.put(setting.getName(), new Setting("Keyboard", ((KeyValue) setting).getValue()));
                    else
                        config.settings.put(setting.getName(), new Setting(setting.getValue().getClass().getSimpleName(), setting.getValue()));
                }
                File configs = new File(String.format("%s/%s/%s.json", title, module.category.name().toLowerCase(), module.name.toLowerCase()));
                JsonWriter jsonWriter = new JsonWriter(new FileWriter(configs));
                jsonWriter.setIndent("  ");
                gson.toJson(config, Config.class, jsonWriter);
                jsonWriter.flush();
                jsonWriter.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        ignores.save();
        friends.save();
        nickName.save();
    }

    public void loadConfigs() {
        for (Module module : ShimejiClient.moduleManager.modules) {
            try {
                File file = new File(String.format("%s/%s/%s.json", title, module.category.name().toLowerCase(), module.name.toLowerCase()));
                if (file.exists()) {
                    Gson gson = new Gson();
                    Config config = gson.fromJson(new FileReader(file), Config.class);
                    config.settings.forEach((name, setting) -> {
                        List<ValueBase<?>> settings = new ArrayList<>(module.settings);
                        for (ValueBase<?> valueBase : module.settings) {
                            if (name.equals(valueBase.getName())) {
                                try {
                                    switch (setting.type) {
                                        case "Integer":
                                            ((IntegerValue) valueBase).setValue(Double.valueOf(String.valueOf(setting.value)).intValue());
                                            break;
                                        case "Boolean":
                                            ((BooleanValue) valueBase).setValue((Boolean) setting.value);
                                            break;
                                        case "Float":
                                            ((FloatValue) valueBase).setValue(((Double) setting.value).floatValue());
                                            break;
                                        case "Color":
                                            ((ColorValue) valueBase).setIntValue(Double.valueOf(String.valueOf(setting.value)).intValue());
                                            break;
                                        case "String":
                                            ((StringValue) valueBase).setValue((String) setting.value);
                                            break;
                                        case "Mode":
                                            ((ModeValue) valueBase).setValue((String) setting.value);
                                            break;
                                        case "ModeIndex":
                                            ((ModeValue) valueBase).setValueOfIndex(Double.valueOf(String.valueOf(setting.value)).intValue());
                                            break;
                                        case "Keyboard":
                                            ((KeyValue) valueBase).setValue(Double.valueOf(String.valueOf(setting.value)).intValue());
                                            break;
                                        case "Enum":
                                            ((EnumValue) valueBase).setValue(Enum.valueOf(((EnumValue<?>) valueBase).getValue().getClass(), String.valueOf(setting.value)));
                                        default:
                                            LogManager.getLogger("ConfigLoader").error(module.name + " what is this ? {}", setting.value);
                                            break;
                                    }
                                } catch (Throwable e) {
                                    LogManager.getLogger("ConfigLoader").error(module.name + " Error", e);
                                }
                            }
                        }
                        module.settings = new ArrayList<>(settings);
                    });
                    if (config.toggled) {
                        module.toggled = true;
                        try {
                            module.Enable();
                            module.onEnable();
                        } catch (NullPointerException e) {
                            LogManager.getLogger("ConfigLoader").error("Failed to load {} configuration", module.name);
                        }
                    }
                    module.keyboard = config.keyboard;
                    module.drawn = config.drawn;
                }
            } catch (Exception e) {
                LogManager.getLogger("ConfigLoader").error("Failed to load {} configuration {}", module.name, e.toString());
            }
        }
        ignores.load();
        friends.load();
        nickName.load();
    }

    private static class IgnoreConfig {
        private final String title;

        public IgnoreConfig(String title) {
            this.title = title;
        }

        public void save() {
            try {
                Gson gson = new Gson();
                JsonWriter writer = new JsonWriter(new FileWriter(String.format("%s/ignore.json", this.title)));
                writer.setIndent("  ");
                gson.toJson(ChatIgnore.INSTANCE.ignore_user, List.class, writer);
                writer.flush();
            } catch (IOException e) {
                ShimejiClient.logger.error("saving config error", e);
            }
        }

        public void load() {
            try {
                Gson gson = new Gson();
                JsonReader reader = new JsonReader(new FileReader(String.format("%s/ignore.json", this.title)));
                ArrayList<String> list = gson.fromJson(reader, List.class);
                if (list != null) {
                    ChatIgnore.INSTANCE.ignore_user = list;
                }

            } catch (IOException e) {
                try {
                    JsonWriter writer = new JsonWriter(new FileWriter(String.format("%s/ignore.json", this.title)));
                    writer.flush();
                } catch (IOException ex) {
                    ShimejiClient.logger.error("createFile config error", ex);
                }
            }
        }
    }

    private static class FriendConfig {
        private final String title;

        public FriendConfig(String title) {
            this.title = title;
        }

        public void save() {
            try {
                Gson gson = new Gson();
                JsonWriter writer = new JsonWriter(new FileWriter(String.format("%s/friend.json", this.title)));
                writer.setIndent("  ");
                gson.toJson(FriendUtil.friends, List.class, writer);
                writer.flush();
            } catch (IOException e) {
                ShimejiClient.logger.error("saving config error", e);
            }
        }

        public void load() {
            try {
                Gson gson = new Gson();
                JsonReader reader = new JsonReader(new FileReader(String.format("%s/friend.json", this.title)));
                ArrayList<String> list = gson.fromJson(reader, List.class);
                if (list != null) {
                    FriendUtil.friends = list;
                }
            } catch (IOException e) {
                try {
                    JsonWriter writer = new JsonWriter(new FileWriter(String.format("%s/friend.json", this.title)));
                    writer.flush();
                } catch (IOException ex) {
                    ShimejiClient.logger.error("createFile config error", ex);
                }
            }
        }
    }

    private static class NickNameConfig {
        private final String title;

        public NickNameConfig(String title) {
            this.title = title;
        }

        public void save() {
            try {
                Gson gson = new Gson();
                JsonWriter writer = new JsonWriter(new FileWriter(String.format("%s/nicknames.json", this.title)));
                writer.setIndent("  ");
                gson.toJson(ShimejiClient.listManager.nicknames, HashMap.class, writer);
                writer.flush();
            } catch (IOException e) {
                ShimejiClient.logger.error("saving config error", e);
            }
        }

        public void load() {
            try {
                Gson gson = new Gson();
                JsonReader reader = new JsonReader(new FileReader(String.format("%s/nicknames.json", this.title)));
                HashMap<UUID, ListManager.Nick> list = gson.fromJson(reader, new TypeToken<HashMap<UUID, ListManager.Nick>>(){}.getType());
                ShimejiClient.listManager.nicknames.putAll(list);
            } catch (IOException e) {
                try {
                    JsonWriter writer = new JsonWriter(new FileWriter(String.format("%s/nicknames.json", this.title)));
                    writer.flush();
                } catch (IOException ex) {
                    ShimejiClient.logger.error("createFile config error", ex);
                }
            }
        }
    }

    public static class Config {
        public Map<String, Setting> settings;
        public boolean toggled;
        public int keyboard;
        public boolean drawn;
    }

    public static class Setting {
        public String type;
        public Object value;

        public Setting(String type, Object value) {
            this.type = type;
            this.value = value;
        }
    }
}
