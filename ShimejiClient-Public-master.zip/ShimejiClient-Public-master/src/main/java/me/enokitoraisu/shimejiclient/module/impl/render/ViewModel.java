package me.enokitoraisu.shimejiclient.module.impl.render;

import me.enokitoraisu.shimejiclient.event.ItemRendererEvent;
import me.enokitoraisu.shimejiclient.event.SideItemRendererEvent;
import me.enokitoraisu.shimejiclient.module.Category;
import me.enokitoraisu.shimejiclient.module.Module;
import me.enokitoraisu.shimejiclient.value.values.FloatValue;
import me.enokitoraisu.shimejiclient.value.values.IntegerValue;
import me.enokitoraisu.shimejiclient.value.values.ModeValue;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.util.EnumHandSide;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import org.lwjgl.input.Keyboard;

@SuppressWarnings("unused")
public class ViewModel extends Module {
    private final ModeValue fov = register(new ModeValue("FovMode", "XY", "XY", "Z"));
    private final FloatValue scalefov = register(new FloatValue("FovScale", 1, 0, 5));

    private final ModeValue page = register(new ModeValue("Page", "Translate", "Translate", "Rotate", "Scale"));

    private final FloatValue transX = register(new FloatValue("TranslateX", 0, -5, 5, v -> page.getValue().equals("Translate")));
    private final FloatValue transY = register(new FloatValue("TranslateY", 0, -5, 5, v -> page.getValue().equals("Translate")));
    private final FloatValue transZ = register(new FloatValue("TranslateZ", 0, -5, 5, v -> page.getValue().equals("Translate")));

    private final IntegerValue rotateX = register(new IntegerValue("RotateX", 0, -360, 360, v -> page.getValue().equals("Rotate")));
    private final IntegerValue rotateY = register(new IntegerValue("RotateY", 0, -360, 360, v -> page.getValue().equals("Rotate")));
    private final IntegerValue rotateZ = register(new IntegerValue("RotateZ", 0, -360, 360, v -> page.getValue().equals("Rotate")));

    private final FloatValue scaleX = register(new FloatValue("ScaleX", 1, 0, 5, v -> page.getValue().equals("Scale")));
    private final FloatValue scaleY = register(new FloatValue("ScaleY", 1, 0, 5, v -> page.getValue().equals("Scale")));
    private final FloatValue scaleZ = register(new FloatValue("ScaleZ", 1, 0, 5, v -> page.getValue().equals("Scale")));

    public ViewModel() {
        super("ViewModel", Category.RENDER, Keyboard.KEY_NONE);
    }

    @SubscribeEvent
    public void onSideItemRenderer(SideItemRendererEvent event) {
        if (event.getHand() == EnumHandSide.LEFT) {
            GlStateManager.translate(transX.getValue(), transY.getValue(), transZ.getValue());
            GlStateManager.scale(scaleX.getValue(), scaleY.getValue(), scaleZ.getValue());
            GlStateManager.rotate(rotateX.getValue(), 1, 0, 0);
            GlStateManager.rotate(rotateY.getValue(), 0, 1, 0);
            GlStateManager.rotate(rotateZ.getValue(), 0, 0, 1);
        }

        if (event.getHand() == EnumHandSide.RIGHT) {
            GlStateManager.translate(-transX.getValue(), transY.getValue(), transZ.getValue());
            GlStateManager.scale(scaleX.getValue(), scaleY.getValue(), scaleZ.getValue());
            GlStateManager.rotate(rotateX.getValue(), 1, 0, 0);
            GlStateManager.rotate(-rotateY.getValue(), 0, 1, 0);
            GlStateManager.rotate(-rotateZ.getValue(), 0, 0, 1);
        }
    }

    @SubscribeEvent
    public void onItemRenderer(ItemRendererEvent event) {
        if (fov.getValue().equals("XY")) GlStateManager.scale(scalefov.getValue(), scalefov.getValue(), 1);
        else if (fov.getValue().equals("Z")) GlStateManager.scale(1, 1, scalefov.getValue());
    }
}
