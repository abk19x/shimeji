package me.enokitoraisu.shimejiclient.module.impl.render;

import me.enokitoraisu.shimejiclient.event.PacketEvent;
import me.enokitoraisu.shimejiclient.module.Category;
import me.enokitoraisu.shimejiclient.module.Module;
import me.enokitoraisu.shimejiclient.utils.entity.PacketUtil;
import me.enokitoraisu.shimejiclient.utils.math.ColorConverter;
import me.enokitoraisu.shimejiclient.utils.math.Easings;
import me.enokitoraisu.shimejiclient.utils.renderer.PlayerModel;
import me.enokitoraisu.shimejiclient.utils.renderer.RenderUtil;
import me.enokitoraisu.shimejiclient.value.values.*;
import net.minecraft.client.entity.AbstractClientPlayer;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.network.play.server.SPacketEntityStatus;
import net.minecraft.util.math.MathHelper;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import org.lwjgl.input.Keyboard;
import org.lwjgl.opengl.GL11;

import java.awt.*;
import java.util.concurrent.CopyOnWriteArrayList;

import static org.lwjgl.opengl.GL11.*;

public class PopChams extends Module {
    private final IntegerValue fadeoutMs = register(new IntegerValue("FadeoutMillis", 1000, 100, 5000));
    private final ColorValue fillColor = register(new ColorValue("FillColor", new Color(0x80FFFFFF)));
    private final BooleanValue line = register(new BooleanValue("Line", true));
    private final ColorValue lineColor = register(new ColorValue("LineColor", new Color(0xFFFFFFFF), v -> line.getValue()));
    private final FloatValue lineWidth = register(new FloatValue("LineWidth", 1.0F, 0.5F, 2.0F, v -> line.getValue()));
    private final BooleanValue smooth = register(new BooleanValue("Smooth", true, v -> line.getValue()));
    private final BooleanValue fadeout = register(new BooleanValue("FadeOut", false));
    private final BooleanValue motion = register(new BooleanValue("Y-Motion", false));
    private final FloatValue height = register(new FloatValue("MotionHeight", 1.0F, -5.0F, 5.0F, v -> motion.getValue()));
    private final ModeValue motionEasing = register(new ModeValue("Motion-Easing", "None", v -> motion.getValue(), "None", "Cubic", "Quad", "Expo", "Sine", "Circ"));
    private final BooleanValue scale = register(new BooleanValue("Scale", false));
    private final ModeValue scaleEasing = register(new ModeValue("Scale-Easing", "None", v -> scale.getValue(), "None", "Cubic", "Quad", "Expo", "Sine", "Circ"));
    private final BooleanValue rotation = register(new BooleanValue("Rotation", false));
    private final ModeValue rotationEasing = register(new ModeValue("Rotation-Easing", "None", v -> rotation.getValue(), "None", "Cubic", "Quad", "Expo", "Sine", "Circ"));
    private final BooleanValue reverse = register(new BooleanValue("Reverse", false, v -> rotation.getValue()));
    private final CopyOnWriteArrayList<PopData> popData = new CopyOnWriteArrayList<>();

    public PopChams() {
        super("PopChams", Category.RENDER, Keyboard.KEY_NONE);
    }

    @SubscribeEvent
    public void onPacketReceived(PacketEvent.Receive event) {
        if (event.getPacket() instanceof SPacketEntityStatus) {
            SPacketEntityStatus packet = (SPacketEntityStatus) event.getPacket();

            if (!fullNullCheck() || packet.getOpCode() != PacketUtil.TOTEM_USE) return;
            mc.addScheduledTask(() -> {
                Entity entity = PacketUtil.getEntityStatusByEntity(packet);
                if (entity instanceof EntityPlayer && entity != mc.player)
                    popData.add(new PopData((EntityPlayer) entity));
            });
        }
    }

    @Override
    public void onRender3D() {
        for (PopData data : popData) {
            glPushAttrib(GL_ALL_ATTRIB_BITS);
            glPushMatrix();
            GlStateManager.disableAlpha();
            GlStateManager.enableBlend();
            glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
            GlStateManager.disableTexture2D();
            GlStateManager.disableDepth();
            GlStateManager.depthMask(false);
            GlStateManager.enableCull();
            GlStateManager.disableLighting();
            if (smooth.getValue()) {
                glEnable(GL_LINE_SMOOTH);
                glHint(GL_LINE_SMOOTH_HINT, GL_NICEST);
            }

            float value = MathHelper.clamp((float) (System.currentTimeMillis() - data.time) / fadeoutMs.getValue(), 0.0F, 1.0F);
            double x = data.posX - mc.getRenderManager().viewerPosX;
            double y = data.posY - mc.getRenderManager().viewerPosY + (motion.getValue() ? height.getValue() * easingValue(motionEasing.getValue(), value) : 0);
            double z = data.posZ - mc.getRenderManager().viewerPosZ;
            int fillColor;
            int lineColor;
            if (fadeout.getValue()) {
                fillColor = new ColorConverter(this.fillColor.getIntValue()).setAlpha((int) ((1 - value) * this.fillColor.getValue().getAlpha()));
                lineColor = new ColorConverter(this.lineColor.getIntValue()).setAlpha((int) ((1 - value) * this.lineColor.getValue().getAlpha()));
            } else {
                fillColor = this.fillColor.getIntValue();
                lineColor = this.lineColor.getIntValue();
            }

            GlStateManager.translate(x, y, z);
            if (scale.getValue()) {
                float scaleValue = easingValue(scaleEasing.getValue(), 1 - value);
                GlStateManager.scale(scaleValue, scaleValue, scaleValue);
            }
            GlStateManager.rotate(data.rotationYaw, 0, 1, 0);
            if (rotation.getValue())
                GlStateManager.rotate(reverse.getValue() ? -360 * easingValue(rotationEasing.getValue(), value) : 360 * easingValue(rotationEasing.getValue(), value), 0, 1, 0);
            GlStateManager.enableRescaleNormal();
            GlStateManager.scale(-1.0F, -1.0F, 1.0F);
            double widthX = data.player.getEntityBoundingBox().maxX - data.player.getRenderBoundingBox().minX + 1;
            double widthZ = data.player.getEntityBoundingBox().maxZ - data.player.getEntityBoundingBox().minZ + 1;
            GlStateManager.scale(widthX, data.player.height, widthZ);
            GlStateManager.translate(0.0F, -1.501F, 0.0F);
            RenderUtil.setColor(fillColor);
            GL11.glPolygonMode(GL11.GL_FRONT_AND_BACK, GL11.GL_FILL);
            data.model.render(0.0625f);
            if (line.getValue()) {
                RenderUtil.setColor(lineColor);
                GL11.glLineWidth(lineWidth.getValue());
                GL11.glPolygonMode(GL11.GL_FRONT_AND_BACK, GL11.GL_LINE);
                data.model.render(0.0625f);
            }
            if (smooth.getValue())
                glDisable(GL_LINE_SMOOTH);
            GlStateManager.enableLighting();
            GlStateManager.enableTexture2D();
            GlStateManager.disableBlend();
            GlStateManager.enableAlpha();
            GlStateManager.enableDepth();
            GlStateManager.depthMask(true);
            GlStateManager.cullFace(GlStateManager.CullFace.BACK);
            glPopMatrix();
            glPopAttrib();
        }

        popData.removeIf(data -> System.currentTimeMillis() - data.time >= fadeoutMs.getValue());
    }

    public float easingValue(String mode, float value) {
        switch (mode) {
            case "Cubic":
                return (float) Easings.cubicOut(value);
            case "Quad":
                return (float) Easings.quadOut(value);
            case "Expo":
                return (float) Easings.expoOut(value);
            case "Sine":
                return (float) Easings.sineOut(value);
            case "Circ":
                return (float) Easings.circOut(value);
            case "None":
            default:
                return value;
        }
    }

    public static class PopData {
        public final EntityPlayer player;
        public final long time;
        public final float rotationYaw;
        public final float rotationYawHead;
        public final float rotationPitch;
        public final double posX;
        public final double posY;
        public final double posZ;
        public final double lastTickPosX;
        public final double lastTickPosY;
        public final double lastTickPosZ;
        public final boolean slim;
        public final PlayerModel model;

        public PopData(EntityPlayer player) {
            this.player = player;
            this.time = System.currentTimeMillis();
            this.rotationYaw = player.rotationYaw;
            this.rotationYawHead = player.rotationYawHead;
            this.rotationPitch = player.rotationPitch;
            this.posX = player.posX;
            this.posY = player.posY - (player.isSneaking() ? 0.125 : 0);
            this.posZ = player.posZ;
            this.lastTickPosX = player.lastTickPosX;
            this.lastTickPosY = player.lastTickPosY;
            this.lastTickPosZ = player.lastTickPosZ;
            this.slim = player instanceof AbstractClientPlayer && ((AbstractClientPlayer) player).getSkinType().equals("slim");
            this.model = new PlayerModel(player, slim, 0);
            this.model.disableArmorLayers();
        }
    }
}
