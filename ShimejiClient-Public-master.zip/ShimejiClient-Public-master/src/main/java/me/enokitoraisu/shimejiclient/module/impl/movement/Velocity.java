package me.enokitoraisu.shimejiclient.module.impl.movement;

import me.enokitoraisu.shimejiclient.event.PacketEvent;
import me.enokitoraisu.shimejiclient.mixin.AccessorSPacketExplosion;
import me.enokitoraisu.shimejiclient.module.Category;
import me.enokitoraisu.shimejiclient.module.Module;
import net.minecraft.network.play.server.SPacketEntityVelocity;
import net.minecraft.network.play.server.SPacketExplosion;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import org.lwjgl.input.Keyboard;

@SuppressWarnings("unused")
public class Velocity extends Module {
    public Velocity() {
        super("Velocity", Category.MOVEMENT, Keyboard.KEY_NONE);
    }

    @SubscribeEvent
    public void onPacket(PacketEvent.Receive event) {
        if (!fullNullCheck()) return;
        if (event.getPacket() instanceof SPacketEntityVelocity) {
            SPacketEntityVelocity entityVelocity = (SPacketEntityVelocity) event.getPacket();
            if (entityVelocity.getEntityID() == mc.player.getEntityId())
                event.setCanceled(true);
        }

        if (event.getPacket() instanceof SPacketExplosion) {
            AccessorSPacketExplosion explosion = (AccessorSPacketExplosion) event.getPacket();
            explosion.setMotionX(0);
            explosion.setMotionY(0);
            explosion.setMotionZ(0);
        }
    }
}
