package me.enokitoraisu.shimejiclient.gui.shimeji.componet.componets;

import me.enokitoraisu.shimejiclient.gui.shimeji.componet.Component;
import me.enokitoraisu.shimejiclient.utils.math.MathUtil;
import me.enokitoraisu.shimejiclient.utils.renderer.RenderUtil;
import me.enokitoraisu.shimejiclient.utils.renderer.font.FontUtil;
import me.enokitoraisu.shimejiclient.value.values.KeyValue;
import org.lwjgl.input.Keyboard;

public class KeyButton extends Component {
    private final KeyValue keyValue;
    private boolean isWaiting = false;

    public KeyButton(KeyValue keyValue, int x, int width, int height) {
        this.keyValue = keyValue;
        this.x = x;
        this.width = width;
        this.height = height;
    }

    @Override
    public void drawScreen(int mouseX, int mouseY, int offsetY) {
        this.visible = true;
        this.y = offsetY;

        RenderUtil.drawRect(x, offsetY, width, height, 0xCB191919);

        if (bounding(mouseX, mouseY)) RenderUtil.drawRect(x, offsetY, width, height, 0x40000000);

        if (this.isWaiting)
            FontUtil.sfui18.drawStringWithShadow("PressKey...", x + 5, offsetY + (height - FontUtil.sfui18.getHeight()) / 2f, -1);
        else
            FontUtil.sfui18.drawStringWithShadow(String.format("%s: %s", keyValue.getName(), MathUtil.toTitleCase(Keyboard.getKeyName(keyValue.getValue()))), x + 5, offsetY + (height - FontUtil.sfui18.getHeight()) / 2f, -1);
    }

    @Override
    public void mouseClicked(int mouseX, int mouseY, int mouseButton) {
        if (mouseButton == 0) {
            if (bounding(mouseX, mouseY)) isWaiting = !isWaiting;
            else isWaiting = false;
        }
    }

    @Override
    public void keyTyped(char typedChar, int keyCode) {
        if (isWaiting) {
            if (Keyboard.getEventKey() == Keyboard.KEY_DELETE) keyValue.setValue(Keyboard.KEY_NONE);
            else keyValue.setValue(Keyboard.getEventKey());
            isWaiting = false;
        }
    }
}