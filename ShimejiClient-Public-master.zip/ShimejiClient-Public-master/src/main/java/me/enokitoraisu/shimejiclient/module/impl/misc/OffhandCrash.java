package me.enokitoraisu.shimejiclient.module.impl.misc;

import me.enokitoraisu.shimejiclient.module.Category;
import me.enokitoraisu.shimejiclient.module.Module;
import me.enokitoraisu.shimejiclient.value.values.IntegerValue;
import net.minecraft.network.play.client.CPacketPlayer;
import net.minecraft.network.play.client.CPacketPlayerDigging;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.math.BlockPos;
import org.lwjgl.input.Keyboard;

@SuppressWarnings("unused")
public class OffhandCrash extends Module {
    private final IntegerValue amount = register(new IntegerValue("Amount", 500, 100, 3000));

    public OffhandCrash() {
        super("OffhandCrash", Category.MISC, Keyboard.KEY_NONE);
    }

    @Override
    public void onTick() {
        if (mc.player.inventory.offHandInventory.get(0).isEmpty() && mc.player.inventory.getStackInSlot(mc.player.inventory.currentItem).isEmpty()) return;
        new Thread(() -> {
            try {
                for (int i = 0; i < amount.getValue(); i++) {
                    mc.player.connection.sendPacket(new CPacketPlayerDigging(CPacketPlayerDigging.Action.SWAP_HELD_ITEMS, BlockPos.ORIGIN, EnumFacing.UP));
                    mc.player.connection.sendPacket(new CPacketPlayer(true));
                }
            } catch (NullPointerException e) {
                e.printStackTrace();
            }
        }).start();
    }
}
