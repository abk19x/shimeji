package me.enokitoraisu.shimejiclient.value.values;

import me.enokitoraisu.shimejiclient.utils.game.MouseUtil;
import me.enokitoraisu.shimejiclient.value.ValueBase;
import org.lwjgl.input.Keyboard;
import org.lwjgl.input.Mouse;

import java.util.function.Predicate;

public class KeyValue extends ValueBase<Integer> {
    public KeyValue(String name, Integer value) {
        this(name, value, v -> true);
    }

    public KeyValue(String name, Integer key, Predicate<Integer> visibility) {
        super(name, key, visibility);
    }

    public boolean isKeyDown() {
        if (getValue() > -1) {
            return Keyboard.isKeyDown(getValue());
        } else if (getValue() < -1) {
            return Mouse.isButtonDown(MouseUtil.convertToMouse(getValue()));
        }
        return false;
    }
}