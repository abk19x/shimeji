package me.enokitoraisu.shimejiclient.event;

import net.minecraft.client.entity.AbstractClientPlayer;
import net.minecraft.item.ItemStack;
import net.minecraft.util.EnumHand;

public class ItemRendererEvent extends EventManager {
    private final AbstractClientPlayer player;
    private final float p_187457_2_;
    private final float p_187457_3_;
    private final EnumHand hand;
    private final float p_187457_5_;
    private final ItemStack stack;
    private final float p_187457_7_;

    public ItemRendererEvent(AbstractClientPlayer player, float p_187457_2_, float p_187457_3_, EnumHand hand, float p_187457_5_, ItemStack stack, float p_187457_7_) {
        this.player = player;
        this.p_187457_2_ = p_187457_2_;
        this.p_187457_3_ = p_187457_3_;
        this.hand = hand;
        this.p_187457_5_ = p_187457_5_;
        this.stack = stack;
        this.p_187457_7_ = p_187457_7_;
    }

    public AbstractClientPlayer getPlayer() {
        return player;
    }

    public float getP_187457_2_() {
        return p_187457_2_;
    }

    public float getP_187457_3_() {
        return p_187457_3_;
    }

    public EnumHand getHand() {
        return hand;
    }

    public float getP_187457_5_() {
        return p_187457_5_;
    }

    public ItemStack getStack() {
        return stack;
    }

    public float getP_187457_7_() {
        return p_187457_7_;
    }
}
