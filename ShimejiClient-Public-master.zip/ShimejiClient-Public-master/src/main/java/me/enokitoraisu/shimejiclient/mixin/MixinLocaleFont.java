package me.enokitoraisu.shimejiclient.mixin;

import net.minecraft.client.resources.Locale;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(Locale.class)
public class MixinLocaleFont {
    @Inject(method = "checkUnicode()V", at = @At(value = "HEAD"), cancellable = true)
    public void checkUnicode(CallbackInfo ci) {
        ci.cancel();
    }
}