package me.enokitoraisu.shimejiclient.module.impl.player;

import me.enokitoraisu.shimejiclient.module.Category;
import me.enokitoraisu.shimejiclient.module.Module;
import me.enokitoraisu.shimejiclient.utils.entity.BlockUtil;
import me.enokitoraisu.shimejiclient.utils.entity.EntityUtil;
import me.enokitoraisu.shimejiclient.utils.entity.InventoryUtil;
import me.enokitoraisu.shimejiclient.utils.game.DisplayUtil;
import me.enokitoraisu.shimejiclient.utils.math.MathUtil;
import me.enokitoraisu.shimejiclient.utils.renderer.RenderUtil;
import me.enokitoraisu.shimejiclient.value.values.BooleanValue;
import net.minecraft.block.Block;
import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemStack;
import net.minecraft.network.play.client.CPacketPlayer;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import org.lwjgl.input.Keyboard;

@SuppressWarnings("unused")
public class Scaffold extends Module {
    public BooleanValue rotation = register(new BooleanValue("Rotate", false));
    public BooleanValue swing = register(new BooleanValue("Swing", true));

    public Scaffold() {
        super("Scaffold", Category.PLAYER, Keyboard.KEY_NONE);
    }

    @Override
    public void onTick() {
        BlockPos playerBlock;
        if (BlockUtil.isScaffoldPos((playerBlock = EntityUtil.getPlayerPosWithEntity()).add(0, -1, 0))) {
            if (BlockUtil.isValidBlock(playerBlock.add(0, -2, 0))) place(playerBlock.add(0, -1, 0), EnumFacing.UP);
            else if (BlockUtil.isValidBlock(playerBlock.add(-1, -1, 0)))
                place(playerBlock.add(0, -1, 0), EnumFacing.EAST);
            else if (BlockUtil.isValidBlock(playerBlock.add(1, -1, 0)))
                place(playerBlock.add(0, -1, 0), EnumFacing.WEST);
            else if (BlockUtil.isValidBlock(playerBlock.add(0, -1, -1)))
                place(playerBlock.add(0, -1, 0), EnumFacing.SOUTH);
            else if (BlockUtil.isValidBlock(playerBlock.add(0, -1, 1)))
                place(playerBlock.add(0, -1, 0), EnumFacing.NORTH);
            else if (BlockUtil.isValidBlock(playerBlock.add(1, -1, 1))) {
                if (BlockUtil.isValidBlock(playerBlock.add(0, -1, 1)))
                    place(playerBlock.add(0, -1, 1), EnumFacing.NORTH);
                place(playerBlock.add(1, -1, 1), EnumFacing.EAST);
            } else if (BlockUtil.isValidBlock(playerBlock.add(-1, -1, 1))) {
                if (BlockUtil.isValidBlock(playerBlock.add(-1, -1, 0)))
                    place(playerBlock.add(0, -1, 1), EnumFacing.WEST);
                place(playerBlock.add(-1, -1, 1), EnumFacing.SOUTH);
            } else if (BlockUtil.isValidBlock(playerBlock.add(1, -1, 1))) {
                if (BlockUtil.isValidBlock(playerBlock.add(0, -1, 1)))
                    place(playerBlock.add(0, -1, 1), EnumFacing.SOUTH);
                place(playerBlock.add(1, -1, 1), EnumFacing.WEST);
            } else if (BlockUtil.isValidBlock(playerBlock.add(1, -1, 1))) {
                if (BlockUtil.isValidBlock(playerBlock.add(0, -1, 1)))
                    place(playerBlock.add(0, -1, 1), EnumFacing.EAST);
                place(playerBlock.add(1, -1, 1), EnumFacing.NORTH);
            }
        }
    }

    @Override
    public void onRender2D() {
        int newSlot = -1;
        for (int i = 0; i < 9; ++i) {
            ItemStack stack = mc.player.inventory.getStackInSlot(i);
            if (InventoryUtil.isNull(stack) || !(stack.getItem() instanceof ItemBlock) || !Block.getBlockFromItem(stack.getItem()).getDefaultState().isFullBlock())
                continue;
            newSlot = i;
            break;
        }

        if (newSlot != -1)
            RenderUtil.renderItem(mc.player.inventory.getStackInSlot(newSlot), DisplayUtil.getWidth() / 2, DisplayUtil.getHeight() / 2);
    }

    public void place(BlockPos pos, EnumFacing facing) {
        if (facing == EnumFacing.UP) pos = pos.add(0, -1, 0);
        else if (facing == EnumFacing.NORTH) pos = pos.add(0, 0, 1);
        else if (facing == EnumFacing.SOUTH) pos = pos.add(0, 0, -1);
        else if (facing == EnumFacing.EAST) pos = pos.add(-1, 0, 0);
        else if (facing == EnumFacing.WEST) pos = pos.add(1, 0, 0);

        int oldSlot = mc.player.inventory.currentItem;
        int newSlot = -1;
        for (int i = 0; i < 9; ++i) {
            ItemStack stack = mc.player.inventory.getStackInSlot(i);
            if (InventoryUtil.isNull(stack) || !(stack.getItem() instanceof ItemBlock) || !Block.getBlockFromItem(stack.getItem()).getDefaultState().isFullBlock())
                continue;
            newSlot = i;
            break;
        }

        if (newSlot != -1) {
            if (this.rotation.getValue()) {
                float[] angle = MathUtil.calcAngle(mc.player.getPositionEyes(mc.getRenderPartialTicks()), new Vec3d((float) pos.getX() + 0.5f, (float) pos.getY() - 0.5f, (float) pos.getZ() + 0.5f));
                mc.player.connection.sendPacket(new CPacketPlayer.Rotation(angle[0], (float) MathHelper.normalizeAngle((int) angle[1], 360), mc.player.onGround));
                mc.player.rotationYawHead = angle[0];
            }

            InventoryUtil.switchToSlot(newSlot, false);
            mc.playerController.processRightClickBlock(mc.player, mc.world, pos, facing, new Vec3d(0.5, 0.5, 0.5), EnumHand.MAIN_HAND);
            if (swing.getValue()) mc.player.swingArm(EnumHand.MAIN_HAND);
            InventoryUtil.switchToSlot(oldSlot, false);
        }
    }
}
