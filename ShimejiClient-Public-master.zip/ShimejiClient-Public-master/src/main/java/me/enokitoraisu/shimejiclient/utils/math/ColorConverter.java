package me.enokitoraisu.shimejiclient.utils.math;

public class ColorConverter {
    private int color;

    public ColorConverter(int color) {
        this.color = color;
    }

    public int setRed(int value) {
        if (value >= 255) value = 255;
        if (value < 0) value = 0;
        return setColor(ColorUtil.toRGBA(value, getGreen(), getBlue(), getAlpha()));
    }

    public int setGreen(int value) {
        if (value >= 255) value = 255;
        if (value < 0) value = 0;
        return setColor(ColorUtil.toRGBA(getRed(), value, getBlue(), getAlpha()));
    }

    public int setBlue(int value) {
        if (value >= 255) value = 255;
        if (value < 0) value = 0;
        return setColor(ColorUtil.toRGBA(getRed(), getGreen(), value, getAlpha()));
    }

    public int setAlpha(int value) {
        if (value >= 255) value = 255;
        if (value < 0) value = 0;
        return setColor(ColorUtil.toRGBA(getRed(), getGreen(), getBlue(), value));
    }

    public int getRed() {
        return color >> 16 & 255;
    }

    public int getGreen() {
        return color >> 8 & 255;
    }

    public int getBlue() {
        return color & 255;
    }

    public int getAlpha() {
        return color >> 24 & 255;
    }

    public int setColor(int color) {
        return this.color = color;
    }

    public int getColor() {
        return color;
    }
}
