package me.enokitoraisu.shimejiclient.gui.shimeji.componet.componets;

import me.enokitoraisu.shimejiclient.gui.shimeji.Panel;
import me.enokitoraisu.shimejiclient.gui.shimeji.componet.Component;
import me.enokitoraisu.shimejiclient.utils.animation.Animate;
import me.enokitoraisu.shimejiclient.utils.animation.Easing;
import me.enokitoraisu.shimejiclient.utils.math.ColorConverter;
import me.enokitoraisu.shimejiclient.utils.math.ColorUtil;
import me.enokitoraisu.shimejiclient.utils.renderer.RenderUtil;
import me.enokitoraisu.shimejiclient.utils.renderer.font.FontUtil;
import me.enokitoraisu.shimejiclient.value.values.ColorValue;
import org.lwjgl.opengl.GL11;

import java.awt.*;

public class HSBButton extends Component {
    private final ColorValue colorValue;
    private final Animate animate = new Animate();
    private boolean isOpening = false;
    private float hue, saturation, brightness, alpha;
    private boolean hueClicked, pickerClicked, alphaClicked;

    public HSBButton(ColorValue colorValue, int x, int width, int height) {
        this.colorValue = colorValue;
        this.x = x;
        this.width = width;
        this.height = height;
        Color color = colorValue.getValue();
        this.hue = ColorUtil.getHSB(color.getRed() / 255f, color.getGreen() / 255f, color.getBlue() / 255f)[0];
        this.saturation = ColorUtil.getHSB(color.getRed() / 255f, color.getGreen() / 255f, color.getBlue() / 255f)[1];
        this.brightness = ColorUtil.getHSB(color.getRed() / 255f, color.getGreen() / 255f, color.getBlue() / 255f)[2];
        if (colorValue.isEnableAlpha()) this.alpha = colorValue.getValue().getAlpha() / 255f;
    }

    /*
    Old Color Picker

    public static void drawSB(int x, int y, int width, int height, int color) {
        float red = (float) (color >> 16 & 0xFF) / 255.0f;
        float green = (float) (color >> 8 & 0xFF) / 255.0f;
        float blue = (float) (color & 0xFF) / 255.0f;

        GlStateManager.disableTexture2D();
        GlStateManager.enableBlend();
        GlStateManager.disableAlpha();
        GlStateManager.tryBlendFuncSeparate(GlStateManager.SourceFactor.SRC_ALPHA, GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA, GlStateManager.SourceFactor.ONE, GlStateManager.DestFactor.ZERO);
        GlStateManager.shadeModel(7425);
        Tessellator tessellator = Tessellator.getInstance();
        BufferBuilder bufferBuilder = tessellator.getBuffer();
        bufferBuilder.begin(7, DefaultVertexFormats.POSITION_COLOR);
        bufferBuilder.pos(x, y, 0.0).color(255, 255, 255, 255).endVertex();
        bufferBuilder.pos(x, y + height, 0.0).color(0, 0, 0, 255).endVertex();
        bufferBuilder.pos(x + width, y + height, 0.0).color(0, 0, 0, 255).endVertex();
        bufferBuilder.pos(x + width, y, 0.0).color(red, green, blue, 1f).endVertex();
        tessellator.draw();
        GlStateManager.shadeModel(7424);
        GlStateManager.disableBlend();
        GlStateManager.enableAlpha();
        GlStateManager.enableTexture2D();
    }
     */

    public static void drawBetterPicker(int x, int y, int width, int height, float hue) {
        for (int i = 0; i < width; i++) {
            float saturation = (float) i / (float) width;
            for (int j = 0; j < height; j++) {
                float brightness = 1 - (float) j / (float) height;
                RenderUtil.drawRect(x + i, y + j, 1, 1, Color.HSBtoRGB(hue, saturation, brightness));
            }
        }
    }

    public static void transparentBackground(float x, float y, float width, float height) {
        float pixelSize = height / 2;

        for (float i = 0; i < width; i += pixelSize) {
            if (i / pixelSize % 2 == 1) {
                if (i + pixelSize > width) {
                    RenderUtil.drawRect(x + i, y, pixelSize + (width - pixelSize - i), pixelSize, new Color(0xFFBABABA).hashCode());
                    RenderUtil.drawRect(x + i, y + pixelSize, pixelSize + (width - pixelSize - i), pixelSize, new Color(0xFFFFFFFF).hashCode());
                } else {
                    RenderUtil.drawRect(x + i, y, pixelSize, pixelSize, new Color(0xFFBABABA).hashCode());
                    RenderUtil.drawRect(x + i, y + pixelSize, pixelSize, pixelSize, new Color(0xFFFFFFFF).hashCode());
                }
            } else {
                if (i + pixelSize > width) {
                    RenderUtil.drawRect(x + i, y, pixelSize + (width - pixelSize - i), pixelSize, new Color(0xFFFFFFFF).hashCode());
                    RenderUtil.drawRect(x + i, y + pixelSize, pixelSize + (width - pixelSize - i), pixelSize, new Color(0xFFBABABA).hashCode());
                } else {
                    RenderUtil.drawRect(x + i, y, pixelSize, pixelSize, new Color(0xFFFFFFFF).hashCode());
                    RenderUtil.drawRect(x + i, y + pixelSize, pixelSize, pixelSize, new Color(0xFFBABABA).hashCode());
                }
            }
        }
    }

    @Override
    public void drawScreen(int mouseX, int mouseY, int offsetY) {
        this.visible = this.colorValue.getVisibility();
        if (this.visible) {
            this.y = offsetY;
            RenderUtil.drawRect(this.x, offsetY, this.width, this.height, 0xCB191919);

            if (bounding(mouseX, mouseY))
                RenderUtil.drawRect(x, offsetY, width, height, 0x40000000);

            FontUtil.sfui18.drawStringWithShadow(String.format("\u00A7f%s \u00A7r#%s", colorValue.getName(), Integer.toHexString(colorValue.getIntValue())), x + 5, offsetY + (height / 2f - FontUtil.sfui18.getHeight() / 2f), new ColorConverter(colorValue.getIntValue()).setAlpha(255));

            FontUtil.sfui18.drawStringWithShadow(
                    "...",
                    (x + width) - (5 + FontUtil.sfui18.getStringWidth("...")),
                    y + height / 2f - FontUtil.sfui18.getHeight() / 2f,
                    -1
            );

            animate.setEase(animate.isReversed() ? Easing.QUINTIC_IN : Easing.QUINTIC_OUT).setMin(0).setMax(100).setSpeed(500).setReversed(!isOpening).update();

            Panel.offset += (height * (colorValue.isEnableAlpha() ? 6 : 5)) * (animate.getValue() / 100);

            if (isOpening || animate.getValue() > 0) {
                GL11.glEnable(GL11.GL_SCISSOR_TEST);
                RenderUtil.glScissor(x, y, width, height + (height * (colorValue.isEnableAlpha() ? 6 : 5) + 0.6f) * (animate.getValue() / 100));

                RenderUtil.drawRect(x, y + height, width, height * (colorValue.isEnableAlpha() ? 6 : 5), 0xCB191919);
                if (bounding(mouseX, mouseY, x, y + height, width, height * (colorValue.isEnableAlpha() ? 6 : 5)))
                    RenderUtil.drawRect(x, y + height, width, height * (colorValue.isEnableAlpha() ? 6 : 5), 0x40000000);

                drawBetterPicker(x + 3, y + height + 3, width - 6, height * 4 - 6, hue);
                float pickedX = (x + 3 + (width - 6) * saturation);
                float pickedY = (y + height + 3 + (height * 4 - 6) * (1.0f - brightness));
                RenderUtil.drawRect(pickedX - 1, pickedY - 1, 2, 2, -1);
                RenderUtil.drawOutLineRect(pickedX - 1, pickedY - 1, 2, 2, 0.5f, 0xFF000000);

                for (int i = 0; i < width - 6; i++) {
                    int color = Color.HSBtoRGB(i / (float) (width - 6), 1, 1);
                    RenderUtil.drawRect(x + 3 + i, y + height * 5, 1, height - 3, color);
                }

                RenderUtil.drawRect((x + 3 + (width - 6) * hue) - 1, (y + height * 5) - 1, 2, height - 1, -1);
                RenderUtil.drawOutLineRect((x + 3 + (width - 6) * hue) - 1, (y + height * 5) - 1, 2, height - 1, 0.5f, 0xFF000000);

                if (colorValue.isEnableAlpha()) {
                    transparentBackground(x + 3, y + height * 6, width - 6, height - 3);
                    RenderUtil.drawGradientRect(x + 3, y + height * 6, width - 6, height - 3, Color.HSBtoRGB(hue, saturation, brightness), new ColorConverter(Color.HSBtoRGB(hue, saturation, brightness)).setAlpha(0));
                    RenderUtil.drawRect((x + 3 + (width - 6) * (1.0f - alpha)) - 1, (y + height * 6) - 1, 2, height - 1, -1);
                    RenderUtil.drawOutLineRect((x + 3 + (width - 6) * (1.0f - alpha)) - 1, (y + height * 6) - 1, 2, height - 1, 0.5f, 0xFF000000);
                }
                GL11.glDisable(GL11.GL_SCISSOR_TEST);

                if (isOpening && visible) {
                    clickMove(mouseX, mouseY);

                    if (colorValue.isEnableAlpha()) {
                        Color color = Color.getHSBColor(hue, saturation, brightness);
                        colorValue.setValue(new Color(color.getRed() / 255F, color.getGreen() / 255F, color.getBlue() / 255F, alpha));
                    } else {
                        colorValue.setValue(Color.getHSBColor(hue, saturation, brightness));
                    }
                }
            }
        }
    }

    @Override
    public void mouseClicked(int mouseX, int mouseY, int mouseButton) {
        if (this.bounding(mouseX, mouseY) && mouseButton == 1) this.isOpening = !this.isOpening;
        if (isOpening && visible) {
            if (this.bounding(mouseX, mouseY, x + 3, y + height * 5, width - 6, height - 3) && mouseButton == 0)
                hueClicked = true;
            if (this.bounding(mouseX, mouseY, x + 3, y + height * 6, width - 6, height - 3) && mouseButton == 0)
                alphaClicked = true;
            if (this.bounding(mouseX, mouseY, x + 3, y + height + 3, width - 6, height * 4 - 6) && mouseButton == 0)
                pickerClicked = true;
        }
    }

    @Override
    public void mouseReleased(int mouseX, int mouseY, int state) {
        hueClicked = false;
        pickerClicked = false;
        alphaClicked = false;
    }

    public void clickMove(int mouseX, int mouseY) {
        if (hueClicked) {
            int hueX = x + 3;
            float hueWidth = width - 6f;
            float value = (mouseX - hueX) / hueWidth;
            if (value > 1.0f) {
                value = 1.0f;
            }
            if (value < 0.0f) {
                value = 0.0f;
            }
            hue = value;
        }

        if (alphaClicked) {
            int alphaX = x + 3;
            float alphaWidth = width - 6f;
            float value = 1.0f - (mouseX - alphaX) / alphaWidth;
            if (value > 1.0f) {
                value = 1.0f;
            }
            if (value < 0.0f) {
                value = 0.0f;
            }
            alpha = value;
        }

        if (pickerClicked) {
            float saturationX = x + 3f;
            float saturationWidth = width - 6f;
            float value = (mouseX - saturationX) / saturationWidth;
            if (value > 1.0f) {
                value = 1.0f;
            }
            if (value < 0.0f) {
                value = 0.0f;
            }
            saturation = value;
        }

        if (pickerClicked) {
            float brightnessY = y + height + 3f;
            float brightnessHeight = height * 4 - 6;
            float value = 1.0f - (mouseY - brightnessY) / brightnessHeight;
            if (value > 1.0f) {
                value = 1.0f;
            }
            if (value < 0.0f) {
                value = 0.0f;
            }
            brightness = value;
        }
    }
}
