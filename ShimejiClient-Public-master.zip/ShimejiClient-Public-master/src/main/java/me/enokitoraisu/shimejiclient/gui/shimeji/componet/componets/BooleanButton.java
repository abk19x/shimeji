package me.enokitoraisu.shimejiclient.gui.shimeji.componet.componets;

import me.enokitoraisu.shimejiclient.gui.GuiSetting;
import me.enokitoraisu.shimejiclient.gui.shimeji.componet.Component;
import me.enokitoraisu.shimejiclient.utils.renderer.RenderUtil;
import me.enokitoraisu.shimejiclient.utils.renderer.font.FontUtil;
import me.enokitoraisu.shimejiclient.value.values.BooleanValue;

public class BooleanButton extends Component {
    public BooleanValue booleanValue;

    public BooleanButton(BooleanValue booleanValue, int x, int width, int height) {
        this.booleanValue = booleanValue;
        this.x = x;
        this.width = width;
        this.height = height;
    }

    @Override
    public void drawScreen(int mouseX, int mouseY, int offsetY) {
        this.visible = this.booleanValue.getVisibility();
        if (this.visible) {
            this.y = offsetY;
            RenderUtil.drawRect(x, offsetY, width, height, 0xCB191919);

            if (bounding(mouseX, mouseY))
                RenderUtil.drawRect(x, offsetY, width, height, 0x40000000);

            RenderUtil.drawOutLineRect(x + 5, offsetY + 2, height - 4, height - 4, 0.5f, -1);
            if (booleanValue.getValue())
                RenderUtil.drawRect(x + 6, offsetY + 3, height - 6, height - 6, GuiSetting.getAccent());

            FontUtil.sfui18.drawStringWithShadow(booleanValue.getName(), x + 6 + (this.height - 2), offsetY + (height - FontUtil.sfui18.getHeight()) / 2f, -1);
        }
    }

    @Override
    public void mouseClicked(int mouseX, int mouseY, int mouseButton) {
        if (visible) {
            if (bounding(mouseX, mouseY) && mouseButton == 0) {
                booleanValue.setValue(!booleanValue.getValue());
            }
        }
    }
}
