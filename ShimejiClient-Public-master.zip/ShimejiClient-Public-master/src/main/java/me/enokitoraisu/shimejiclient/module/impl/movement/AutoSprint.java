package me.enokitoraisu.shimejiclient.module.impl.movement;

import me.enokitoraisu.shimejiclient.module.Category;
import me.enokitoraisu.shimejiclient.module.Module;
import org.lwjgl.input.Keyboard;

@SuppressWarnings("unused")
public class AutoSprint extends Module {
    public AutoSprint() {
        super("AutoSprint", Category.MOVEMENT, Keyboard.KEY_NONE);
    }

    @Override
    public void onTick() {
        if (mc.player.moveForward > 0) {
            mc.player.setSprinting(true);
        }
    }
}
