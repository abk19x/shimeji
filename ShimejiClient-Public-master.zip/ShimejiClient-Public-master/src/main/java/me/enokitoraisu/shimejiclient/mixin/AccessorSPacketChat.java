package me.enokitoraisu.shimejiclient.mixin;

import net.minecraft.network.play.server.SPacketChat;
import net.minecraft.util.text.ChatType;
import net.minecraft.util.text.ITextComponent;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(SPacketChat.class)
public interface AccessorSPacketChat {
    @Accessor("chatComponent")
    void setChatComponent(ITextComponent component);

    @Accessor("chatComponent")
    ITextComponent getChatComponent();

    @Accessor("type")
    void setType(ChatType component);

    @Accessor("type")
    ChatType getType();
}
