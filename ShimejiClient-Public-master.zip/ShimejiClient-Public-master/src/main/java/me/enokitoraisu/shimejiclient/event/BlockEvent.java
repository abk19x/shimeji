package me.enokitoraisu.shimejiclient.event;

import net.minecraft.util.math.BlockPos;

public class BlockEvent {
    public static class Place extends EventManager {
        private final BlockPos eventPos;

        public Place(BlockPos eventPos) {
            this.eventPos = eventPos;
        }

        public BlockPos getPos() {
            return eventPos;
        }
    }

    public static class Break extends EventManager {
        private final BlockPos eventPos;

        public Break(BlockPos eventPos) {
            this.eventPos = eventPos;
        }

        public BlockPos getPos() {
            return eventPos;
        }
    }

    public static class Damage extends EventManager {
        private final BlockPos eventPos;

        public Damage(BlockPos eventPos) {
            this.eventPos = eventPos;
        }

        public BlockPos getEventPos() {
            return eventPos;
        }
    }
}
