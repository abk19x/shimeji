package me.enokitoraisu.shimejiclient.module.impl.player;

import me.enokitoraisu.shimejiclient.module.Category;
import me.enokitoraisu.shimejiclient.module.Module;
import me.enokitoraisu.shimejiclient.utils.entity.BlockUtil;
import me.enokitoraisu.shimejiclient.utils.entity.InventoryUtil;
import me.enokitoraisu.shimejiclient.value.values.BooleanValue;
import me.enokitoraisu.shimejiclient.value.values.IntegerValue;
import me.enokitoraisu.shimejiclient.value.values.ModeValue;
import net.minecraft.block.BlockAir;
import net.minecraft.item.ItemBlock;
import net.minecraft.network.play.client.CPacketPlayer;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;
import org.lwjgl.input.Keyboard;

@SuppressWarnings("unused")
public class AutoTunnel extends Module {
    public ModeValue mode = register(new ModeValue("Mode", "Baritone", "Baritone", "Client"));
    private final BooleanValue rotate = register(new BooleanValue("Rotate", false, v -> mode.getValue().equals("Client")));
    private final BooleanValue size = register(new BooleanValue("TunnelSize", false, v -> mode.getValue().equals("Baritone")));
    private final IntegerValue height = register(new IntegerValue("Height", 2, 2, 5, v -> mode.getValue().equals("Baritone") && size.getValue()));
    private final IntegerValue width = register(new IntegerValue("Width", 1, 1, 5, v -> mode.getValue().equals("Baritone") && size.getValue()));
    private final IntegerValue depth = register(new IntegerValue("Depth", 100, 1, 1000, v -> mode.getValue().equals("Baritone") && size.getValue()));

    public AutoTunnel() {
        super("AutoTunnel", Category.PLAYER, Keyboard.KEY_NONE);
    }

    @Override
    public void onEnable() {
        if (mode.getValue().equalsIgnoreCase("Baritone") && fullNullCheck()) {
            if (size.getValue())
                mc.player.sendChatMessage(String.format("#tunnel %s %s %s", height.getValue(), width.getValue(), depth.getValue()));
            else
                mc.player.sendChatMessage("#tunnel");
        }
    }

    @Override
    public void onDisable() {
        if (mode.getValue().equalsIgnoreCase("Baritone")) mc.player.sendChatMessage("#stop");
    }

    @Override
    public void onTick() {
        if (mode.getValue().equalsIgnoreCase("Client")) {
            BlockPos playerPos = BlockUtil.floorPos(mc.player);
            EnumFacing playerFacing = mc.player.getHorizontalFacing();

            BlockPos blockPos = playerPos.offset(playerFacing);
            BlockPos blockPosAbove = blockPos.up();

            BlockPos blockPosOffset = blockPos.offset(playerFacing);
            BlockPos blockPosAboveOffset = blockPosOffset.up();

            if (!(mc.world.getBlockState(blockPosAbove).getBlock() instanceof BlockAir)) {
                if (rotate.getValue())
                    mc.player.connection.sendPacket(new CPacketPlayer.Rotation(BlockUtil.getLegitRotations(blockPosAbove)[0], BlockUtil.getLegitRotations(blockPosAbove)[1], mc.player.onGround));
                mc.player.swingArm(EnumHand.MAIN_HAND);
                mc.playerController.onPlayerDamageBlock(blockPosAbove, playerFacing);
            } else if (!(mc.world.getBlockState(blockPos).getBlock() instanceof BlockAir)) {
                if (rotate.getValue())
                    mc.player.connection.sendPacket(new CPacketPlayer.Rotation(BlockUtil.getLegitRotations(blockPos)[0], BlockUtil.getLegitRotations(blockPos)[1], mc.player.onGround));
                mc.player.swingArm(EnumHand.MAIN_HAND);
                mc.playerController.onPlayerDamageBlock(blockPos, playerFacing);
            } else if (!(mc.world.getBlockState(blockPosAboveOffset).getBlock() instanceof BlockAir)) {
                if (rotate.getValue())
                    mc.player.connection.sendPacket(new CPacketPlayer.Rotation(BlockUtil.getLegitRotations(blockPosAboveOffset)[0], BlockUtil.getLegitRotations(blockPosAboveOffset)[1], mc.player.onGround));
                mc.player.swingArm(EnumHand.MAIN_HAND);
                mc.playerController.onPlayerDamageBlock(blockPosAboveOffset, playerFacing);
            } else if (!(mc.world.getBlockState(blockPosOffset).getBlock() instanceof BlockAir)) {
                if (rotate.getValue())
                    mc.player.connection.sendPacket(new CPacketPlayer.Rotation(BlockUtil.getLegitRotations(blockPosOffset)[0], BlockUtil.getLegitRotations(blockPosOffset)[1], mc.player.onGround));
                mc.player.swingArm(EnumHand.MAIN_HAND);
                mc.playerController.onPlayerDamageBlock(blockPosOffset, playerFacing);
            } else if (mc.world.getBlockState(blockPos.down().offset(playerFacing)).getMaterial().isReplaceable()) {
                int slot = InventoryUtil.findHotbarBlock(ItemBlock.class);
                if (slot != -1) {
                    int oldSlot = mc.player.inventory.currentItem;
                    InventoryUtil.switchToSlot(slot, false);
                    if (rotate.getValue())
                        mc.player.connection.sendPacket(new CPacketPlayer.Rotation(BlockUtil.getLegitRotations(blockPos.down().offset(playerFacing))[0], BlockUtil.getLegitRotations(blockPos.down().offset(playerFacing))[1], mc.player.onGround));
                    BlockUtil.placeBlock(blockPos.down().offset(playerFacing), EnumHand.MAIN_HAND, false, false, mc.player.isSneaking());
                    InventoryUtil.switchToSlot(oldSlot, false);
                }
            }

            if (rotate.getValue())
                mc.player.connection.sendPacket(new CPacketPlayer.Rotation(mc.player.rotationYaw, mc.player.rotationPitch, mc.player.onGround));
        }
    }
}