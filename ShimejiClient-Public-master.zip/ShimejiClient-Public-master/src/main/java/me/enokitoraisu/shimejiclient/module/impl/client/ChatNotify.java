package me.enokitoraisu.shimejiclient.module.impl.client;

import me.enokitoraisu.shimejiclient.module.Category;
import me.enokitoraisu.shimejiclient.module.Module;
import org.lwjgl.input.Keyboard;

@SuppressWarnings("unused")
public class ChatNotify extends Module {
    public static ChatNotify INSTANCE = new ChatNotify();

    public ChatNotify() {
        super("ChatNotify", Category.CLIENT, Keyboard.KEY_NONE);
        INSTANCE = this;
    }
}
