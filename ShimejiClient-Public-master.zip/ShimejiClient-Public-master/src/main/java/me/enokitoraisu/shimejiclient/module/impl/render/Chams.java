package me.enokitoraisu.shimejiclient.module.impl.render;

import me.enokitoraisu.shimejiclient.module.Category;
import me.enokitoraisu.shimejiclient.module.Module;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.OpenGlHelper;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraftforge.client.event.RenderLivingEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import org.lwjgl.input.Keyboard;
import org.lwjgl.opengl.GL11;

public class Chams extends Module {
    public Chams() {
        super("Chams", Category.RENDER, Keyboard.KEY_NONE);
    }


    @SubscribeEvent
    public void onRenderLivingPre(RenderLivingEvent.Pre<EntityPlayer> event) {
        if (event.getEntity() instanceof EntityPlayer) {
            mc.getRenderManager().setRenderShadow(false);
            mc.getRenderManager().setRenderOutlines(false);
            GlStateManager.pushMatrix();
            GlStateManager.depthMask(true);
            OpenGlHelper.setLightmapTextureCoords(OpenGlHelper.lightmapTexUnit, 240.0F, 240.0F);
            GL11.glEnable(GL11.GL_POLYGON_OFFSET_FILL);
            GL11.glDepthRange(0.0, 0.01);
            GlStateManager.popMatrix();
        }
    }

    @SubscribeEvent
    public void onRenderLivingPre(RenderLivingEvent.Post<EntityPlayer> event) {
        if (event.getEntity() instanceof EntityPlayer) {
            boolean shadow = mc.getRenderManager().isRenderShadow();
            mc.getRenderManager().setRenderShadow(shadow);
            GlStateManager.pushMatrix();
            GlStateManager.depthMask(false);
            GL11.glDisable(GL11.GL_POLYGON_OFFSET_FILL);
            GL11.glDepthRange(0.0, 1.0);
            GlStateManager.popMatrix();
        }
    }
}
