package me.enokitoraisu.shimejiclient.module.impl.hud;

import me.enokitoraisu.shimejiclient.ShimejiClient;
import me.enokitoraisu.shimejiclient.module.Category;
import me.enokitoraisu.shimejiclient.module.Module;
import me.enokitoraisu.shimejiclient.utils.math.ColorUtil;
import me.enokitoraisu.shimejiclient.utils.renderer.RenderUtil;
import me.enokitoraisu.shimejiclient.utils.renderer.font.FontUtil;
import me.enokitoraisu.shimejiclient.value.values.ColorValue;
import me.enokitoraisu.shimejiclient.value.values.ModeValue;
import net.minecraft.client.Minecraft;
import org.lwjgl.input.Keyboard;

import java.awt.*;

import static me.enokitoraisu.shimejiclient.ShimejiClient.ModName;
import static me.enokitoraisu.shimejiclient.ShimejiClient.ModVersion;

@SuppressWarnings("unused")
public class WaterMark extends Module {
    public ModeValue styleSetting = register(new ModeValue("Style", "Simple", "Simple", "STYLE1"));
    public ColorValue colorSetting = register(new ColorValue("Color", new Color(179, 220, 239, 255)));
    public ModeValue fontsSetting = register(new ModeValue("Fonts", "Righteous", v -> styleSetting.getValue().equals("Simple"), "Minecraft", "Righteous", "Comfortaa", "Roboto"));

    public WaterMark() {
        super("WaterMark", Category.HUD, Keyboard.KEY_NONE);
    }

    @Override
    public void onRender2D() {
        int x = 5;
        int y = 5;

        switch (styleSetting.getValue()) {
            case "STYLE1":
                int rainbow1 = ColorUtil.getRainbow(10.0f, 0.5f, 1.0f, 0L);
                int rainbow2 = ColorUtil.getRainbow(10.0f, 0.5f, 1.0f, 2000L);
                String text = String.format(
                        "\u00A7f%s\u00A7rsense\u00A7f - %s - %s - %dms",
                        ShimejiClient.ModID,
                        mc.getSession().getUsername(),
                        mc.isSingleplayer() ? "SinglePlayer" : mc.getCurrentServerData() == null ? "null" : mc.getCurrentServerData().serverIP,
                        getResponseTime(mc)
                );
                RenderUtil.drawRect(x, y, (float) FontUtil.sfui18.getStringWidth(text) + 10, FontUtil.sfui18.getHeight() + 12, 0xFF4B4B4B);
                RenderUtil.drawRect(x + 2, y + 2, (float) FontUtil.sfui18.getStringWidth(text) + 6, FontUtil.sfui18.getHeight() + 7, 0xFF282828);
                RenderUtil.drawGradientRect(x + 2, FontUtil.sfui18.getHeight() + y + 9, (int) (FontUtil.sfui18.getStringWidth(text) + 6), 1, rainbow1, rainbow2);
                FontUtil.sfui18.drawString(text, x + 5, y + 6, this.colorSetting.getIntValue());
                break;
            case "Simple":
                switch (fontsSetting.getValue()) {
                    case "Minecraft":
                        mc.fontRenderer.drawStringWithShadow(String.format("%s v%s", ModName, ModVersion), 3, 3, this.colorSetting.getIntValue());
                        break;
                    case "Righteous":
                        FontUtil.righteous18.drawStringWithShadow(ModName + " v" + ModVersion, 3, 3, ColorUtil.toRGBA(colorSetting.getValue()));
                        break;
                    case "Comfortaa":
                        FontUtil.comf18.drawStringWithShadow(ModName + " v" + ModVersion, 3, 3, ColorUtil.toRGBA(colorSetting.getValue()));
                        break;
                    case "Roboto":
                        FontUtil.roboto18.drawStringWithShadow(ModName + " v" + ModVersion, 3, 3, ColorUtil.toRGBA(colorSetting.getValue()));
                        break;
                }
        }
    }

    public int getResponseTime(Minecraft mc) {
        if (mc.player.connection.getPlayerInfo(mc.getSession().getProfile().getId()) != null) {
            return mc.player.connection.getPlayerInfo(mc.getSession().getProfile().getId()).getResponseTime();
        } else {
            return 0;
        }
    }
}
