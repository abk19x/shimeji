package me.enokitoraisu.shimejiclient.utils.math;

public class Easings {
    public static final String[] easings = {"none", "cubic", "quint", "quad", "quart", "expo", "sine", "circ"};

    public static double toOutEasing(String easing, double value) {
        switch (easing) {
            case "cubic":
                return cubicOut(value);
            case "quint":
                return quintOut(value);
            case "quad":
                return quadOut(value);
            case "quart":
                return quartOut(value);
            case "expo":
                return expoOut(value);
            case "sine":
                return sineOut(value);
            case "circ":
                return circOut(value);
            default:
                return value;
        }
    }

    public static double toInEasing(String easing, double value) {
        switch (easing) {
            case "cubic":
                return cubicIn(value);
            case "quint":
                return quintIn(value);
            case "quad":
                return quadIn(value);
            case "quart":
                return quartIn(value);
            case "expo":
                return expoIn(value);
            case "sine":
                return sineIn(value);
            case "circ":
                return circIn(value);
            default:
                return value;
        }
    }

    //cubic
    public static double cubicIn(double value) {
        return value * value * value;
    }

    public static double cubicOut(double value) {
        return 1 - Math.pow(1 - value, 3);
    }

    public static double cubicInOut(double value) {
        return value < 0.5 ? 4 * value * value * value : 1 - Math.pow(-2 * value + 2, 3) / 2;
    }

    //quint
    public static double quintIn(double value) {
        return value * value * value * value * value;
    }

    public static double quintOut(double value) {
        return 1 - Math.pow(1 - value, 5);
    }

    public static double quintInOut(double value) {
        return value < 0.5 ? 16 * value * value * value * value * value : 1 - Math.pow(-2 * value + 2, 5) / 2;
    }

    //quad
    public static double quadIn(double value) {
        return value * value;
    }

    public static double quadOut(double value) {
        return 1 - (1 - value) * (1 - value);
    }

    public static double quadInOut(double value) {
        return value < 0.5 ? 2 * value * value : 1 - Math.pow(-2 * value + 2, 2) / 2;
    }

    //Quart
    public static double quartIn(double value) {
        return value * value * value * value;
    }

    public static double quartOut(double value) {
        return 1 - Math.pow(1 - value, 4);
    }

    public static double quartInOut(double value) {
        return value < 0.5 ? 8 * value * value * value * value : 1 - Math.pow(-2 * value + 2, 4) / 2;
    }

    //expo
    public static double expoIn(double value) {
        return value == 0 ? 0 : Math.pow(2, 10 * value - 10);
    }

    public static double expoOut(double value) {
        return value == 1 ? 1 : 1 - Math.pow(2, -10 * value);
    }

    public static double expoInOut(double value) {
        return value == 0 ? 0 : value == 1 ? 1 : value < 0.5 ? Math.pow(2, 20 * value - 10) / 2 : (2 - Math.pow(2, -20 * value + 10)) / 2;
    }

    //sine
    public static double sineIn(double value) {
        return 1 - Math.cos((value * Math.PI) / 2);
    }

    public static double sineOut(double value) {
        return Math.sin((value * Math.PI) / 2);
    }

    public static double sineInOut(double value) {
        return -(Math.cos(Math.PI * value) - 1) / 2;
    }

    //circ
    public static double circIn(double value) {
        return 1 - Math.sqrt(1 - Math.pow(value, 2));
    }

    public static double circOut(double value) {
        return Math.sqrt(1 - Math.pow(value - 1, 2));
    }

    public static double circInOut(double value) {
        return value < 0.5 ? (1 - Math.sqrt(1 - Math.pow(2 * value, 2))) / 2 : (Math.sqrt(1 - Math.pow(-2 * value + 2, 2)) + 1) / 2;
    }
}
