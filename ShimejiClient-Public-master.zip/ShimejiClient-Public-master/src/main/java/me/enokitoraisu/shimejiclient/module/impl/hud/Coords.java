package me.enokitoraisu.shimejiclient.module.impl.hud;

import me.enokitoraisu.shimejiclient.module.Category;
import me.enokitoraisu.shimejiclient.module.Module;
import me.enokitoraisu.shimejiclient.utils.game.DisplayUtil;
import me.enokitoraisu.shimejiclient.utils.math.ColorUtil;
import me.enokitoraisu.shimejiclient.utils.renderer.font.FontUtil;
import me.enokitoraisu.shimejiclient.value.values.BooleanValue;
import me.enokitoraisu.shimejiclient.value.values.ColorValue;
import net.minecraft.client.gui.GuiChat;
import org.lwjgl.input.Keyboard;

import java.awt.*;

@SuppressWarnings("unused")
public class Coords extends Module {
    private final BooleanValue font = register(new BooleanValue("CustomFont", false));
    public ColorValue color = register(new ColorValue("Color", new Color(179, 220, 239, 255)));

    public Coords() {
        super("Coords", Category.HUD, Keyboard.KEY_NONE);
    }

    @Override
    public void onRender2D() {
        if (!mc.gameSettings.showDebugInfo) {
            String format = String.format("\u00A77X: \u00A7r%.1f \u00A77Y: \u00A7r%.0f \u00A77Z: \u00A7r%.1f", mc.player.posX, mc.player.posY, mc.player.posZ);

            if (font.getValue()) {
                FontUtil.sfui20.drawStringWithShadow(
                        format,
                        3,
                        mc.currentScreen instanceof GuiChat ? (DisplayUtil.getScaledResolution().getScaledHeight() - FontUtil.sfui20.getHeight()) - 17 : (DisplayUtil.getScaledResolution().getScaledHeight() - FontUtil.sfui20.getHeight() - 3),
                        ColorUtil.toRGBA(color.getValue())
                );
            } else {
                mc.fontRenderer.drawStringWithShadow(
                        format,
                        3,
                        mc.currentScreen instanceof GuiChat ? (DisplayUtil.getScaledResolution().getScaledHeight() - mc.fontRenderer.FONT_HEIGHT) - 17 : (DisplayUtil.getScaledResolution().getScaledHeight() - mc.fontRenderer.FONT_HEIGHT - 3),
                        ColorUtil.toRGBA(color.getValue())
                );
            }
        }
    }
}
