package me.enokitoraisu.shimejiclient.mixin;

import me.enokitoraisu.shimejiclient.module.impl.misc.EnderChestFix;
import net.minecraft.block.BlockEnderChest;
import net.minecraft.block.state.IBlockState;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.IBlockAccess;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import static net.minecraft.block.Block.FULL_BLOCK_AABB;

@Mixin(BlockEnderChest.class)
public class MixinBlockEnderChest {
    @Shadow
    @Final
    protected static AxisAlignedBB ENDER_CHEST_AABB;

    @Inject(method = "getBoundingBox(Lnet/minecraft/block/state/IBlockState;Lnet/minecraft/world/IBlockAccess;Lnet/minecraft/util/math/BlockPos;)Lnet/minecraft/util/math/AxisAlignedBB;", at = @At(value = "HEAD"), cancellable = true)
    public void getBoundingBox(IBlockState state, IBlockAccess source, BlockPos pos, CallbackInfoReturnable<AxisAlignedBB> cir) {
        EnderChestFix ecf = EnderChestFix.INSTANCE;
        if (ecf.toggled) {
            AxisAlignedBB fullBB = FULL_BLOCK_AABB;
            AxisAlignedBB enderBB = ENDER_CHEST_AABB;
            cir.setReturnValue(new AxisAlignedBB(
                    ecf.xFixer.getValue() ? fullBB.minX : enderBB.minX,
                    ecf.yFixer.getValue() ? fullBB.minY : enderBB.minY,
                    ecf.zFixer.getValue() ? fullBB.minZ : enderBB.minZ,
                    ecf.xFixer.getValue() ? fullBB.maxX : enderBB.maxX,
                    ecf.yFixer.getValue() ? fullBB.maxY : enderBB.maxY,
                    ecf.zFixer.getValue() ? fullBB.maxZ : enderBB.maxZ));
        }
    }
}
