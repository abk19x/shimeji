package me.enokitoraisu.shimejiclient.utils.entity;

import net.minecraft.entity.player.EntityPlayer;

import java.util.ArrayList;
import java.util.List;

public class FriendUtil {
    public static List<String> friends = new ArrayList<>();

    public static boolean isFriend(EntityPlayer player) {
        for (String name : friends) {
            if (name.equalsIgnoreCase(player.getName())) {
                return true;
            }
        }
        return false;
    }
}
