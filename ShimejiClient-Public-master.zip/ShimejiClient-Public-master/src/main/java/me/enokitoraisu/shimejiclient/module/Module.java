package me.enokitoraisu.shimejiclient.module;

import me.enokitoraisu.shimejiclient.ShimejiClient;
import me.enokitoraisu.shimejiclient.module.impl.client.ChatNotify;
import me.enokitoraisu.shimejiclient.module.impl.hud.NewNotifications;
import me.enokitoraisu.shimejiclient.utils.animation.Animate;
import me.enokitoraisu.shimejiclient.utils.chat.ChatUtil;
import me.enokitoraisu.shimejiclient.utils.renderer.font.FontUtil;
import me.enokitoraisu.shimejiclient.value.ValueBase;
import me.enokitoraisu.shimejiclient.value.values.*;
import net.minecraft.client.Minecraft;
import net.minecraft.util.text.TextComponentString;
import net.minecraftforge.common.MinecraftForge;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;

public class Module {
    public static Minecraft mc = Minecraft.getMinecraft();
    public String name, tags, description;
    public Category category;
    public int keyboard;
    public boolean toggled, drawn;
    public List<ValueBase<?>> settings;
    public Logger logger;
    public Animate slide;

    public Module(String name, Category category, int keyboard) {
        this(name, "", category, keyboard);
    }

    public Module(String name, String description, Category category, int keyboard) {
        this.name = name;
        this.tags = "";
        this.description = description;
        this.category = category;
        this.keyboard = keyboard;
        this.toggled = false;
        this.drawn = true;
        this.settings = new ArrayList<>();
        this.logger = LogManager.getLogger(name);
        this.slide = new Animate();
    }

    public static boolean fullNullCheck() {
        return !(mc.player == null || mc.world == null);
    }

    public void Enable() {
        MinecraftForge.EVENT_BUS.register(this);
    }

    public void Disable() {
        MinecraftForge.EVENT_BUS.unregister(this);
    }

    public void onEnable() {
    }

    public void onDisable() {
    }

    public void onTick() {
    }

    public void onUpdate() {
    }

    public void onRender3D() {
    }

    public void onRender2D() {
    }

    public void toggle() {
        this.toggled = !this.toggled;
        if (ChatNotify.INSTANCE.toggled)
            sendMessage(ShimejiClient.PrefixFormat + (toggled ? "\u00A7aEnable " : "\u00A7cDisable ") + "\u00A7r" + name);
        if (NewNotifications.INSTANCE.toggled)
            NewNotifications.INSTANCE.add((this.toggled ? "\u00A7aEnabled" : "\u00A7cDisabled") + "\u00A7r " + this.name, NewNotifications.Type.INFO);
        if (toggled) {
            Enable();
            onEnable();
        } else {
            onDisable();
            Disable();
        }
    }

    public void sendNotify(String message, NewNotifications.Type type) {
        if (NewNotifications.INSTANCE.toggled) NewNotifications.INSTANCE.add(message, type);
        if (ChatNotify.INSTANCE.toggled) sendMessage(String.format("%s%s", ShimejiClient.PrefixFormat, message));
    }

    public void sendMessage(String msg) {
        if (ChatUtil.getChatGui() != null)
            ChatUtil.getChatGui().printChatMessageWithOptionalDeletion(new TextComponentString(msg), ShimejiClient.CHAT_DELETE_ID);
    }

    public void setTags(String tags) {
        this.tags = tags;
    }

    public String getName() {
        return this.name;
    }

    public FloatValue register(FloatValue setting) {
        this.settings.add(setting);
        return setting;
    }

    public ColorValue register(ColorValue setting) {
        this.settings.add(setting);
        return setting;
    }

    public IntegerValue register(IntegerValue setting) {
        this.settings.add(setting);
        return setting;
    }

    public BooleanValue register(BooleanValue setting) {
        this.settings.add(setting);
        return setting;
    }

    public ModeValue register(ModeValue setting) {
        this.settings.add(setting);
        return setting;
    }

    public StringValue register(StringValue setting) {
        this.settings.add(setting);
        return setting;
    }

    public KeyValue register(KeyValue setting) {
        this.settings.add(setting);
        return setting;
    }

    public void register(ValueBase<?>... valueBases) {
        this.settings.addAll(Arrays.asList(valueBases));
    }

    public double ArrayLength() {
        return FontUtil.sfui20.getStringWidth(!Objects.equals(tags, "") ? name + " [" + tags + "]" : name);
    }

    public boolean isToggled() {
        return toggled;
    }
}