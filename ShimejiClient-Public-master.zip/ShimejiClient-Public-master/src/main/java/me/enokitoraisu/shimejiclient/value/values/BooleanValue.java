package me.enokitoraisu.shimejiclient.value.values;

import me.enokitoraisu.shimejiclient.value.ValueBase;

import java.util.function.Predicate;

public class BooleanValue extends ValueBase<Boolean> {
    public BooleanValue(String name, Boolean value) {
        this(name, value, v -> true);
    }

    public BooleanValue(String name, Boolean value, Predicate<Boolean> visibility) {
        super(name, value, visibility);
    }
}
