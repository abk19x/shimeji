package me.enokitoraisu.shimejiclient.gui.shimeji;

import me.enokitoraisu.shimejiclient.ShimejiClient;
import me.enokitoraisu.shimejiclient.gui.GuiSetting;
import me.enokitoraisu.shimejiclient.gui.shimeji.componet.componets.ModuleButton;
import me.enokitoraisu.shimejiclient.module.Category;
import me.enokitoraisu.shimejiclient.module.Module;
import me.enokitoraisu.shimejiclient.utils.interfaces.Util;
import me.enokitoraisu.shimejiclient.utils.renderer.RenderUtil;
import me.enokitoraisu.shimejiclient.utils.renderer.font.FontUtil;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class Panel implements Util {
    public static int offset = 0;
    private final Category category;
    public int x;
    public int y;
    public int width;
    public int height;
    public boolean opening = true;
    public List<ModuleButton> buttons;
    private boolean isMoving;
    private boolean isHovering;
    private int diffX;
    private int diffY;

    public Panel(Category c, int x, int y, int width, int height) {
        this.category = c;
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
        this.isMoving = false;
        this.diffX = 0;
        this.diffY = 0;
        this.buttons = new ArrayList<>();
        List<Module> moduleArrayList = ShimejiClient.moduleManager.getModulesWithCategories(c);
        moduleArrayList.sort(Comparator.comparing(Module::getName));
        for (Module module : moduleArrayList) this.buttons.add(new ModuleButton(module, x, width, height - 2));
    }

    public void drawScreen(int mouseX, int mouseY) {
        if (this.isMoving) {
            this.x = mouseX + this.diffX;
            this.y = mouseY + this.diffY;
            buttons.forEach(moduleButton -> moduleButton.changeX(x));
        }

        RenderUtil.drawDoubleRectWH(x, y, width, height, GuiSetting.getAccent());

        FontUtil.sfui18.drawStringWithShadow(
                category.getName(),
                x + (width / 2f - FontUtil.sfui18.getStringWidth(category.getName()) / 2f),
                y + (height / 2f - FontUtil.sfui18.getHeight() / 2f),
                -1
        );

        offset = y + 2;

        if (opening)
            buttons.forEach(moduleButton -> moduleButton.drawScreen(mouseX, mouseY, offset += moduleButton.height));

        RenderUtil.drawOutLineRect(x, y, width, offset + height - 2 - y, 0.5f, 0xFF191919);
    }

    public boolean mouseClicked(int mouseX, int mouseY, int mouseButton) {
        if (opening)
            buttons.forEach(moduleButton -> moduleButton.mouseClicked(mouseX, mouseY, mouseButton));

        if (mouseButton == 0 && x < mouseX && x + width > mouseX && !isHovering && y < mouseY && y + height > mouseY) {
            isMoving = true;
            isHovering = true;
            diffX = x - mouseX;
            diffY = y - mouseY;
        }

        if (x < mouseX && x + width > mouseX && mouseButton == 1 && y < mouseY && y + height > mouseY) {
            opening = !opening;
        }

        return x < mouseX && x + width > mouseX && mouseButton == 0 && y < mouseY && y + height > mouseY;
    }

    public void mouseReleased(int mouseX, int mouseY, int state) {
        buttons.forEach(moduleButton -> moduleButton.mouseReleased(mouseX, mouseY, state));
        isMoving = false;
        isHovering = false;
    }

    public void mouseClickMove(int mouseX, int mouseY, int clickedMouseButton) {
        buttons.forEach(moduleButton -> moduleButton.mouseClickMove(mouseX, mouseY, clickedMouseButton));
    }

    public void keyTyped(char typedChar, int keyCode) {
        buttons.forEach(moduleButton -> moduleButton.keyTyped(typedChar, keyCode));
    }

    public void setX(int x) {
        buttons.forEach(moduleButton -> moduleButton.changeX(x));
    }
}

