package me.enokitoraisu.shimejiclient.event;

import net.minecraft.client.gui.ChatLine;
import net.minecraft.util.text.ITextComponent;

import java.util.List;

public class PrintChatEvent extends EventManager {
    private final ITextComponent chatComponent;
    private final int chatLineId;
    private final List<ChatLine> drawnChatLines;

    public PrintChatEvent(ITextComponent chatComponent, int chatLineId, List<ChatLine> drawnChatLines) {
        this.chatComponent = chatComponent;
        this.chatLineId = chatLineId;
        this.drawnChatLines = drawnChatLines;
    }

    public ITextComponent getChatComponent() {
        return chatComponent;
    }

    public int getChatLineId() {
        return chatLineId;
    }

    public List<ChatLine> getDrawnChatLines() {
        return drawnChatLines;
    }
}
