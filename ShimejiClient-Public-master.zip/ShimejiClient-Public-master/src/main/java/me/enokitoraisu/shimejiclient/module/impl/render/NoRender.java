package me.enokitoraisu.shimejiclient.module.impl.render;

import me.enokitoraisu.shimejiclient.event.FireEffectEvent;
import me.enokitoraisu.shimejiclient.event.HurtEffectEvent;
import me.enokitoraisu.shimejiclient.event.SpawnParticleEvent;
import me.enokitoraisu.shimejiclient.module.Category;
import me.enokitoraisu.shimejiclient.module.Module;
import me.enokitoraisu.shimejiclient.value.values.BooleanValue;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import org.lwjgl.input.Keyboard;

@SuppressWarnings("unused")
public class NoRender extends Module {
    public static NoRender INSTANCE = new NoRender();

    public BooleanValue fire = register(new BooleanValue("Fire", false));
    public BooleanValue hurtCam = register(new BooleanValue("HurtCam", false));
    public BooleanValue toast = register(new BooleanValue("Toast", false));
    public BooleanValue explosion = register(new BooleanValue("Explosion", false));

    public NoRender() {
        super("NoRender", Category.RENDER, Keyboard.KEY_NONE);
        INSTANCE = this;
    }

    @Override
    public void onTick() {
        if (toast.getValue())
            mc.getToastGui().clear();
    }

    @SubscribeEvent
    public void onHurtCameraEffect(HurtEffectEvent event) {
        if (hurtCam.getValue())
            event.setCanceled(true);
    }

    @SubscribeEvent
    public void onFireEffectRender(FireEffectEvent event) {
        if (fire.getValue())
            event.setCanceled(true);
    }

    @SubscribeEvent
    public void onSpawnParticle(SpawnParticleEvent event) {
        if (explosion.getValue()) {
            switch (event.getParticleType()) {
                case EXPLOSION_NORMAL:
                case EXPLOSION_LARGE:
                case EXPLOSION_HUGE:
                    event.setCanceled(true);
                    break;
            }
        }
    }
}
