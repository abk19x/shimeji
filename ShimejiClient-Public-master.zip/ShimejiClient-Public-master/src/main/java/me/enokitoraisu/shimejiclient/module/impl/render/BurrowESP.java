package me.enokitoraisu.shimejiclient.module.impl.render;

import me.enokitoraisu.shimejiclient.module.Category;
import me.enokitoraisu.shimejiclient.module.Module;
import me.enokitoraisu.shimejiclient.utils.entity.FriendUtil;
import me.enokitoraisu.shimejiclient.utils.renderer.RenderUtil3D;
import me.enokitoraisu.shimejiclient.value.values.ColorValue;
import me.enokitoraisu.shimejiclient.value.values.IntegerValue;
import net.minecraft.block.material.Material;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.math.BlockPos;
import org.lwjgl.input.Keyboard;

import java.awt.*;

@SuppressWarnings("unused")
public class BurrowESP extends Module {
    private final IntegerValue alpha = register(new IntegerValue("LineAlpha", 127, 0, 255));
    private final IntegerValue boxAlpha = register(new IntegerValue("BoxAlpha", 127, 0, 255));
    private final ColorValue selfColor = register(new ColorValue("SelfColor", new Color(0x00FF00), false));
    private final ColorValue playerColor = register(new ColorValue("PlayerColor", new Color(0xFF0000), false));

    public BurrowESP() {
        super("BurrowESP", Category.RENDER, Keyboard.KEY_NONE);
    }

    public void onRender3D() {
        for (Entity entity : mc.world.loadedEntityList) {
            if (entity instanceof EntityPlayer) {
                BlockPos pos = new BlockPos(Math.floor(entity.posX), Math.floor(entity.posY), Math.floor(entity.posZ));
                if (mc.world.getBlockState(pos).getMaterial() != Material.AIR) {
                    RenderUtil3D.drawBox(pos,
                            isSelf((EntityPlayer) entity) || FriendUtil.isFriend((EntityPlayer) entity) ? getBoxColor(selfColor.getIntValue()) : getBoxColor(playerColor.getIntValue()),
                            isSelf((EntityPlayer) entity) || FriendUtil.isFriend((EntityPlayer) entity) ? getLineColor(selfColor.getIntValue()) : getLineColor(playerColor.getIntValue()),
                            true,
                            true,
                            1.0f);
                }
            }
        }
    }

    public int getLineColor(int color) {
        return (color & 0x00FFFFFF) | (alpha.getValue() << 24);
    }

    public int getBoxColor(int color) {
        return (color & 0x00FFFFFF) | (boxAlpha.getValue() << 24);
    }

    public boolean isSelf(EntityPlayer e) {
        return e == mc.player;
    }
}