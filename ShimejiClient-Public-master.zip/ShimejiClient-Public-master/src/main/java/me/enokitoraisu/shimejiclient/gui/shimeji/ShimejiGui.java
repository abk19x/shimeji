package me.enokitoraisu.shimejiclient.gui.shimeji;

import com.google.common.collect.Lists;
import me.enokitoraisu.shimejiclient.module.Category;
import me.enokitoraisu.shimejiclient.module.impl.client.Gui;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.util.ResourceLocation;
import org.lwjgl.input.Mouse;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class ShimejiGui extends GuiScreen {
    private static final List<Panel> panels = new ArrayList<>();

    public void initGui() {
        if (Minecraft.getMinecraft().entityRenderer.getShaderGroup() != null)
            Minecraft.getMinecraft().entityRenderer.getShaderGroup().deleteShaderGroup();
        if (Gui.INSTANCE.blur.getValue())
            Minecraft.getMinecraft().entityRenderer.loadShader(new ResourceLocation("shaders/post/blur.json"));

        if (panels.size() == 0) {
            int x = 10;
            for (Category category : Category.values()) {
                panels.add(new Panel(category, x, 10, 100, 17));
                x += 101;
            }
        }
    }

    @Override
    public void drawScreen(int mouseX, int mouseY, float partialTicks) {
        this.scrollY();

        //GuiSetting.setAccent(Gui.INSTANCE.color.getIntValue());
        //animate.setEase(Easing.LINEAR).setMin(0).setMax(100).setSpeed(200).setReversed(false).update();
        //GlStateManager.pushMatrix();
        //float value = animate.getValue() / 100;
        //GlStateManager.translate(width / 2f, height / 2f, 1);
        //GlStateManager.scale(value, value, 0);
        //GlStateManager.translate(-width / 2f, -height / 2f, 1);

        panels.forEach(panel -> panel.drawScreen(mouseX, mouseY));
        //GlStateManager.popMatrix();

        super.drawScreen(mouseX, mouseY, partialTicks);
    }

    @Override
    public void mouseClicked(int mouseX, int mouseY, int mouseButton) {
        List<Panel> sorted = Lists.reverse(panels);
        for (Panel panel : sorted) {
            if (panel.mouseClicked(mouseX, mouseY, mouseButton)) {
                set(sorted, panel);
                break;
            }
        }
        try {
            super.mouseClicked(mouseX, mouseY, mouseButton);
        } catch (IOException ignored) {
        }
    }

    public void set(List<Panel> panels, Panel obj) {
        int a = panels.indexOf(obj);
        if (a > 0) {
            panels.remove(a);
            panels.add(0, obj);
        }
    }

    @Override
    public void mouseReleased(int mouseX, int mouseY, int state) {
        panels.forEach(panel -> panel.mouseReleased(mouseX, mouseY, state));
    }

    @Override
    public void mouseClickMove(int mouseX, int mouseY, int clickedMouseButton, long timeSinceLastClick) {
        panels.forEach(panel -> panel.mouseClickMove(mouseX, mouseY, clickedMouseButton));
    }

    @Override
    public void keyTyped(char typedChar, int keyCode) {
        panels.forEach(panel -> panel.keyTyped(typedChar, keyCode));
        try {
            super.keyTyped(typedChar, keyCode);
        } catch (Exception ignored) {
        }
    }

    @Override
    public void onGuiClosed() {
        if (Minecraft.getMinecraft().entityRenderer.getShaderGroup() != null)
            Minecraft.getMinecraft().entityRenderer.getShaderGroup().deleteShaderGroup();
    }

    @Override
    public boolean doesGuiPauseGame() {
        return false;
    }

    public void scrollY() {
        int scroll = Mouse.getDWheel();
        if (scroll < 0) {
            panels.forEach(panel -> panel.y -= 5);
        } else if (scroll > 0) {
            panels.forEach(panel -> panel.y += 5);
        }
    }

}