package me.enokitoraisu.shimejiclient.utils.chat;

import java.util.concurrent.atomic.AtomicInteger;
import java.util.function.Predicate;

public class SkippingCounter {
    private final AtomicInteger counter;
    private final Predicate<Integer> skip;

    public SkippingCounter(int initial, Predicate<Integer> skip) {
        this.counter = new AtomicInteger(initial);
        this.skip = skip;
    }

    public int next() {
        int result;

        do {
            result = counter.incrementAndGet();
        }
        while (!skip.test(result));

        return result;
    }
}
