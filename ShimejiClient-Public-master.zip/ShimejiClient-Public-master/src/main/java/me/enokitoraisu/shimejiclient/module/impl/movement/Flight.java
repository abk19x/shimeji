package me.enokitoraisu.shimejiclient.module.impl.movement;

import me.enokitoraisu.shimejiclient.event.JumpEvent;
import me.enokitoraisu.shimejiclient.module.Category;
import me.enokitoraisu.shimejiclient.module.Module;
import me.enokitoraisu.shimejiclient.utils.math.ColorUtil;
import me.enokitoraisu.shimejiclient.utils.math.MathUtil;
import me.enokitoraisu.shimejiclient.utils.math.TimerUtil;
import me.enokitoraisu.shimejiclient.utils.renderer.RenderUtil3D;
import me.enokitoraisu.shimejiclient.value.values.BooleanValue;
import me.enokitoraisu.shimejiclient.value.values.FloatValue;
import me.enokitoraisu.shimejiclient.value.values.IntegerValue;
import me.enokitoraisu.shimejiclient.value.values.ModeValue;
import net.minecraft.network.play.client.CPacketPlayer;
import net.minecraft.util.math.BlockPos;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import org.lwjgl.input.Keyboard;

@SuppressWarnings("unused")
public class Flight extends Module {
    public BlockPos SP;
    public double StartY;
    public boolean onDamage = false;
    public TimerUtil timerUtil = new TimerUtil();

    public ModeValue FlyModes = register(new ModeValue("Mode", "Creative", "Creative", "SlimeFly", "Jump", "2B2TJP"));
    public FloatValue Speed = register(new FloatValue("Speed", 0.1F, 0.1F, 5.0F, v -> FlyModes.getValue().equals("Creative")));
    public BooleanValue ViewBob = register(new BooleanValue("ViewBob", false, v -> FlyModes.getValue().equals("Creative")));
    public FloatValue BobAmount = register(new FloatValue("BobAmount", 0.1F, 0.1F, 5.0F, v -> (ViewBob.getValue() && FlyModes.getValue().equals("Creative"))));
    public BooleanValue Damage = register(new BooleanValue("Damage", false, v -> FlyModes.getValue().equals("Creative")));
    public BooleanValue cancel = register(new BooleanValue("CancelJump", false, v -> FlyModes.getValue().equals("SlimeFly")));
    public BooleanValue render_slime = register(new BooleanValue("StartPosRender", false, v -> FlyModes.getValue().equals("SlimeFly")));
    public IntegerValue jpSpeed = register(new IntegerValue("TeleportAmount", 5, 10, 30, v -> FlyModes.getValue().equals("2B2TJP")));
    public IntegerValue teleportTime = register(new IntegerValue("TeleportTime", 750, 300, 3000, v -> FlyModes.getValue().equals("2B2TJP")));

    public Flight() {
        super("Flight", Category.MOVEMENT, Keyboard.KEY_NONE);
    }

    @Override
    public void onTick() {
        setTags(FlyModes.getValue());
        switch (FlyModes.getValue()) {
            case "Creative":
                if (Damage.getValue() && !onDamage) {
                    break;
                }
                mc.player.setVelocity(0, 0, 0);
                mc.player.jumpMovementFactor = Speed.getValue();
                final double[] move = MathUtil.directionSpeed(Speed.getValue());
                if (mc.player.movementInput.moveStrafe != 0 || mc.player.movementInput.moveForward != 0) {
                    if (ViewBob.getValue()) mc.player.cameraYaw = BobAmount.getValue() / 10;
                    mc.player.motionX = move[0];
                    mc.player.motionZ = move[1];
                } else {
                    mc.player.motionX = 0;
                    mc.player.motionZ = 0;
                }
                if (mc.gameSettings.keyBindJump.isKeyDown()) mc.player.motionY += Speed.getValue();
                if (mc.gameSettings.keyBindSneak.isKeyDown()) mc.player.motionY -= Speed.getValue();
                break;
            case "SlimeFly":
                mc.player.motionY = 0.0f;
                mc.player.onGround = true;
                break;
            case "Jump":
                if (mc.player.posY < StartY) {
                    mc.player.jump();
                }
                break;
            case "2B2TJP":
                double yaw = Math.cos(Math.toRadians(mc.player.rotationYaw + 90.0f));
                double pitch = Math.sin(Math.toRadians(mc.player.rotationYaw + 90.0f));

                mc.player.setPosition(mc.player.posX + jpSpeed.getValue() * yaw, mc.player.posY, mc.player.posZ + jpSpeed.getValue() * pitch);

                if (timerUtil.passedMs(teleportTime.getValue())) {
                    mc.player.setPosition(mc.player.posX, mc.player.posY + 30, mc.player.posZ);
                    timerUtil.reset();
                }

                mc.player.motionY = 0;
                break;
        }
    }

    @Override
    public void onDisable() {
        mc.player.motionX = 0;
        mc.player.motionY = 0;
        mc.player.motionZ = 0;
    }

    @Override
    public void onRender3D() {
        if (FlyModes.getValue().equals("SlimeFly") && render_slime.getValue() && SP != null) {
            RenderUtil3D.drawString3D(
                    SP.down(),
                    String.format("%d %d %d Distance: %d", SP.getX(), SP.getY(), SP.getZ(), Math.round(mc.player.getDistance(SP.getX(), SP.getY(), SP.getZ()))),
                    ColorUtil.getRainbow(10.0f, 0.5f, 1.0f, 0)
            );
        }
    }

    @SubscribeEvent
    public void onJump(JumpEvent event) {
        if (FlyModes.getValue().equals("SlimeFly") && cancel.getValue()) event.setCanceled(true);
    }

    @Override
    public void onEnable() {
        if (fullNullCheck()) {
            if (FlyModes.getValue().equals("Creative") && Damage.getValue()) {
                if (mc.world.getCollisionBoxes(mc.player, mc.player.getEntityBoundingBox().offset(0, 3.0001, 0).expand(0, 0, 0)).isEmpty()) {
                    mc.player.connection.sendPacket(new CPacketPlayer.Position(mc.player.posX, mc.player.posY + 3.0001, mc.player.posZ, false));
                    mc.player.connection.sendPacket(new CPacketPlayer.Position(mc.player.posX, mc.player.posY, mc.player.posZ, false));
                    mc.player.connection.sendPacket(new CPacketPlayer.Position(mc.player.posX, mc.player.posY, mc.player.posZ, true));
                }
                mc.player.setPosition(mc.player.posX, mc.player.posY + 0.42, mc.player.posZ);
                onDamage = true;
            }
            if (FlyModes.getValue().equals("SlimeFly"))
                SP = new BlockPos((int) Math.floor(mc.player.posX), (int) Math.floor(mc.player.posY), (int) Math.floor(mc.player.posZ));
            if (FlyModes.getValue().equals("Jump")) StartY = mc.player.posY;
        }
    }
}
