package me.enokitoraisu.shimejiclient.gui.shimeji.componet.componets;

import me.enokitoraisu.shimejiclient.gui.shimeji.componet.Component;
import me.enokitoraisu.shimejiclient.utils.animation.Animate;
import me.enokitoraisu.shimejiclient.utils.animation.Easing;
import me.enokitoraisu.shimejiclient.utils.renderer.RenderUtil;
import me.enokitoraisu.shimejiclient.utils.renderer.font.FontUtil;
import me.enokitoraisu.shimejiclient.value.values.StringValue;
import net.minecraft.util.ChatAllowedCharacters;
import org.lwjgl.input.Keyboard;

import java.awt.*;
import java.awt.datatransfer.DataFlavor;
import java.awt.datatransfer.UnsupportedFlavorException;
import java.io.IOException;

public class StringButton extends Component {
    private final StringValue stringValue;
    //private int selectLength;
    private final Animate animate = new Animate();
    private boolean isWaiting;
    private boolean select;
    private CurrentString currentString;

    public StringButton(StringValue stringValue, int x, int width, int height) {
        this.stringValue = stringValue;
        this.x = x;
        this.width = width;
        this.height = height;
        this.currentString = new CurrentString(stringValue.getValue());
    }

    @Override
    public void drawScreen(int mouseX, int mouseY, int offsetY) {
        this.visible = this.stringValue.getVisibility();
        if (this.visible) {
            this.y = offsetY;

            RenderUtil.drawRect(this.x, offsetY, this.width, this.height, 0xCB191919);

            animate.setEase(animate.isReversed() ? Easing.CIRC_IN : Easing.CIRC_OUT).setMax(100).setMin(0).setSpeed(300).setReversed(!isWaiting).update();

            if (animate.getValue() > 0)
                RenderUtil.drawRect(x + 2, offsetY + height - 1, (width - 4) * animate.getValue() / animate.getMax(), 1, 0xFFFFFFFF);

            if (bounding(mouseX, mouseY))
                RenderUtil.drawRect(x, offsetY, width, height, 0x40000000);


            if ((currentString.getString().isEmpty() && isWaiting) || (bounding(mouseX, mouseY) && !isWaiting)) {
                FontUtil.sfui18.drawStringWithShadow(String.format("\u00A77%s...\u00A7r", this.stringValue.getName()), this.x + 5, offsetY + (this.height - FontUtil.sfui18.getHeight()) / 2f, -1);
            } else {
                if (select)
                    RenderUtil.drawRect(this.x + 4, offsetY - 1 + (this.height - FontUtil.sfui18.getHeight()) / 2f, (float) FontUtil.sfui18.getStringWidth(this.currentString.getString()) + 1F, FontUtil.sfui18.getHeight() + 1F, 0x80FFFFFF);
                FontUtil.sfui18.drawStringWithShadow(this.isWaiting ? this.currentString.getString() : stringValue.isPassword() ? this.stringValue.getValue().replaceAll(".", "*") : this.stringValue.getValue(), this.x + 5, offsetY + (this.height - FontUtil.sfui18.getHeight()) / 2f, -1);
            }
        }
    }

    @Override
    public void mouseClicked(int mouseX, int mouseY, int mouseButton) {
        if (!this.visible) return;
        if (this.bounding(mouseX, mouseY)) {
            if (mouseButton == 0) {
                if (!this.isWaiting) {
                    this.currentString = new CurrentString(stringValue.getValue());
                }
                this.isWaiting = !this.isWaiting;
                this.select = false;
            }
        } else {
            this.isWaiting = false;
            this.select = false;
        }
    }

    @Override
    public void keyTyped(char typedChar, int keyCode) {
        if (!this.visible) return;
        if (this.isWaiting) {
            switch (keyCode) {
                case Keyboard.KEY_ESCAPE:
                    select = false;
                    return;
                case Keyboard.KEY_RETURN:
                    if (!currentString.getString().isEmpty()) {
                        this.stringValue.setValue(this.currentString.getString());
                    }
                    isWaiting = !isWaiting;
                    select = false;
                    break;
                case Keyboard.KEY_BACK:
                    this.currentString.setString(select ? "" : removeLastChar(this.currentString.getString()));
                    if (select)
                        select = false;
            }
            if (Keyboard.isKeyDown(Keyboard.KEY_LCONTROL)) {
                if (keyCode == Keyboard.KEY_V) {
                    try {
                        this.currentString.setString(this.currentString.getString() + Toolkit.getDefaultToolkit().getSystemClipboard().getData(DataFlavor.stringFlavor));
                    } catch (IOException | UnsupportedFlavorException ignored) {
                    }
                    return;
                }
                if (keyCode == Keyboard.KEY_A) {
                    select = !select;
                    return;
                }
            }

            if (ChatAllowedCharacters.isAllowedCharacter(typedChar)) {
                this.currentString.setString(select ? String.valueOf(typedChar) : this.currentString.getString() + typedChar);
                if (select)
                    select = false;
            }
        }
    }

    public String removeLastChar(String str) {
        String output = "";
        if (str != null && str.length() > 0) {
            output = str.substring(0, str.length() - 1);
        }
        return output;
    }

    public static class CurrentString {
        private String string;

        public CurrentString(String string) {
            this.string = string;
        }

        public String getString() {
            return this.string;
        }

        public void setString(String integer) {
            this.string = integer;
        }
    }
}
