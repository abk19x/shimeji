package me.enokitoraisu.shimejiclient.event;

import net.minecraftforge.fml.common.eventhandler.Event;

public class EventManager extends Event {
    public boolean canceled = false;

    @Override
    public boolean isCanceled() {
        return canceled;
    }

    @Override
    public void setCanceled(boolean canceled) {
        this.canceled = canceled;
    }
}

