package me.enokitoraisu.shimejiclient.manager;

import me.enokitoraisu.shimejiclient.ShimejiClient;
import me.enokitoraisu.shimejiclient.command.Command;
import org.apache.logging.log4j.LogManager;
import org.reflections.Reflections;

import java.util.ArrayList;
import java.util.Set;

public class CommandManager {
    public ArrayList<Command> commands = new ArrayList<>();

    public CommandManager() {
        Reflections reflections = new Reflections("me.enokitoraisu.shimejiclient.command.impl");
        Set<Class<? extends Command>> subTypes = reflections.getSubTypesOf(Command.class);

        subTypes.forEach(subclass -> {
            try {
                commands.add(subclass.newInstance());
            } catch (InstantiationException | IllegalAccessException e) {
                LogManager.getLogger(String.format("%s/CommandManager", ShimejiClient.ModName)).error(e);
            }
        });
    }
}
