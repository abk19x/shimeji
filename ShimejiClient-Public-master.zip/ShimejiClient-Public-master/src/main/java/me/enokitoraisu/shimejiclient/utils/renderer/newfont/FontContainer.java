package me.enokitoraisu.shimejiclient.utils.renderer.newfont;

public class FontContainer {
    public static TrueTypeRenderer SFUI20 = new TrueTypeRenderer(new StringCache(20, true, "sfui.ttf"));
    public static TrueTypeRenderer SFUI16 = new TrueTypeRenderer(new StringCache(16, true, "sfui.ttf"));
}