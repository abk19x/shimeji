package me.enokitoraisu.shimejiclient.module.impl.misc;

import me.enokitoraisu.shimejiclient.event.PacketEvent;
import me.enokitoraisu.shimejiclient.event.SwingArmEvent;
import me.enokitoraisu.shimejiclient.module.Category;
import me.enokitoraisu.shimejiclient.module.Module;
import me.enokitoraisu.shimejiclient.value.values.ModeValue;
import net.minecraft.network.play.client.CPacketAnimation;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import org.lwjgl.input.Keyboard;

@SuppressWarnings("unused")
public class NoSwing extends Module {
    private final ModeValue mode = register(new ModeValue("Mode", "Packet", "Packet", "Client", "Full"));

    public NoSwing() {
        super("NoSwing", Category.MISC, Keyboard.KEY_NONE);
    }

    @SubscribeEvent
    public void onSendPacket(PacketEvent.Send event) {
        if (event.getPacket() instanceof CPacketAnimation && (mode.getValue().equals("Packet") || mode.getValue().equals("Full"))) {
            event.setCanceled(true);
        }
    }

    @SubscribeEvent
    public void onSwingArm(SwingArmEvent event) {
        if (mode.getValue().equals("Client") || mode.getValue().equals("Full")) {
            if (mode.getValue().equals("Client"))
                mc.player.connection.sendPacket(new CPacketAnimation(event.getHand()));
            event.setCanceled(true);
        }
    }
}
