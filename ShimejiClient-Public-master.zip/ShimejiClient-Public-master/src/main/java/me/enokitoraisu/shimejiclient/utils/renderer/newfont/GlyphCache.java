package me.enokitoraisu.shimejiclient.utils.renderer.newfont;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import me.enokitoraisu.shimejiclient.ShimejiClient;
import net.minecraft.client.renderer.GLAllocation;
import net.minecraft.client.renderer.GlStateManager;
import org.lwjgl.opengl.GL11;

import java.awt.*;
import java.awt.font.FontRenderContext;
import java.awt.font.GlyphVector;
import java.awt.geom.Point2D;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.io.InputStream;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.IntBuffer;
import java.util.Arrays;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;

class GlyphCache {
    private static final int TEXTURE_WIDTH = 256;
    private static final int TEXTURE_HEIGHT = 256;
    private static final int STRING_WIDTH = 256;
    private static final int STRING_HEIGHT = 64;
    private static final int GLYPH_BORDER = 1;
    private static final Color BACK_COLOR = new Color(255, 255, 255, 0);
    private float fontSize = 18;
    private boolean antiAliasEnabled = false;
    private BufferedImage stringImage;
    private Graphics2D stringGraphics;
    private final BufferedImage glyphCacheImage = new BufferedImage(TEXTURE_WIDTH, TEXTURE_HEIGHT, BufferedImage.TYPE_INT_ARGB);
    private final Graphics2D glyphCacheGraphics = glyphCacheImage.createGraphics();
    private final FontRenderContext fontRenderContext = glyphCacheGraphics.getFontRenderContext();
    private final int[] imageData = new int[TEXTURE_WIDTH * TEXTURE_HEIGHT];
    private final IntBuffer imageBuffer = ByteBuffer.allocateDirect(4 * TEXTURE_WIDTH * TEXTURE_HEIGHT).order(ByteOrder.BIG_ENDIAN).asIntBuffer();
    private final IntBuffer singleIntBuffer = GLAllocation.createDirectByteBuffer(4).asIntBuffer();
    private final List<Font> allFonts = Arrays.asList(GraphicsEnvironment.getLocalGraphicsEnvironment().getAllFonts());
    private final List<Font> usedFonts = Lists.newArrayList();
    private int textureName;
    private final LinkedHashMap<Font, Integer> fontCache = Maps.newLinkedHashMap();
    private final LinkedHashMap<Long, Entry> glyphCache = Maps.newLinkedHashMap();
    private int cachePosX = GLYPH_BORDER;
    private int cachePosY = GLYPH_BORDER;
    private int cacheLineHeight = 0;
    static class Entry {
        int textureName;
        int width;
        int height;
        float u1;
        float v1;
        float u2;
        float v2;
    }

    GlyphCache() {
        glyphCacheGraphics.setBackground(BACK_COLOR);
        glyphCacheGraphics.setComposite(AlphaComposite.Src);

        allocateGlyphCacheTexture();
        allocateStringImage(STRING_WIDTH, STRING_HEIGHT);

        GraphicsEnvironment.getLocalGraphicsEnvironment().preferLocaleFonts();
    }

    void setFont(float size, boolean antiAlias, String name) {
        usedFonts.clear();
        try (InputStream inputStream = getClass().getResourceAsStream("/assets/minecraft/shimeji/font/" + name)) {
            if (inputStream != null) {
                Font f = Font.createFont(Font.TRUETYPE_FONT, inputStream);
                usedFonts.add(f);
            }
        } catch (FontFormatException | IOException e) {
            e.printStackTrace();
        }

        fontSize = size;
        antiAliasEnabled = antiAlias;
        setRenderingHints();
    }

    public void clear() {
        glyphCache.clear();
    }

    GlyphVector layoutGlyphVector(Font font, char[] text, int start, int limit, int layoutFlags) {
        if (!fontCache.containsKey(font)) {
            fontCache.put(font, fontCache.size());
        }
        return font.layoutGlyphVector(fontRenderContext, text, start, limit, layoutFlags);
    }

    Font lookupFont(char[] text, int start, int limit, int style) {
        Iterator<Font> iterator = usedFonts.iterator();
        while (iterator.hasNext()) {
            Font font = iterator.next();
            if (font.canDisplayUpTo(text, start, limit) != start) {
                return font.deriveFont(style, fontSize);
            }
        }

        iterator = allFonts.iterator();
        while (iterator.hasNext()) {
            Font font = iterator.next();
            if (font.canDisplayUpTo(text, start, limit) != start) {
                ShimejiClient.logger.info("[{}] {} has been loaded", ShimejiClient.ModName, font.getName());
                usedFonts.add(font);

                return font.deriveFont(style, fontSize);
            }
        }

        Font font = usedFonts.get(0);

        return font.deriveFont(style, fontSize);
    }

    Entry lookupGlyph(Font font, int glyphCode) {
        long fontKey = (long) fontCache.get(font) << 32;
        return glyphCache.get(fontKey | glyphCode);
    }

    void cacheGlyphs(Font font, char[] text, int start, int limit, int layoutFlags) {
        GlyphVector vector = layoutGlyphVector(font, text, start, limit, layoutFlags);
        Rectangle vectorBounds = null;
        long fontKey = (long) fontCache.get(font) << 32;

        int numGlyphs = vector.getNumGlyphs();
        Rectangle dirty = null;
        boolean vectorRendered = false;

        for (int index = 0; index < numGlyphs; index++) {
            int glyphCode = vector.getGlyphCode(index);
            if (glyphCache.containsKey(fontKey | glyphCode)) {
                continue;
            }

            if (!vectorRendered) {
                vectorRendered = true;

                for (int i = 0; i < numGlyphs; i++) {
                    Point2D pos = vector.getGlyphPosition(i);
                    pos.setLocation(pos.getX() + 2 * i, pos.getY());
                    vector.setGlyphPosition(i, pos);
                }

                vectorBounds = vector.getPixelBounds(fontRenderContext, 0, 0);

                if (vectorBounds.width > stringImage.getWidth() || vectorBounds.height > stringImage.getHeight()) {
                    int width = Math.max(vectorBounds.width, stringImage.getWidth());
                    int height = Math.max(vectorBounds.height, stringImage.getHeight());
                    allocateStringImage(width, height);
                }

                stringGraphics.clearRect(0, 0, vectorBounds.width, vectorBounds.height);

                stringGraphics.drawGlyphVector(vector, -vectorBounds.x, -vectorBounds.y);
            }

            Rectangle rect = vector.getGlyphPixelBounds(index, null, -vectorBounds.x, -vectorBounds.y);

            if (cachePosX + rect.width + GLYPH_BORDER > TEXTURE_WIDTH) {
                cachePosX = GLYPH_BORDER;
                cachePosY += cacheLineHeight + GLYPH_BORDER;
                cacheLineHeight = 0;
            }

            if (cachePosY + rect.height + GLYPH_BORDER > TEXTURE_HEIGHT) {
                updateTexture(dirty);
                dirty = null;

                allocateGlyphCacheTexture();
                cachePosY = cachePosX = GLYPH_BORDER;
                cacheLineHeight = 0;
            }

            if (rect.height > cacheLineHeight) {
                cacheLineHeight = rect.height;
            }

            glyphCacheGraphics.drawImage(stringImage,
                    cachePosX, cachePosY, cachePosX + rect.width, cachePosY + rect.height,
                    rect.x, rect.y, rect.x + rect.width, rect.y + rect.height, null);

            rect.setLocation(cachePosX, cachePosY);

            Entry entry = new Entry();
            entry.textureName = textureName;
            entry.width = rect.width;
            entry.height = rect.height;
            entry.u1 = ((float) rect.x) / TEXTURE_WIDTH;
            entry.v1 = ((float) rect.y) / TEXTURE_HEIGHT;
            entry.u2 = ((float) (rect.x + rect.width)) / TEXTURE_WIDTH;
            entry.v2 = ((float) (rect.y + rect.height)) / TEXTURE_HEIGHT;

            glyphCache.put(fontKey | glyphCode, entry);

            if (dirty == null) {
                dirty = new Rectangle(cachePosX, cachePosY, rect.width, rect.height);
            } else {
                dirty.add(rect);
            }

            cachePosX += rect.width + GLYPH_BORDER;
        }

        updateTexture(dirty);
    }

    private void updateTexture(Rectangle dirty) {
        if (dirty != null) {
            updateImageBuffer(dirty.x, dirty.y, dirty.width, dirty.height);

            GlStateManager.bindTexture(textureName);
            GL11.glTexSubImage2D(GL11.GL_TEXTURE_2D, 0, dirty.x, dirty.y, dirty.width, dirty.height, GL11.GL_RGBA, GL11.GL_UNSIGNED_BYTE, imageBuffer);
        }
    }

    private void allocateStringImage(int width, int height) {
        stringImage = new BufferedImage(width, height, BufferedImage.TYPE_INT_ARGB);
        stringGraphics = stringImage.createGraphics();
        setRenderingHints();
        stringGraphics.setBackground(BACK_COLOR);
        stringGraphics.setPaint(Color.WHITE);
    }

    private void setRenderingHints() {
        stringGraphics.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
                antiAliasEnabled ? RenderingHints.VALUE_ANTIALIAS_ON : RenderingHints.VALUE_ANTIALIAS_OFF);
        stringGraphics.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING,
                antiAliasEnabled ? RenderingHints.VALUE_TEXT_ANTIALIAS_ON : RenderingHints.VALUE_TEXT_ANTIALIAS_OFF);

        stringGraphics.setRenderingHint(RenderingHints.KEY_FRACTIONALMETRICS, RenderingHints.VALUE_FRACTIONALMETRICS_OFF);
    }

    private void allocateGlyphCacheTexture() {
        glyphCacheGraphics.clearRect(0, 0, TEXTURE_WIDTH, TEXTURE_HEIGHT);

        singleIntBuffer.clear();
        GL11.glGenTextures(singleIntBuffer);
        textureName = singleIntBuffer.get(0);

        updateImageBuffer(0, 0, TEXTURE_WIDTH, TEXTURE_HEIGHT);

        GlStateManager.bindTexture(textureName);
        GL11.glTexImage2D(GL11.GL_TEXTURE_2D, 0, GL11.GL_ALPHA8, TEXTURE_WIDTH, TEXTURE_HEIGHT, 0, GL11.GL_RGBA, GL11.GL_UNSIGNED_BYTE, imageBuffer);

        GL11.glTexParameteri(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_MIN_FILTER, GL11.GL_NEAREST);
        GL11.glTexParameteri(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_MAG_FILTER, GL11.GL_NEAREST);
    }

    private void updateImageBuffer(int x, int y, int width, int height) {
        glyphCacheImage.getRGB(x, y, width, height, imageData, 0, width);

        for (int i = 0; i < width * height; i++) {
            int color = imageData[i];
            imageData[i] = (color << 8) | (color >>> 24);
        }

        imageBuffer.clear();
        imageBuffer.put(imageData);
        imageBuffer.flip();
    }

    static class Glyph implements Comparable<Glyph> {
        int stringIndex;
        Entry texture;
        int x;
        int y;
        float advance;

        @Override
        public int compareTo(Glyph o) {
            return Integer.compare(stringIndex, o.stringIndex);
        }
    }
}