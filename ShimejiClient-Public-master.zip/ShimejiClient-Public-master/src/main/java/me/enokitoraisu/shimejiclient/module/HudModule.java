package me.enokitoraisu.shimejiclient.module;

import me.enokitoraisu.shimejiclient.utils.animation.Animate;
import me.enokitoraisu.shimejiclient.utils.animation.Easing;
import me.enokitoraisu.shimejiclient.utils.game.MouseUtil;
import me.enokitoraisu.shimejiclient.utils.math.ColorUtil;
import me.enokitoraisu.shimejiclient.utils.renderer.BonIcon;
import me.enokitoraisu.shimejiclient.utils.renderer.RenderUtil;
import me.enokitoraisu.shimejiclient.utils.renderer.font.FontUtil;
import me.enokitoraisu.shimejiclient.value.values.IntegerValue;
import net.minecraft.client.gui.GuiChat;

public class HudModule extends Module {
    private final IntegerValue xPos = register(new IntegerValue("XPos", 1, 0, 1000, v -> false));
    private final IntegerValue yPos = register(new IntegerValue("YPos", 1, 0, 1000, v -> false));
    public Animate hover = new Animate();

    private int width, height;
    private boolean clicked;
    private int lastX;
    private int lastY;
    private boolean dragging;

    public HudModule(String name, Category category, int keybind, int x, int y, int width, int height) {
        this(name, "", category, keybind, x, y, width, height);
    }

    public HudModule(String name, String description, Category category, int keybind, int x, int y, int width, int height) {
        super(name, description, category, keybind);
        this.xPos.setValue(x);
        this.yPos.setValue(y);
        this.width = width;
        this.height = height;
    }

    void draggingFix(int mouseX, int mouseY) {
        if (this.dragging) {
            this.xPos.setValue(mouseX + this.lastX);
            this.yPos.setValue(mouseY + this.lastY);
            if (!this.clicked)
                this.dragging = false;
        }
    }

    public void drag(int mouseX, int mouseY) {
        draggingFix(mouseX, mouseY);
        if (this.clicked && bounding(mouseX, mouseY)) {
            if (!this.dragging) {
                this.lastX = this.xPos.getValue() - mouseX;
                this.lastY = this.yPos.getValue() - mouseY;
                this.dragging = true;
            }
        }
    }

    @Override
    public void onRender2D() {
        boolean draw = this.drawScreen();
        hover.setEase(Easing.LINEAR).setMin(0).setMax(100).setSpeed(500).setReversed(!(mc.currentScreen instanceof GuiChat) || (!bounding(MouseUtil.getMouseX(), MouseUtil.getMouseY())) || !draw).update();
        RenderUtil.drawRect(this.xPos.getValue(), this.yPos.getValue(), getWidth(), getHeight(), ColorUtil.toRGBA(0f, 0f, 0f, hover.getValue() / 200f));
        RenderUtil.drawOutLineRect(this.xPos.getValue(), this.yPos.getValue(), getWidth(), getHeight(), 1f, ColorUtil.toRGBA(1f, 1f, 1f, hover.getValue() / 100f));
        if (hover.getValue() / hover.getMax() > 0.1F)
            FontUtil.bonicon40.drawCenteredString(BonIcon.LEFT_MOUSE, this.xPos.getValue() + getWidth() / 2f, this.yPos.getValue() + (getHeight() / 2f - FontUtil.bonicon30.getHeight() / 2f), ColorUtil.toRGBA(1f, 1f, 1f, hover.getValue() / hover.getMax()));
    }

    public void drawChatScreen(int mouseX, int mouseY) {
    }

    public boolean drawScreen() {
        return true;
    }

    public boolean clicked(int mouseX, int mouseY, int button) {
        return false;
    }

    public boolean bounding(int mouseX, int mouseY) {
        return this.xPos.getValue() < mouseX && this.xPos.getValue() + this.getWidth() > mouseX && this.yPos.getValue() < mouseY && this.yPos.getValue() + this.getHeight() > mouseY;
    }

    public boolean bounding(int mouseX, int mouseY, float x, float y, float width, float height) {
        return x < mouseX && x + width > mouseX && y < mouseY && y + height > mouseY;
    }

    public int getX() {
        return this.xPos.getValue();
    }

    public void setX(int x) {
        this.xPos.setValue(x);
    }

    public int getY() {
        return this.yPos.getValue();
    }

    public void setY(int y) {
        this.yPos.setValue(y);
    }

    public int getWidth() {
        return width;
    }

    public void setWidth(int width) {
        this.width = width;
    }

    public int getHeight() {
        return height;
    }

    public void setHeight(int height) {
        this.height = height;
    }

    public boolean isClicked() {
        return clicked;
    }

    public void setClicked(boolean clicked) {
        this.clicked = clicked;
    }

    public boolean isDragging() {
        return dragging;
    }

    public void setDragging(boolean dragging) {
        this.dragging = dragging;
    }
}
