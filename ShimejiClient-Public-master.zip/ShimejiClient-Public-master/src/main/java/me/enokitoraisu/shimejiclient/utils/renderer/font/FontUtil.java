package me.enokitoraisu.shimejiclient.utils.renderer.font;

import net.minecraft.client.Minecraft;
import net.minecraft.util.ResourceLocation;

import java.awt.*;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;

public class FontUtil {
    public static MinecraftFontRenderer sfui40, sfui30, sfui20, sfui18, sfui16, sfui12,
            bonicon40, bonicon30, bonicon20,
            icon40, icon30,
            righteous50, righteous18,
            albula40, albula20,
            comf40, comf20, comf18,
            roboto20, roboto18, roboto24,
            kosugi20, kosugi16;
    public static Font sfui40_, sfui30_, sfui20_, sfui18_, sfui16_, sfui12_,
            bonicon40_, bonicon30_, bonicon20_,
            icon40_, icon30_,
            righteous50_,
            albula40_, albula20_,
            comf40_, comf20_,
            kosugi20_, kosugi16_;

    public static Font getFont(Map<String, Font> locationMap, String location, int size) {
        Font font;

        try {
            if (locationMap.containsKey(location)) {
                font = locationMap.get(location).deriveFont(Font.PLAIN, size);
            } else {
                InputStream is = Minecraft.getMinecraft().getResourceManager().getResource(new ResourceLocation("shimeji/font/" + location)).getInputStream();
                font = Font.createFont(0, is);
                locationMap.put(location, font);
                font = font.deriveFont(Font.PLAIN, size);
            }
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("Error loading font");
            font = new Font("default", Font.PLAIN, 20);
        }

        return font;
    }

    public static void initialize() {
        Map<String, Font> locationMap = new HashMap<>();
        sfui40_ = getFont(locationMap, "sfui.ttf", 40);
        sfui30_ = getFont(locationMap, "sfui.ttf", 25);
        sfui20_ = getFont(locationMap, "sfui.ttf", 20);
        sfui18_ = getFont(locationMap, "sfui.ttf", 18);
        sfui16_ = getFont(locationMap, "sfui.ttf", 16);
        sfui12_ = getFont(locationMap, "sfui.ttf", 12);
        icon40_ = getFont(locationMap, "icon.ttf", 40);
        icon30_ = getFont(locationMap, "icon.ttf", 30);
        bonicon40_ = getFont(locationMap, "bonicon2.0.ttf", 40);
        bonicon30_ = getFont(locationMap, "bonicon2.0.ttf", 30);
        bonicon20_ = getFont(locationMap, "bonicon2.0.ttf", 20);
        righteous50_ = getFont(locationMap, "righteous.ttf", 50);
        albula40_ = getFont(locationMap, "albula.ttf", 40);
        albula20_ = getFont(locationMap, "albula.ttf", 20);
        comf40_ = getFont(locationMap, "comfortaa.ttf", 40);
        comf20_ = getFont(locationMap, "comfortaa.ttf", 20);
        kosugi20_ = getFont(locationMap, "kosugi.ttf", 20);
        kosugi16_ = getFont(locationMap, "kosugi.ttf", 16);

        sfui40 = new MinecraftFontRenderer(sfui40_, true, true);
        sfui30 = new MinecraftFontRenderer(sfui30_, true, true);
        sfui20 = new MinecraftFontRenderer(sfui20_, true, true);
        sfui18 = new MinecraftFontRenderer(sfui18_, true, true);
        sfui16 = new MinecraftFontRenderer(sfui16_, true, true);
        sfui12 = new MinecraftFontRenderer(sfui12_, true, true);
        icon40 = new MinecraftFontRenderer(icon40_, true, true);
        icon30 = new MinecraftFontRenderer(icon30_, true, true);
        bonicon40 = new MinecraftFontRenderer(bonicon40_, true, true);
        bonicon30 = new MinecraftFontRenderer(bonicon30_, true, true);
        bonicon20 = new MinecraftFontRenderer(bonicon20_, true, true);
        righteous50 = new MinecraftFontRenderer(righteous50_, true, true);
        righteous18 = new MinecraftFontRenderer(getFont(locationMap, "righteous.ttf", 18), true, true);
        albula40 = new MinecraftFontRenderer(albula40_, true, true);
        albula20 = new MinecraftFontRenderer(albula20_, true, true);
        comf40 = new MinecraftFontRenderer(comf40_, true, true);
        comf20 = new MinecraftFontRenderer(comf20_, true, true);
        comf18 = new MinecraftFontRenderer(getFont(locationMap, "comfortaa.ttf", 18), true, true);
        kosugi20 = new MinecraftFontRenderer(kosugi20_, true, true);
        kosugi16 = new MinecraftFontRenderer(kosugi16_, true, true);

        roboto24 = new MinecraftFontRenderer(getFont(locationMap, "robotomono.ttf", 24), true, true);
        roboto20 = new MinecraftFontRenderer(getFont(locationMap, "robotomono.ttf", 20), true, true);
        roboto18 = new MinecraftFontRenderer(getFont(locationMap, "robotomono.ttf", 18), true, true);
    }
}