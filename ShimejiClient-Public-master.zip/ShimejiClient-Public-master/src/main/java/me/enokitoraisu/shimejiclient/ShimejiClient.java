package me.enokitoraisu.shimejiclient;

import me.enokitoraisu.shimejiclient.manager.*;
import me.enokitoraisu.shimejiclient.module.impl.client.Capes;
import me.enokitoraisu.shimejiclient.utils.renderer.font.FontUtil;
import net.minecraft.client.Minecraft;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.Mod.EventHandler;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPostInitializationEvent;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

@SideOnly(Side.CLIENT)
@Mod(modid = ShimejiClient.ModID, name = ShimejiClient.ModName, version = ShimejiClient.ModVersion)
public class ShimejiClient {
    public static final String ModID = "shimeji";
    public static final String ModName = "Shimeji Client";
    public static final String ModNameWithoutSpace = ModName.replace(" ", "");
    public static final String ModVersion = "2.2";
    public static final String[] Authors = {"enokitoraisu", "kazubon12"};
    public static final String Message = "Best Anarchy Client";
    public static final String PrefixFormat = String.format("\u00A77[\u00A7a%s\u00A77]\u00A7r ", ModName);
    public static final String CmdPrefix = ">";
    public static final int CHAT_DELETE_ID = (int) Math.ceil(Math.random() * Integer.MAX_VALUE);

    public static final Logger logger = LogManager.getLogger(ModID);

    public static CommandManager commandManager;
    public static ModuleManager moduleManager;
    public static ConfigManager configManager;
    public static SpotifyManager spotifyManager;
    public static ScreenManager screenManager;
    public static ListManager listManager;

    @EventHandler
    public void postInit(FMLPostInitializationEvent event) {
        Minecraft.getMinecraft().getRenderManager().getSkinMap().values().forEach(render -> render.addLayer(new Capes.RenderCape(render)));
    }

    @EventHandler
    public void Init(FMLInitializationEvent event) {
        logger.info(String.format("Initializing %s...", ModName));

        long start = System.currentTimeMillis();
        moduleManager = new ModuleManager();
        listManager = new ListManager();
        configManager = new ConfigManager(ModNameWithoutSpace.toLowerCase());
        configManager.loadConfigs();
        listManager.reloadUUIDs();
        screenManager = new ScreenManager();
        commandManager = new CommandManager();

        MinecraftForge.EVENT_BUS.register(new Listener());
        FontUtil.initialize();
        long end = System.currentTimeMillis();

        logger.info(String.format("Initialized %s in %sms !!", ModName, end - start));
    }
}
