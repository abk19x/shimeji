package me.enokitoraisu.shimejiclient.event;

public class TextEvent extends EventManager {
    public String text;

    public TextEvent(String text) {
        this.text = text;
    }

    public String getText() {
        return this.text;
    }

    public void setText(String text) {
        this.text = text;
    }
}
