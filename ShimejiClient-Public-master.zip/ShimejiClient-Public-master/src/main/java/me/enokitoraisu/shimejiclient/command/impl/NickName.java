package me.enokitoraisu.shimejiclient.command.impl;

import me.enokitoraisu.shimejiclient.ShimejiClient;
import me.enokitoraisu.shimejiclient.command.Command;
import me.enokitoraisu.shimejiclient.manager.ListManager;
import me.spotify.gson.JsonElement;
import me.spotify.gson.JsonParser;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.UUID;

@SuppressWarnings("unused")
public class NickName extends Command {
    public NickName() {
        super("NickName", "Add to the player to the client side only nickname.");
    }

    public static Object[] getUUID(String username) {
        try {
            URL url = new URL(String.format("https://api.mojang.com/users/profiles/minecraft/%s", username));
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();

            connection.setRequestMethod("GET");

            BufferedReader in = new BufferedReader(new InputStreamReader(connection.getInputStream()));
            String inputLine;
            StringBuilder content = new StringBuilder();
            while ((inputLine = in.readLine()) != null) {
                content.append(inputLine);
            }
            in.close();

            JsonElement jsonElement = JsonParser.parseString(content.toString());

            JsonElement uuid = jsonElement.getAsJsonObject().get("id");
            JsonElement name = jsonElement.getAsJsonObject().get("name");

            connection.disconnect();
            if (uuid == null || name == null)
                return null;
            else
                return new Object[]{UUID.fromString(uuid.getAsString().replaceFirst("(\\p{XDigit}{8})(\\p{XDigit}{4})(\\p{XDigit}{4})(\\p{XDigit}{4})(\\p{XDigit}+)", "$1-$2-$3-$4-$5")), name.getAsString()};
        } catch (IOException e) {
            return null;
        }
    }

    @Override
    public void onCommand() {
        if (args().length == 3) {
            String username = arg(1);
            String nickname = arg(2);
            if (username.equalsIgnoreCase("del")) {
                new Thread(() -> {
                    Object[] uuid = getUUID(nickname);
                    if (uuid != null && ShimejiClient.listManager.nicknames.containsKey((UUID) uuid[0])) {
                        ShimejiClient.listManager.nicknames.remove((UUID) uuid[0]);
                        sendMessage("Deleted Nick");
                    } else {
                        sendMessage("Invalid Username");
                    }
                }).start();
            } else {
                new Thread(() -> {
                    Object[] uuid = getUUID(username);
                    if (uuid != null) {
                        ListManager.Nick oldNick = ShimejiClient.listManager.nicknames.get((UUID) uuid[0]);
                        if (oldNick == null) {
                            ShimejiClient.listManager.nicknames.put((UUID) uuid[0], new ListManager.Nick((String) uuid[1], nickname));
                            sendMessage("Saved Nick");
                        } else {
                            oldNick.setNickname(nickname);
                            sendMessage("Update Nick");
                        }
                    } else {
                        sendMessage("Invalid Username");
                    }
                }).start();
            }
        } else if (args().length == 2 && arg(1).equalsIgnoreCase("reload")) {
            try {
                ShimejiClient.listManager.reloadUUIDs();
                sendMessage("Reload Nicks");
            } catch (Throwable e) {
                sendMessage("Error Reload Nicks " + e);
            }
        } else {
            sendMessage("Usage >NickName <Username> <NickName>, >NickName del <Username>, >NickName reload");
        }
    }
}
