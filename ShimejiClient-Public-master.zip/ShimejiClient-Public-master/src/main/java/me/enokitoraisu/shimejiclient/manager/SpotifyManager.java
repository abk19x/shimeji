package me.enokitoraisu.shimejiclient.manager;

import com.sun.net.httpserver.HttpServer;
import me.enokitoraisu.shimejiclient.ShimejiClient;
import me.spotify.webapi.SpotifyApi;
import me.spotify.webapi.SpotifyHttpManager;
import me.spotify.webapi.exceptions.SpotifyWebApiException;
import me.spotify.webapi.modelobjects.credentials.AuthorizationCodeCredentials;
import me.spotify.webapi.modelobjects.miscellaneous.CurrentlyPlayingContext;
import me.spotify.webapi.modelobjects.specification.Track;
import me.spotify.webapi.requests.authorization.authorization_code.AuthorizationCodeUriRequest;
import me.spotify.webapi.requests.authorization.authorization_code.pkce.AuthorizationCodePKCERequest;
import org.apache.hc.core5.http.ParseException;

import java.awt.*;
import java.io.IOException;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

public class SpotifyManager {
    private final static String CODE_CHALLENGE = "w6iZIj99vHGtEx_NVl9u3sthTN646vvkiP8OMCGfPmo";
    private final static String CODE_VERIFIER = "NlJx4kD4opk4HY7zBM6WfUHxX7HoF8A2TUhOIPGA74w";
    private final ExecutorService executorService = Executors.newSingleThreadExecutor();
    public SpotifyApi spotifyApi;
    public AuthorizationCodeUriRequest authCodeUriRequest;
    public Track currentTrack;
    public CurrentlyPlayingContext currentPlayingContext;
    public boolean authenticated;
    private int tokenRefreshInterval = 2;
    private final SpotifyCallBack callback = code -> {
        AuthorizationCodePKCERequest authCodePKCERequest = spotifyApi.authorizationCodePKCE(code, CODE_VERIFIER).build();
        try {
            AuthorizationCodeCredentials authCredentials = authCodePKCERequest.execute();
            spotifyApi.setAccessToken(authCredentials.getAccessToken());
            spotifyApi.setRefreshToken(authCredentials.getRefreshToken());
            tokenRefreshInterval = authCredentials.getExpiresIn();
            authenticated = true;
            new Thread(() -> {
                while (!Thread.currentThread().isInterrupted()) {
                    try {
                        TimeUnit.SECONDS.sleep(tokenRefreshInterval - 2);
                        System.out.println("Refreshing token...");
                        AuthorizationCodeCredentials refreshRequest = spotifyApi.authorizationCodePKCERefresh().build().execute();
                        spotifyApi.setAccessToken(refreshRequest.getAccessToken());
                        spotifyApi.setRefreshToken(refreshRequest.getRefreshToken());
                        tokenRefreshInterval = refreshRequest.getExpiresIn();
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            }).start();
            new Thread(() -> {
                while (!Thread.currentThread().isInterrupted()) {
                    try {
                        TimeUnit.SECONDS.sleep(1);
                        CurrentlyPlayingContext currentlyPlayingContext = spotifyApi.getInformationAboutUsersCurrentPlayback().build().execute();
                        String currentTrackId = currentlyPlayingContext.getItem().getId();
                        this.currentTrack = spotifyApi.getTrack(currentTrackId).build().execute();
                        this.currentPlayingContext = currentlyPlayingContext;
                    } catch (Exception ignored) {
                    }
                }
            }).start();
        } catch (Exception e) {
            e.printStackTrace();
        }
    };
    private HttpServer callbackServer;

    public void startConnection() {
        if (!authenticated) {
            try {
                Desktop.getDesktop().browse(authCodeUriRequest.execute());
                executorService.submit(() -> {
                    try {
                        if (callbackServer != null) {
                            callbackServer.stop(0);
                        }
                        callbackServer = HttpServer.create(new InetSocketAddress(4030), 0);
                        callbackServer.createContext("/", context -> {
                            callback.codeCallback(context.getRequestURI().getQuery().split("=")[1]);
                            final String messageSuccess = context.getRequestURI().getQuery().contains("code")
                                    ? "<!DOCTYPE html><html lang=\"en\"><head><meta charset=\"UTF-8\"><title>Success Connection</title><link href=\"https://fonts.googleapis.com/css2?family=Zen+Kaku+Gothic+New:wght@700&display=swap\" rel=\"stylesheet\"><style>h1, h3 {font-family: 'Zen Kaku Gothic New', cursive;}</style></head><body><h1>Successfully authorized.</h1><h3>You can now close this window</h3></body></html>"
                                    : "Unable to Authorize client.";
                            context.sendResponseHeaders(200, messageSuccess.length());
                            OutputStream out = context.getResponseBody();
                            out.write(messageSuccess.getBytes());
                            out.close();
                            callbackServer.stop(0);
                        });
                        callbackServer.start();
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                });
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

    }


    public void build(String clientID) {
        spotifyApi = new SpotifyApi.Builder().setClientId(clientID)
                .setRedirectUri(SpotifyHttpManager.makeUri("http://localhost:4030/"))
                .build();

        authCodeUriRequest = spotifyApi.authorizationCodePKCEUri(CODE_CHALLENGE)
                .code_challenge_method("S256")
                .scope("user-read-playback-state user-read-playback-position user-modify-playback-state user-read-currently-playing")
                .build();
    }

    public void changeRepeatState(String state) {
        if (state == null || state.isEmpty()) return;
        try {
            ShimejiClient.spotifyManager.spotifyApi.setRepeatModeOnUsersPlayback(state).build().execute();
        } catch (IOException | SpotifyWebApiException | ParseException ignored) {
        }
    }

    public void skipToPreviousTrack() {
        try {
            spotifyApi.skipUsersPlaybackToPreviousTrack().build().execute();
        } catch (IOException | SpotifyWebApiException | ParseException ignored) {
        }
    }

    public void skipTrack() {
        try {
            spotifyApi.skipUsersPlaybackToNextTrack().build().execute();
        } catch (IOException | SpotifyWebApiException | ParseException ignored) {
        }
    }

    public void toggleShuffleState() {
        try {
            spotifyApi.toggleShuffleForUsersPlayback(!currentPlayingContext.getShuffle_state()).build().execute();
        } catch (IOException | SpotifyWebApiException | ParseException ignored) {
        }
    }

    public void pausePlayback() {
        try {
            spotifyApi.pauseUsersPlayback().build().execute();
        } catch (IOException | SpotifyWebApiException | ParseException ignored) {
        }
    }

    public void resumePlayback() {
        try {
            spotifyApi.startResumeUsersPlayback().build().execute();
        } catch (IOException | SpotifyWebApiException | ParseException ignored) {
        }
    }

    public boolean isPlaying() {
        return currentPlayingContext.getIs_playing();
    }

    public interface SpotifyCallBack {
        void codeCallback(final String code);
    }
}

