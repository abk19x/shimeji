package me.enokitoraisu.shimejiclient.utils.math;

import me.enokitoraisu.shimejiclient.utils.interfaces.Util;

import java.awt.*;
import java.awt.image.BufferedImage;

public class ColorUtil implements Util {
    public static float[] getHSB(float r, float g, float b) {
        float hue, saturation, brightness;
        float[] hsbValues = new float[3];
        float cmax = Math.max(r, g);
        if (b > cmax) cmax = b;
        float cmin = Math.min(r, g);
        if (b < cmin) cmin = b;

        brightness = cmax;
        if (cmax != 0) saturation = (cmax - cmin) / cmax;
        else saturation = 0;

        if (saturation == 0) {
            hue = 0;
        } else {
            float redc = (cmax - r) / (cmax - cmin);
            float greenc = (cmax - g) / (cmax - cmin);
            float bluec = (cmax - b) / (cmax - cmin);
            if (r == cmax) hue = bluec - greenc;
            else if (g == cmax) hue = 2 + redc - bluec;
            else hue = 4 + greenc - redc;
            hue = hue / 6;
            if (hue < 0) hue = hue + 1;
        }
        hsbValues[0] = hue;
        hsbValues[1] = saturation;
        hsbValues[2] = brightness;

        return hsbValues;
    }

    public static int toRGBA(int red, int green, int blue) {
        return ColorUtil.toRGBA(red, green, blue, 255);
    }

    public static int toRGBA(int n, int n2, int n3, int n4) {
        return (n << 16) + (n2 << 8) + n3 + (n4 << 24);
    }

    public static int toRGBA(Color color) {
        return (color.getRed() << 16) + (color.getGreen() << 8) + color.getBlue() + (color.getAlpha() << 24);
    }

    public static int toRGBA(float f, float f2, float f3, float f4) {
        return ColorUtil.toRGBA((int) (f * 255.0f), (int) (f2 * 255.0f), (int) (f3 * 255.0f), (int) (f4 * 255.0f));
    }

    public static int getRainbow(float seconds, float saturation, float brightness, long index) {
        float hue = ((System.currentTimeMillis() + index) % (int) (seconds * 1000)) / (seconds * 1000);
        return Color.HSBtoRGB(hue, saturation, brightness);
    }

    public static int getBrightness(float hue, float saturation, float min, float max, float seconds, long index) {
        float currentTime = ((System.currentTimeMillis() + index) % (int) (seconds * 1000)) / (seconds * 1000);
        if (currentTime <= 0.5) {
            return Color.HSBtoRGB(hue, saturation, min + (max - min) * (currentTime * 2));
        } else {
            return Color.HSBtoRGB(hue, saturation, max - (max - min) * ((currentTime - 0.5f) * 2));
        }
    }

    public static Color averageColor(BufferedImage bi, int width, int height, int pixelStep) {
        int[] color = new int[3];
        for (int x = 0; x < width; x += pixelStep) {
            for (int y = 0; y < height; y += pixelStep) {
                Color pixel = new Color(bi.getRGB(x, y));
                color[0] += pixel.getRed();
                color[1] += pixel.getGreen();
                color[2] += pixel.getBlue();
            }
        }
        int num = (width * height) / (pixelStep * pixelStep);
        return new Color(color[0] / num, color[1] / num, color[2] / num);
    }

    public static Color darker(Color color, float v) {
        return new Color(Math.max((int) (color.getRed() * v), 0),
                Math.max((int) (color.getGreen() * v), 0),
                Math.max((int) (color.getBlue() * v), 0),
                color.getAlpha());
    }
}

