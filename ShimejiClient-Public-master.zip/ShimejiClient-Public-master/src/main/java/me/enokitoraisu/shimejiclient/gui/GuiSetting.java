package me.enokitoraisu.shimejiclient.gui;

import me.enokitoraisu.shimejiclient.module.impl.client.Gui;

public class GuiSetting {
    public static int getAccent() {
        return Gui.INSTANCE.color.getIntValue();
    }
}
