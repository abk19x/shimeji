package me.enokitoraisu.shimejiclient.gui.friend;

import me.enokitoraisu.shimejiclient.utils.other.Base64Util;
import me.enokitoraisu.shimejiclient.utils.renderer.RenderUtil;
import me.enokitoraisu.shimejiclient.utils.renderer.font.FontUtil;
import me.spotify.gson.JsonElement;
import me.spotify.gson.JsonObject;
import me.spotify.gson.JsonParser;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.renderer.texture.DynamicTexture;
import net.minecraft.util.ResourceLocation;
import org.lwjgl.input.Keyboard;

import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.datatransfer.DataFlavor;
import java.awt.datatransfer.UnsupportedFlavorException;
import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.List;
import java.util.*;

public class FriendGui extends GuiScreen {
    private static final Map<String, String> skinMap = new HashMap<>();
    private static final List<String> players = new ArrayList<>();
    private boolean keyWaiting = false;
    private String searchFieldText = "";
    private final int rectWidth = 450;
    private final int rectHeight = 300;
    private int rectX;
    private int rectY;
    private int listBoxWidth;
    private int listBoxHeight;

    public static Object search(String search, GetType getType) {
        try {
            URL url;
            switch (getType) {
                case SKIN:
                case USERNAME:
                    url = new URL(String.format("https://sessionserver.mojang.com/session/minecraft/profile/%s", search.replace("-", "")));
                    break;
                case UUID:
                case PROFILES:
                    url = new URL(String.format("https://api.mojang.com/users/profiles/minecraft/%s", search));
                    break;
                default:
                    return null;
            }
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();

            connection.setRequestMethod("GET");

            BufferedReader in = new BufferedReader(new InputStreamReader(connection.getInputStream()));
            String inputLine;
            StringBuilder content = new StringBuilder();
            while ((inputLine = in.readLine()) != null) {
                content.append(inputLine);
            }
            in.close();
            connection.disconnect();

            switch (getType) {
                case PROFILES:
                    return JsonParser.parseString(content.toString()).getAsJsonObject();
                case USERNAME:
                    return JsonParser.parseString(content.toString()).getAsJsonObject().get("name").getAsString();
                case UUID:
                    return JsonParser.parseString(content.toString()).getAsJsonObject().get("id").getAsString();
                case SKIN:
                    JsonElement value = JsonParser.parseString(content.toString()).getAsJsonObject().get("properties").getAsJsonArray().get(0).getAsJsonObject().get("value");
                    JsonElement skin = JsonParser.parseString(Base64Util.getDecode(value.getAsString())).getAsJsonObject().get("textures").getAsJsonObject().get("SKIN").getAsJsonObject().get("url");

                    if (skin == null)
                        return null;

                    InputStream is = new URL(skin.getAsString()).openStream();
                    ByteArrayOutputStream stream = new ByteArrayOutputStream();
                    byte[] buffer = new byte[1024];
                    int read;
                    while ((read = is.read(buffer, 0, buffer.length)) != -1) stream.write(buffer, 0, read);
                    is.close();
                    stream.flush();
                    return Base64.getEncoder().encodeToString(stream.toByteArray());
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    @Override
    public void initGui() {
        this.rectX = width / 2 - rectWidth / 2;
        this.rectY = height / 2 - rectHeight / 2;
        this.listBoxWidth = rectWidth / 2 - 10;
        this.listBoxHeight = rectHeight - 35;
    }

    @Override
    public void drawScreen(int mouseX, int mouseY, float partialTicks) {
        RenderUtil.drawRect(rectX, rectY, rectWidth, rectHeight, 0x80000000);

        //Player List (World)
        RenderUtil.drawRect(rectX + 5, rectY + 5, listBoxWidth, listBoxHeight, 0x80000000);
        FontUtil.sfui20.drawStringWithShadow("Player List", rectX + 10, rectY + 10, -1);
        int y = rectY + 30;
        for (String player : players) {
            String headImage = skinMap.get(player);
            if (headImage != null) {
                try {
                    byte[] decodedImage = Base64.getDecoder().decode(headImage);
                    DynamicTexture dynamicTexture = new DynamicTexture(ImageIO.read(new ByteArrayInputStream(decodedImage)));
                    RenderUtil.drawHead(new ResourceLocation("players/" + player), dynamicTexture, rectX + 20, y - 1.5F, 12, 12);
                } catch (IOException e) {
                    e.printStackTrace();
                }
            } else {
                RenderUtil.drawRect(rectX + 20, y - 1.5F, 12, 12, 0xFF000000);
                mc.fontRenderer.drawString("?", rectX + 20 + 6.5F - mc.fontRenderer.getStringWidth("?") / 2F, y - 1 + 6 - mc.fontRenderer.FONT_HEIGHT / 2F, -1, false);
            }
            FontUtil.sfui18.drawStringWithShadow(player, rectX + 40, y, -1);
            y += 15;
        }

        //Search Field
        RenderUtil.drawRect(rectX + 5, rectY + listBoxHeight + 10, listBoxWidth - 60, 20, 0x80000000);
        if (!keyWaiting && searchFieldText.isEmpty())
            FontUtil.sfui20.drawStringWithShadow("\u00A77\u00A7oUsername...", rectX + 10, rectY + listBoxHeight + 20 - FontUtil.sfui20.getHeight() / 2F, -1);
        else
            FontUtil.sfui20.drawStringWithShadow(searchFieldText, rectX + 10, rectY + listBoxHeight + 20 - FontUtil.sfui20.getHeight() / 2F, -1);

        if (keyWaiting && System.currentTimeMillis() % 800 > 400) {
            FontUtil.sfui20.drawStringWithShadow("_", rectX + 10 + FontUtil.sfui20.getStringWidth(searchFieldText), rectY + listBoxHeight + 20 - FontUtil.sfui20.getHeight() / 2F, -1);
        }

        RenderUtil.drawRect(rectX + listBoxWidth - 50, rectY + listBoxHeight + 10, 55, 20, 0x80000000);
        FontUtil.sfui20.drawStringWithShadow("Search", rectX + listBoxWidth - 50 + 27.5f - FontUtil.sfui20.getStringWidth("Search") / 2f, rectY + listBoxHeight + 20 - FontUtil.sfui20.getHeight() / 2f, -1);

        //Friend List
        RenderUtil.drawRect(rectX + listBoxWidth + 15, rectY + 5, listBoxWidth, listBoxHeight, 0x80000000);
        FontUtil.sfui20.drawStringWithShadow("Friend List", rectX + listBoxWidth + 20, rectY + 10, -1);
    }

    @Override
    public void mouseClicked(int mouseX, int mouseY, int mouseButton) {
        if (mouseButton == 0) {
            if (bounding(mouseX, mouseY, rectX + 5, rectY + listBoxHeight + 10, listBoxWidth - 60, 20)) {
                keyWaiting = true;
                Keyboard.enableRepeatEvents(true);
            }

            if (bounding(mouseX, mouseY, rectX + listBoxWidth - 50, rectY + listBoxHeight + 10, 55, 20)) {
                String lastSearchFieldText = searchFieldText;
                if (!lastSearchFieldText.isEmpty()) {
                    if (containIgnoreCase(players, lastSearchFieldText)) return;
                    JsonObject searchResult = (JsonObject) search(lastSearchFieldText, GetType.PROFILES);
                    if (searchResult.get("id") == null) return;
                    String image = (String) search(searchResult.get("id").getAsString(), GetType.SKIN);
                    String name = searchResult.get("name").getAsString();
                    players.add(name);
                    skinMap.put(name, image);
                    keyWaiting = false;
                    Keyboard.enableRepeatEvents(false);
                    searchFieldText = "";
                }
            }
        }
    }

    public boolean bounding(int mouseX, int mouseY, int x, int y, int width, int height) {
        return x < mouseX && x + width > mouseX && y < mouseY && y + height > mouseY;
    }

    @Override
    public void keyTyped(char typedChar, int keyCode) {
        try {
            if (keyWaiting) {
                switch (keyCode) {
                    case Keyboard.KEY_ESCAPE:
                    case Keyboard.KEY_RETURN:
                        keyWaiting = false;
                        Keyboard.enableRepeatEvents(false);
                        break;
                    case Keyboard.KEY_BACK:
                        searchFieldText = removeLastChar(searchFieldText);
                }

                if (Keyboard.isKeyDown(Keyboard.KEY_LCONTROL) || Keyboard.isKeyDown(Keyboard.KEY_RCONTROL) || Keyboard.isKeyDown(Keyboard.KEY_LMETA) || Keyboard.isKeyDown(Keyboard.KEY_RMETA)) {
                    if (keyCode == Keyboard.KEY_V) {
                        try {
                            searchFieldText += Toolkit.getDefaultToolkit().getSystemClipboard().getData(DataFlavor.stringFlavor);
                            if (searchFieldText.length() >= 16) {
                                searchFieldText = searchFieldText.substring(0, 16);
                            }
                        } catch (UnsupportedFlavorException ignored) {
                        }
                    }
                } else {
                    if (isValidCharacter(typedChar) && searchFieldText.length() < 16)
                        searchFieldText += typedChar;
                }

            } else {
                super.keyTyped(typedChar, keyCode);
            }
        } catch (IOException ignored) {
        }
    }

    @Override
    public void onGuiClosed() {
        keyWaiting = false;
        Keyboard.enableRepeatEvents(false);
    }

    public boolean isValidCharacter(char c) {
        return (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || (c >= '0' && c <= '9') || (c == '_');
    }

    public String removeLastChar(String str) {
        String output = "";
        if (str != null && str.length() > 0) {
            output = str.substring(0, str.length() - 1);
        }
        return output;
    }

    public boolean containIgnoreCase(List<String> list, String text) {
        for (String s : list) {
            if (s.equalsIgnoreCase(text))
                return true;
        }

        return false;
    }

    public enum GetType {
        UUID, USERNAME, PROFILES, SKIN
    }
}
