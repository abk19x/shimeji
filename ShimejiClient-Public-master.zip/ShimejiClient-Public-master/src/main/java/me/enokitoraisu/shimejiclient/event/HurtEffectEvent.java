package me.enokitoraisu.shimejiclient.event;

public class HurtEffectEvent extends EventManager {
}
