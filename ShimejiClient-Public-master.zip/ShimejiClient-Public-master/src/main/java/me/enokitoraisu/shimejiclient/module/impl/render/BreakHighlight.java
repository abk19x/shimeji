package me.enokitoraisu.shimejiclient.module.impl.render;

import me.enokitoraisu.shimejiclient.mixin.AccessorRenderGlobal;
import me.enokitoraisu.shimejiclient.module.Category;
import me.enokitoraisu.shimejiclient.module.Module;
import me.enokitoraisu.shimejiclient.utils.renderer.RenderUtil3D;
import me.enokitoraisu.shimejiclient.value.values.ColorValue;
import me.enokitoraisu.shimejiclient.value.values.IntegerValue;
import net.minecraft.client.renderer.DestroyBlockProgress;
import org.lwjgl.input.Keyboard;

import java.awt.*;
import java.util.Map;

@SuppressWarnings("unused")
public class BreakHighlight extends Module {
    private final IntegerValue alpha = register(new IntegerValue("LineAlpha", 127, 0, 255));
    private final IntegerValue boxAlpha = register(new IntegerValue("BoxAlpha", 127, 0, 255));
    private final ColorValue selfColor = register(new ColorValue("SelfColor", new Color(0x00FF00), false));
    private final ColorValue playerColor = register(new ColorValue("PlayerColor", new Color(0xFF0000), false));

    public BreakHighlight() {
        super("BreakHighlight", Category.RENDER, Keyboard.KEY_NONE);
    }

    @Override
    public void onRender3D() {
        if (!fullNullCheck()) return;
        for (Map.Entry<Integer, DestroyBlockProgress> progressEntry : ((AccessorRenderGlobal) mc.renderGlobal).getDamagedBlocks().entrySet()) {
            RenderUtil3D.drawHeightScaledBox(
                    progressEntry.getValue().getPosition(),
                    progressEntry.getValue().getPartialBlockDamage() / 10F,
                    new int[] {
                            getBoxColor(mc.player == mc.world.getEntityByID(progressEntry.getKey()) ? selfColor.getIntValue() : playerColor.getIntValue()),
                            getLineColor(mc.player == mc.world.getEntityByID(progressEntry.getKey()) ? selfColor.getIntValue() : playerColor.getIntValue())
                    });
            RenderUtil3D.drawString3D(progressEntry.getValue().getPosition(), mc.world.getEntityByID(progressEntry.getKey()).getName(), mc.fontRenderer, true, -1);
        }
    }

    public int getLineColor(int color) {
        return (color & 0x00FFFFFF) | (alpha.getValue() << 24);
    }

    public int getBoxColor(int color) {
        return (color & 0x00FFFFFF) | (boxAlpha.getValue() << 24);
    }
}
