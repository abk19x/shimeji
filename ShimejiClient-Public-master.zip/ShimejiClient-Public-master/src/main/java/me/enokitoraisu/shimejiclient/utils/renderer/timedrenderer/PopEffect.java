package me.enokitoraisu.shimejiclient.utils.renderer.timedrenderer;

import me.enokitoraisu.shimejiclient.utils.interfaces.TimedRenderer;
import me.enokitoraisu.shimejiclient.utils.math.Easings;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.math.AxisAlignedBB;
import org.lwjgl.opengl.GL11;

import java.awt.*;

public class PopEffect implements TimedRenderer {
    private final EntityPlayer player;
    private final long age;
    private final long time;

    public PopEffect(EntityPlayer player, long age, long time) {
        this.player = player;
        this.age = age;
        this.time = time;
    }

    @Override
    public long getCreationTime() {
        return time;
    }

    @Override
    public long getMaxAge() {
        return age;
    }

    public void render(Color color, boolean reverse) {
        float a = color.getAlpha() / 255F - getProgress();
        float r = color.getRed() / 255F;
        float g = color.getGreen() / 255F;
        float b = color.getBlue() / 255F;

        double posX = player.lastTickPosX + (player.posX - player.lastTickPosX) * mc.getRenderPartialTicks() - mc.getRenderManager().viewerPosX;
        double posY = player.lastTickPosY + (player.posY - player.lastTickPosY) * mc.getRenderPartialTicks() - mc.getRenderManager().viewerPosY;
        double posZ = player.lastTickPosZ + (player.posZ - player.lastTickPosZ) * mc.getRenderPartialTicks() - mc.getRenderManager().viewerPosZ;

        GlStateManager.enableBlend();
        GlStateManager.disableTexture2D();
        GlStateManager.disableDepth();
        GlStateManager.disableCull();
        GlStateManager.disableAlpha();
        GlStateManager.translate(posX, posY, posZ);
        //GlStateManager.glLineWidth(width);
        //GL11.glEnable(GL11.GL_LINE_SMOOTH);
        GlStateManager.color(r, g, b, a);
        GL11.glBegin(GL11.GL_QUAD_STRIP);
        for (int i = 0; i <= 180; i++) {
            AxisAlignedBB boundingBox = player.getRenderBoundingBox();
            double x = Math.sin(i * Math.PI / 90) * (boundingBox.maxX - boundingBox.minX);
            double z = Math.cos(i * Math.PI / 90) * (boundingBox.maxZ - boundingBox.minZ);
            if (reverse) {
                GL11.glVertex3d(x, (boundingBox.maxY - boundingBox.minY), z);
                GL11.glVertex3d(x, (boundingBox.maxY - boundingBox.minY) * Easings.cubicOut(getProgress()), z);
            } else {
                GL11.glVertex3d(x, 0, z);
                GL11.glVertex3d(x, (boundingBox.maxY - boundingBox.minY) * (1 - Easings.cubicOut(getProgress())), z);
            }
        }
        GL11.glEnd();
        GlStateManager.color(1F, 1F, 1F, 1F);
        //GL11.glDisable(GL11.GL_LINE_SMOOTH);
        GlStateManager.translate(-posX, -posY, -posZ);
        GlStateManager.enableAlpha();
        GlStateManager.enableDepth();
        GlStateManager.enableCull();
        GlStateManager.depthMask(true);
        GlStateManager.enableTexture2D();
        GlStateManager.disableBlend();
    }
}
