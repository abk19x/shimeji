package me.enokitoraisu.shimejiclient.utils.renderer.timedrenderer;

import me.enokitoraisu.shimejiclient.utils.interfaces.TimedRenderer;

public class Line implements TimedRenderer {
    public final double x;
    public final double y;
    public final double z;
    private final long age;
    private final long time;

    public Line(double x, double y, double z, long age) {
        this.x = x;
        this.y = y;
        this.z = z;
        this.age = age;
        this.time = System.currentTimeMillis();
    }

    @Override
    public long getCreationTime() {
        return time;
    }

    @Override
    public long getMaxAge() {
        return age;
    }
}
