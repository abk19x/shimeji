package me.enokitoraisu.shimejiclient.module.impl.hud;

import me.enokitoraisu.shimejiclient.module.Category;
import me.enokitoraisu.shimejiclient.module.HudModule;
import me.enokitoraisu.shimejiclient.value.values.IntegerValue;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.util.ResourceLocation;
import org.lwjgl.input.Keyboard;

@SuppressWarnings("unused")
public class Icon extends HudModule {
    private final IntegerValue size = register(new IntegerValue("Size", 100, 0, 500));

    public Icon() {
        super("Icon", Category.HUD, Keyboard.KEY_NONE, 0, 0, 100, 100);
    }

    @Override
    public boolean drawScreen() {
        setWidth(size.getValue());
        setHeight(size.getValue());
        mc.getTextureManager().bindTexture(new ResourceLocation("shimeji/image/logo.png"));
        ScaledResolution scale = new ScaledResolution(mc);
        GlStateManager.color(1F, 1F, 1F, 1F);
        GlStateManager.disableBlend();
        Gui.drawModalRectWithCustomSizedTexture(getX(), getY(), 0, 0, getWidth(), getHeight(), getWidth(), getHeight());
        GlStateManager.enableBlend();
        return true;
    }
}
