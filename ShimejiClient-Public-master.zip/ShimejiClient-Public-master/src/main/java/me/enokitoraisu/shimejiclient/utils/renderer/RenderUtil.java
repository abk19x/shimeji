package me.enokitoraisu.shimejiclient.utils.renderer;

import me.enokitoraisu.shimejiclient.utils.interfaces.Util;
import me.enokitoraisu.shimejiclient.utils.math.MathUtil;
import net.minecraft.client.entity.AbstractClientPlayer;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.renderer.BufferBuilder;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.RenderHelper;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.texture.ITextureObject;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.item.ItemStack;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.math.MathHelper;
import org.lwjgl.opengl.GL11;

import static org.lwjgl.opengl.GL11.*;

public class RenderUtil implements Util {
    public static void drawRect(float x, float y, float width, float height, int color) {
        GuiScreen.drawRect((int) x, (int) y, (int) (x + width), (int) (y + height), color);
    }

    public static void drawHorizontalGradientRect(float x, float y, float width, float height, int color1, int color2) {
        float f5 = (float) (color1 >> 24 & 0xFF) / 255.0f;
        float f6 = (float) (color1 >> 16 & 0xFF) / 255.0f;
        float f7 = (float) (color1 >> 8 & 0xFF) / 255.0f;
        float f8 = (float) (color1 & 0xFF) / 255.0f;

        float f9 = (float) (color2 >> 24 & 0xFF) / 255.0f;
        float f10 = (float) (color2 >> 16 & 0xFF) / 255.0f;
        float f11 = (float) (color2 >> 8 & 0xFF) / 255.0f;
        float f12 = (float) (color2 & 0xFF) / 255.0f;
        GlStateManager.disableTexture2D();
        GlStateManager.enableBlend();
        GlStateManager.disableAlpha();
        GlStateManager.tryBlendFuncSeparate(GlStateManager.SourceFactor.SRC_ALPHA, GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA, GlStateManager.SourceFactor.ONE, GlStateManager.DestFactor.ZERO);
        GlStateManager.shadeModel(7425);
        Tessellator tessellator = Tessellator.getInstance();
        BufferBuilder bufferBuilder = tessellator.getBuffer();
        bufferBuilder.begin(7, DefaultVertexFormats.POSITION_COLOR);
        bufferBuilder.pos(x, y, 0.0).color(f6, f7, f8, f5).endVertex();
        bufferBuilder.pos(x, y + height, 0.0).color(f6, f7, f8, f5).endVertex();
        bufferBuilder.pos(x + width, y + height, 0.0).color(f10, f11, f12, f9).endVertex();
        bufferBuilder.pos(x + width, y, 0.0).color(f10, f11, f12, f9).endVertex();
        tessellator.draw();
        GlStateManager.shadeModel(7424);
        GlStateManager.disableBlend();
        GlStateManager.enableAlpha();
        GlStateManager.enableTexture2D();
    }

    public static void drawVerticalGradientRect(float x, float y, float width, float height, int color1, int color2) {
        float f5 = (float) (color1 >> 24 & 0xFF) / 255.0f;
        float f6 = (float) (color1 >> 16 & 0xFF) / 255.0f;
        float f7 = (float) (color1 >> 8 & 0xFF) / 255.0f;
        float f8 = (float) (color1 & 0xFF) / 255.0f;

        float f9 = (float) (color2 >> 24 & 0xFF) / 255.0f;
        float f10 = (float) (color2 >> 16 & 0xFF) / 255.0f;
        float f11 = (float) (color2 >> 8 & 0xFF) / 255.0f;
        float f12 = (float) (color2 & 0xFF) / 255.0f;
        GlStateManager.disableTexture2D();
        GlStateManager.enableBlend();
        GlStateManager.disableAlpha();
        GlStateManager.tryBlendFuncSeparate(GlStateManager.SourceFactor.SRC_ALPHA, GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA, GlStateManager.SourceFactor.ONE, GlStateManager.DestFactor.ZERO);
        GlStateManager.shadeModel(7425);
        Tessellator tessellator = Tessellator.getInstance();
        BufferBuilder bufferBuilder = tessellator.getBuffer();
        bufferBuilder.begin(7, DefaultVertexFormats.POSITION_COLOR);
        bufferBuilder.pos(x, y, 0.0).color(f6, f7, f8, f5).endVertex();
        bufferBuilder.pos(x, y + height, 0.0).color(f10, f11, f12, f9).endVertex();
        bufferBuilder.pos(x + width, y + height, 0.0).color(f10, f11, f12, f9).endVertex();
        bufferBuilder.pos(x + width, y, 0.0).color(f6, f7, f8, f5).endVertex();
        tessellator.draw();
        GlStateManager.shadeModel(7424);
        GlStateManager.disableBlend();
        GlStateManager.enableAlpha();
        GlStateManager.enableTexture2D();
    }

    public static void drawGradientRect(int x, int y, int w, int h, int color1, int color2) {
        drawGradientRect((float) x, (float) y, (float) (x + w), (float) (y + h), color1, color2);
    }

    public static void drawGradientRect(float x, float y, float x2, float y2, int color1, int color2) {
        float f5 = (float) (color1 >> 24 & 0xFF) / 255.0f;
        float f6 = (float) (color1 >> 16 & 0xFF) / 255.0f;
        float f7 = (float) (color1 >> 8 & 0xFF) / 255.0f;
        float f8 = (float) (color1 & 0xFF) / 255.0f;

        float f9 = (float) (color2 >> 24 & 0xFF) / 255.0f;
        float f10 = (float) (color2 >> 16 & 0xFF) / 255.0f;
        float f11 = (float) (color2 >> 8 & 0xFF) / 255.0f;
        float f12 = (float) (color2 & 0xFF) / 255.0f;
        GlStateManager.disableTexture2D();
        GlStateManager.enableBlend();
        GlStateManager.disableAlpha();
        GlStateManager.tryBlendFuncSeparate(GlStateManager.SourceFactor.SRC_ALPHA, GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA, GlStateManager.SourceFactor.ONE, GlStateManager.DestFactor.ZERO);
        GlStateManager.shadeModel(7425);
        Tessellator tessellator = Tessellator.getInstance();
        BufferBuilder bufferBuilder = tessellator.getBuffer();
        bufferBuilder.begin(7, DefaultVertexFormats.POSITION_COLOR);
        bufferBuilder.pos(x, y, 0.0).color(f6, f7, f8, f5).endVertex();
        bufferBuilder.pos(x, y2, 0.0).color(f6, f7, f8, f5).endVertex();
        bufferBuilder.pos(x2, y2, 0.0).color(f10, f11, f12, f9).endVertex();
        bufferBuilder.pos(x2, y, 0.0).color(f10, f11, f12, f9).endVertex();
        tessellator.draw();
        GlStateManager.shadeModel(7424);
        GlStateManager.disableBlend();
        GlStateManager.enableAlpha();
        GlStateManager.enableTexture2D();
    }

    public static void drawModalRectWithCustomSizedTexture(float x, float y, float u, float v, float width, float height, float textureWidth, float textureHeight) {
        float f = 1.0F / textureWidth;
        float f1 = 1.0F / textureHeight;
        Tessellator tessellator = Tessellator.getInstance();
        BufferBuilder bufferbuilder = tessellator.getBuffer();
        bufferbuilder.begin(7, DefaultVertexFormats.POSITION_TEX);
        bufferbuilder.pos(x, y + height, 0.0D).tex(u * f, (v + height) * f1).endVertex();
        bufferbuilder.pos(x + width, y + height, 0.0D).tex((u + width) * f, (v + height) * f1).endVertex();
        bufferbuilder.pos(x + width, y, 0.0D).tex((u + width) * f, v * f1).endVertex();
        bufferbuilder.pos(x, y, 0.0D).tex(u * f, v * f1).endVertex();
        tessellator.draw();
    }

    public static void drawImage(float posX, float posY, float width, float height) {
        glPushMatrix();
        glTranslatef(posX, posY, 0.0f);
        glBegin(7);
        glTexCoord2f(0.0f, 0.0f);
        glVertex3f(0.0f, 0.0f, 0.0f);
        glTexCoord2f(0.0f, 1.0f);
        glVertex3f(0.0f, height, 0.0f);
        glTexCoord2f(1.0f, 1.0f);
        glVertex3f(width, height, 0.0f);
        glTexCoord2f(1.0f, 0.0f);
        glVertex3f(width, 0.0f, 0.0f);
        glEnd();
        glPopMatrix();
    }

    public static void drawCircle(float x, float y, float radius, int color) {
        float red = (float) (color >> 16 & 255) / 255.0F;
        float green = (float) (color >> 8 & 255) / 255.0F;
        float blue = (float) (color & 255) / 255.0F;
        float alpha = (float) (color >> 24 & 255) / 255.0F;

        GlStateManager.disableTexture2D();
        GlStateManager.enableBlend();
        GlStateManager.tryBlendFuncSeparate(GlStateManager.SourceFactor.SRC_ALPHA, GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA, GlStateManager.SourceFactor.ONE, GlStateManager.DestFactor.ZERO);
        GlStateManager.color(red, green, blue, alpha);
        glEnable(GL_LINE_SMOOTH);
        glBegin(GL_POLYGON);
        for (int i = 0; i <= 360; ++i)
            glVertex2d(x + MathHelper.sin(i * MathUtil.PI / 180F) * radius, y + MathHelper.cos(i * MathUtil.PI / 180F) * radius);
        glEnd();
        glBegin(GL_LINE_LOOP);
        for (int i = 0; i <= 360; ++i)
            glVertex2d(x + MathHelper.sin(i * MathUtil.PI / 180F) * radius, y + MathHelper.cos(i * MathUtil.PI / 180F) * radius);
        glColor4d(1.0, 1.0, 1.0, 1.0);
        glEnd();
        glDisable(GL_LINE_SMOOTH);
        GlStateManager.disableBlend();
        GlStateManager.enableTexture2D();
        GlStateManager.color(1.0f, 1.0f, 1.0f, 1.0f);
    }

    public static void drawRectCircle(float x, float y, float width, float height, float lastMouseX, float lastMouseY, float value, int color) {
        float leftWidth = Math.min(width, Math.max(lastMouseX, x) - x);
        float rightWidth = width - leftWidth;
        float topHeight = Math.min(height, Math.max(lastMouseY, y) - y);
        float bottomHeight = height - topHeight;

        float radius = Math.max(width + (Math.max(leftWidth, rightWidth) - Math.min(leftWidth, rightWidth)), height + (Math.max(topHeight, bottomHeight) - Math.min(topHeight, bottomHeight)));

        GlStateManager.color(1F, 1F, 1F, 1F);
        GlStateManager.enableBlend();
        GlStateManager.disableTexture2D();
        GlStateManager.tryBlendFuncSeparate(GlStateManager.SourceFactor.SRC_ALPHA, GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA, GlStateManager.SourceFactor.ONE, GlStateManager.DestFactor.ZERO);
        GlStateManager.color((color >> 16 & 0xFF) / 255.0F, (color >> 8 & 0xFF) / 255.0F, (color & 0xFF) / 255.0F, (color >> 24 & 0xFF) / 255.0F);
        GL11.glBegin(GL11.GL_POLYGON);
        for (int i = 0; i <= 360; i++) {
            float xRadius = MathHelper.sin(i * MathUtil.PI / 180F) * (radius * value);
            float yRadius = MathHelper.cos(i * MathUtil.PI / 180F) * (radius * value);
            if (0 >= xRadius) {
                xRadius = Math.max(xRadius, -leftWidth);
            } else {
                xRadius = Math.min(xRadius, rightWidth);
            }

            if (0 >= yRadius) {
                yRadius = Math.max(yRadius, -topHeight);
            } else {
                yRadius = Math.min(yRadius, bottomHeight);
            }

            GL11.glVertex2d(x + leftWidth + xRadius, y + topHeight + yRadius);
        }
        GL11.glEnd();
        GlStateManager.enableTexture2D();
        GlStateManager.disableBlend();
    }

    public static void drawDoubleRect(double left, double top, double right, double bottom, int color) {
        if (left < right) {
            double i = left;
            left = right;
            right = i;
        }

        if (top < bottom) {
            double j = top;
            top = bottom;
            bottom = j;
        }

        float f3 = (float) (color >> 24 & 255) / 255.0F;
        float f = (float) (color >> 16 & 255) / 255.0F;
        float f1 = (float) (color >> 8 & 255) / 255.0F;
        float f2 = (float) (color & 255) / 255.0F;
        Tessellator tessellator = Tessellator.getInstance();
        BufferBuilder bufferbuilder = tessellator.getBuffer();
        GlStateManager.enableBlend();
        GlStateManager.disableTexture2D();
        GlStateManager.tryBlendFuncSeparate(
                GlStateManager.SourceFactor.SRC_ALPHA,
                GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA,
                GlStateManager.SourceFactor.ONE,
                GlStateManager.DestFactor.ZERO
        );
        GlStateManager.color(f, f1, f2, f3);
        bufferbuilder.begin(7, DefaultVertexFormats.POSITION);
        bufferbuilder.pos(left, bottom, 0.0D).endVertex();
        bufferbuilder.pos(right, bottom, 0.0D).endVertex();
        bufferbuilder.pos(right, top, 0.0D).endVertex();
        bufferbuilder.pos(left, top, 0.0D).endVertex();
        tessellator.draw();
        GlStateManager.enableTexture2D();
        GlStateManager.disableBlend();
    }

    public static void drawOutLineRect(float x, float y, float width, float height, float line, int color) {
        RenderUtil.drawDoubleRectWH(x, y, width, line, color);
        RenderUtil.drawDoubleRectWH(x, y + line, line, height - line * 2, color);
        RenderUtil.drawDoubleRectWH(x + width - line, y + line, line, height - line * 2, color);
        RenderUtil.drawDoubleRectWH(x, y + height - line, width, line, color);
    }

    public static void drawDoubleRectWH(float x, float y, float width, float height, int color) {
        width = x + width;
        height = y + height;
        if (x < width) {
            float i = x;
            x = width;
            width = i;
        }

        if (y < height) {
            float j = y;
            y = height;
            height = j;
        }

        float red = (float) (color >> 16 & 255) / 255.0F;
        float green = (float) (color >> 8 & 255) / 255.0F;
        float blue = (float) (color & 255) / 255.0F;
        float alpha = (float) (color >> 24 & 255) / 255.0F;
        Tessellator tessellator = Tessellator.getInstance();
        BufferBuilder bufferbuilder = tessellator.getBuffer();
        GlStateManager.enableBlend();
        GlStateManager.disableTexture2D();
        GlStateManager.tryBlendFuncSeparate(
                GlStateManager.SourceFactor.SRC_ALPHA,
                GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA,
                GlStateManager.SourceFactor.ONE,
                GlStateManager.DestFactor.ZERO
        );
        GlStateManager.color(red, green, blue, alpha);
        bufferbuilder.begin(7, DefaultVertexFormats.POSITION);
        bufferbuilder.pos(x, height, 0.0D).endVertex();
        bufferbuilder.pos(width, height, 0.0F).endVertex();
        bufferbuilder.pos(width, y, 0.0F).endVertex();
        bufferbuilder.pos(x, y, 0.0F).endVertex();
        tessellator.draw();
        GlStateManager.enableTexture2D();
        GlStateManager.disableBlend();
    }

    public static void drawHead(ResourceLocation location, ITextureObject object, float x, float y, float width, float height) {
        glColor4f(1F, 1F, 1F, 1F);
        mc.getTextureManager().loadTexture(location, object);
        mc.getTextureManager().bindTexture(location);
        RenderUtil.drawScaledCustomSizeModalRect(x, y, 8f, 8f, 8, 8, width, height, 64f, 64f);
        RenderUtil.drawScaledCustomSizeModalRect(x, y, 40f, 8f, 8, 8, width, height, 64f, 64f);
    }

    public static void drawHead(EntityLivingBase player, float x, float y, float width, float height) {
        glColor4f(1F, 1F, 1F, 1F);
        mc.getTextureManager().bindTexture(((AbstractClientPlayer) player).getLocationSkin());
        RenderUtil.drawScaledCustomSizeModalRect(x, y, 8f, 8f, 8, 8, width, height, 64f, 64f);
        RenderUtil.drawScaledCustomSizeModalRect(x, y, 40f, 8f, 8, 8, width, height, 64f, 64f);
    }

    public static void drawScaledCustomSizeModalRect(float x, float y, float u, float v, float uWidth, float vHeight, float width, float height, float tileWidth, float tileHeight) {
        float f = 1.0F / tileWidth;
        float f1 = 1.0F / tileHeight;
        GlStateManager.enableBlend();
        Tessellator tessellator = Tessellator.getInstance();
        BufferBuilder bufferBuilder = tessellator.getBuffer();
        bufferBuilder.begin(GL11.GL_QUADS, DefaultVertexFormats.POSITION_TEX);
        bufferBuilder.pos(x, y + height, 0.0D).tex(u * f, (v + vHeight) * f1).endVertex();
        bufferBuilder.pos(x + width, y + height, 0.0D).tex((u + uWidth) * f, (v + vHeight) * f1).endVertex();
        bufferBuilder.pos(x + width, y, 0.0D).tex((u + uWidth) * f, v * f1).endVertex();
        bufferBuilder.pos(x, y, 0.0D).tex(u * f, v * f1).endVertex();
        tessellator.draw();
        GlStateManager.disableBlend();
    }

    public static void drawRoundedRect(float x, float y, float width, float height, float radius, int color) {
        glPushAttrib(0);
        glScaled(0.5D, 0.5D, 0.5D);
        x *= 2.0D;
        y *= 2.0D;
        width *= 2.0D;
        height *= 2.0D;
        GlStateManager.enableBlend();
        GlStateManager.disableTexture2D();
        float a = (color >> 24 & 0xFF) / 255.0F;
        float r = (color >> 16 & 0xFF) / 255.0F;
        float g = (color >> 8 & 0xFF) / 255.0F;
        float b = (color & 0xFF) / 255.0F;
        glColor4f(r, g, b, a);
        glEnable(GL_LINE_SMOOTH);
        glBegin(GL_POLYGON);
        int i;
        for (i = 0; i <= 90; i += 3)
            glVertex2d(x + radius + Math.sin(i * MathUtil.PI / 180.0D) * radius * -1.0D, y + radius + Math.cos(i * MathUtil.PI / 180.0D) * radius * -1.0D);
        for (i = 90; i <= 180; i += 3)
            glVertex2d(x + radius + Math.sin(i * MathUtil.PI / 180.0D) * radius * -1.0D, (y + height) - radius + Math.cos(i * MathUtil.PI / 180.0D) * radius * -1.0D);
        for (i = 0; i <= 90; i += 3)
            glVertex2d((x + width) - radius + Math.sin(i * MathUtil.PI / 180.0D) * radius, (y + height) - radius + Math.cos(i * MathUtil.PI / 180.0D) * radius);
        for (i = 90; i <= 180; i += 3)
            glVertex2d((x + width) - radius + Math.sin(i * MathUtil.PI / 180.0D) * radius, y + radius + Math.cos(i * MathUtil.PI / 180.0D) * radius);
        glEnd();
        glBegin(GL_LINE_LOOP);
        for (i = 0; i <= 90; i += 3)
            glVertex2d(x + radius + Math.sin(i * MathUtil.PI / 180.0D) * radius * -1.0D, y + radius + Math.cos(i * MathUtil.PI / 180.0D) * radius * -1.0D);
        for (i = 90; i <= 180; i += 3)
            glVertex2d(x + radius + Math.sin(i * MathUtil.PI / 180.0D) * radius * -1.0D, (y + height) - radius + Math.cos(i * MathUtil.PI / 180.0D) * radius * -1.0D);
        for (i = 0; i <= 90; i += 3)
            glVertex2d((x + width) - radius + Math.sin(i * MathUtil.PI / 180.0D) * radius, (y + height) - radius + Math.cos(i * MathUtil.PI / 180.0D) * radius);
        for (i = 90; i <= 180; i += 3)
            glVertex2d((x + width) - radius + Math.sin(i * MathUtil.PI / 180.0D) * radius, y + radius + Math.cos(i * MathUtil.PI / 180.0D) * radius);
        glEnd();
        glDisable(GL_LINE_SMOOTH);
        GlStateManager.enableTexture2D();
        GlStateManager.disableBlend();
        glScaled(2.0D, 2.0D, 2.0D);
        glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
        glPopAttrib();
    }

    public static void drawSmotherRoundedRect(float x, float y, float width, float height, float radius, int color, boolean smother) {
        glPushAttrib(0);
        glScaled(0.5D, 0.5D, 0.5D);
        x *= 2.0D;
        y *= 2.0D;
        width *= 2.0D;
        height *= 2.0D;
        GlStateManager.enableBlend();
        GlStateManager.disableTexture2D();
        float a = (color >> 24 & 0xFF) / 255.0F;
        float r = (color >> 16 & 0xFF) / 255.0F;
        float g = (color >> 8 & 0xFF) / 255.0F;
        float b = (color & 0xFF) / 255.0F;
        glColor4f(r, g, b, a);
        if (smother) glEnable(GL_LINE_SMOOTH);
        glBegin(GL_POLYGON);
        int i;
        for (i = 0; i <= 90; i += 3)
            glVertex2d(x + radius + Math.sin(i * MathUtil.PI / 180.0D) * radius * -1.0D, y + radius + Math.cos(i * MathUtil.PI / 180.0D) * radius * -1.0D);
        for (i = 90; i <= 180; i += 3)
            glVertex2d(x + radius + Math.sin(i * MathUtil.PI / 180.0D) * radius * -1.0D, (y + height) - radius + Math.cos(i * MathUtil.PI / 180.0D) * radius * -1.0D);
        for (i = 0; i <= 90; i += 3)
            glVertex2d((x + width) - radius + Math.sin(i * MathUtil.PI / 180.0D) * radius, (y + height) - radius + Math.cos(i * MathUtil.PI / 180.0D) * radius);
        for (i = 90; i <= 180; i += 3)
            glVertex2d((x + width) - radius + Math.sin(i * MathUtil.PI / 180.0D) * radius, y + radius + Math.cos(i * MathUtil.PI / 180.0D) * radius);
        glEnd();
        if (smother) {
            glBegin(GL_LINE_LOOP);
            for (i = 0; i <= 90; i += 3)
                glVertex2d(x + radius + Math.sin(i * MathUtil.PI / 180.0D) * radius * -1.0D, y + radius + Math.cos(i * MathUtil.PI / 180.0D) * radius * -1.0D);
            for (i = 90; i <= 180; i += 3)
                glVertex2d(x + radius + Math.sin(i * MathUtil.PI / 180.0D) * radius * -1.0D, (y + height) - radius + Math.cos(i * MathUtil.PI / 180.0D) * radius * -1.0D);
            for (i = 0; i <= 90; i += 3)
                glVertex2d((x + width) - radius + Math.sin(i * MathUtil.PI / 180.0D) * radius, (y + height) - radius + Math.cos(i * MathUtil.PI / 180.0D) * radius);
            for (i = 90; i <= 180; i += 3)
                glVertex2d((x + width) - radius + Math.sin(i * MathUtil.PI / 180.0D) * radius, y + radius + Math.cos(i * MathUtil.PI / 180.0D) * radius);
            glEnd();
        }
        if (smother) glDisable(GL_LINE_SMOOTH);
        GlStateManager.enableTexture2D();
        GlStateManager.disableBlend();
        glScaled(2.0D, 2.0D, 2.0D);
        glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
        glPopAttrib();
    }

    public static void setColor(int color) {
        float a = (color >> 24 & 0xFF) / 255.0F;
        float r = (color >> 16 & 0xFF) / 255.0F;
        float g = (color >> 8 & 0xFF) / 255.0F;
        float b = (color & 0xFF) / 255.0F;
        glColor4f(r, g, b, a);
    }

    public static void renderItem(ItemStack itemStack, int x, int y) {
        glPushMatrix();
        glEnable(GL_BLEND);
        glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
        glEnable(GL_DEPTH_TEST);
        RenderHelper.enableGUIStandardItemLighting();
        mc.getRenderItem().renderItemAndEffectIntoGUI(itemStack, x, y);
        mc.getRenderItem().renderItemOverlays(mc.fontRenderer, itemStack, x, y);
        RenderHelper.disableStandardItemLighting();
        glColor4f(1, 1, 1, 1);
        glDisable(GL_DEPTH_TEST);
        glPopMatrix();
    }

    public static void glScissor(float x, float y, float width, float height) {
        ScaledResolution sr = new ScaledResolution(mc);
        float scale = sr.getScaleFactor();
        float finalHeight = height * scale;
        float finalY = (sr.getScaledHeight() - y) * scale;
        float finalX = x * scale;
        float finalWidth = width * scale;
        GL11.glScissor((int) finalX, (int) (finalY - finalHeight), (int) finalWidth, (int) finalHeight);
    }
}
