package me.enokitoraisu.shimejiclient.event;

import net.minecraft.util.EnumHand;

public class SwingArmEvent extends EventManager {
    private final EnumHand hand;

    public SwingArmEvent(EnumHand hand) {
        this.hand = hand;
    }

    public EnumHand getHand() {
        return hand;
    }
}
