package me.enokitoraisu.shimejiclient.mixin;

import net.minecraftforge.fml.client.SplashProgress;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(SplashProgress.class)
public abstract class MixinSplashProgress {
    /*
    @Shadow private static boolean enabled;

    @Overwrite
    public static void start() {
        enabled = true;
        if (Loader.instance().getIndexedModList().get("Abyss") == null) ShimejiSplashProgress.start();
    }

    @Overwrite
    public static void finish() {
        if (Loader.instance().getIndexedModList().get("Abyss") == null) ShimejiSplashProgress.finish();
    }

    @Deprecated
    @Overwrite
    public static void resume() {
        if (Loader.instance().getIndexedModList().get("Abyss") == null) ShimejiSplashProgress.resume();
    }

    @Deprecated
    @Overwrite
    public static void pause() {
        if (Loader.instance().getIndexedModList().get("Abyss") == null) ShimejiSplashProgress.pause();
    }
    */
}
