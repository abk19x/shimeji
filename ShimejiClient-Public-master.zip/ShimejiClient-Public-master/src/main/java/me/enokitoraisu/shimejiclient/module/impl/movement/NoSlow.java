package me.enokitoraisu.shimejiclient.module.impl.movement;

import me.enokitoraisu.shimejiclient.module.Category;
import me.enokitoraisu.shimejiclient.module.Module;
import me.enokitoraisu.shimejiclient.value.values.ModeValue;
import org.lwjgl.input.Keyboard;

@SuppressWarnings("unused")
public class NoSlow extends Module {
    public static NoSlow INSTANCE = new NoSlow();
    public ModeValue mode = register(new ModeValue("Mode", "Vanilla", "Vanilla"));

    public NoSlow() {
        super("NoSlow", Category.MOVEMENT, Keyboard.KEY_NONE);
        INSTANCE = this;
    }

    public void onTick() {
    }
}
