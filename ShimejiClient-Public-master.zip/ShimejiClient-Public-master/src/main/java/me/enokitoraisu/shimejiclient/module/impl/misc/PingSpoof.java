package me.enokitoraisu.shimejiclient.module.impl.misc;

import me.enokitoraisu.shimejiclient.event.PacketEvent;
import me.enokitoraisu.shimejiclient.module.Category;
import me.enokitoraisu.shimejiclient.module.Module;
import me.enokitoraisu.shimejiclient.value.values.IntegerValue;
import net.minecraft.network.play.client.CPacketKeepAlive;
import net.minecraft.network.play.server.SPacketKeepAlive;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import org.lwjgl.input.Keyboard;

import java.util.Random;

@SuppressWarnings("unused")
public class PingSpoof extends Module {
    public IntegerValue min_delay = register(new IntegerValue("MinDelay", 1000, 0, 5000));
    public IntegerValue max_delay = register(new IntegerValue("MaxDelay", 2000, 0, 5000));

    public Random random = new Random();

    public PingSpoof() {
        super("PingSpoof", Category.MISC, Keyboard.KEY_NONE);
    }

    public void onTick() {
        setTags(min_delay.getValue() + "-" + max_delay.getValue());
    }

    @SubscribeEvent
    public void onPacket(PacketEvent.Receive event) {
        if (event.getPacket() instanceof SPacketKeepAlive) {
            SPacketKeepAlive packet = (SPacketKeepAlive) event.getPacket();
            event.setCanceled(true);
            new Thread(() -> {
                int delay = random.nextInt(max_delay.getValue() - min_delay.getValue()) + min_delay.getValue();
                try {
                    Thread.sleep(delay);
                } catch (InterruptedException ignored) {
                }
                if (fullNullCheck()) mc.player.connection.sendPacket(new CPacketKeepAlive(packet.getId()));
            }).start();
        }
    }
}
